# Helia IPFS & viem ENS — Exhaustive Reference

> Last updated: March 2026  
> Sources: [Helia GitHub](https://github.com/ipfs/helia), [Helia Wiki](https://github.com/ipfs/helia/wiki), [npm: helia](https://www.npmjs.com/package/helia), [npm: @helia/unixfs](https://www.npmjs.com/package/@helia/unixfs), [viem docs](https://viem.sh), [ENS Docs](https://docs.ens.domains/learn/deployments), [Pinata Docs](https://docs.pinata.cloud), [Storacha Docs](https://docs.storacha.network)

---

## TABLE OF CONTENTS

**PART 1: Helia (Modern JS IPFS)**
1. [Current Status & Migration from js-ipfs](#1-current-status--migration-from-js-ipfs)
2. [Installation & Package Versions](#2-installation--package-versions)
3. [Basic Usage](#3-basic-usage)
4. [Pinning to Remote Services](#4-pinning-to-remote-services)
5. [CID Verification](#5-cid-verification)
6. [Alternative: Pinata REST API (Simpler)](#6-alternative-pinata-rest-api-simpler)
7. [Alternative: Storacha / web3.storage (w3up)](#7-alternative-storacha--web3storage-w3up)

**PART 2: viem ENS Methods**
1. [getEnsText](#1-getenstext)
2. [getEnsResolver](#2-getensresolver)
3. [getEnsAddress](#3-getensaddress)
4. [namehash and normalize](#4-namehash-and-normalize)
5. [Writing ENS Records via writeContract](#5-writing-ens-records-via-writecontract)
6. [viem Chain Configs & ENS Contract Addresses](#6-viem-chain-configs--ens-contract-addresses)
7. [keccak256, toHex, toBytes](#7-keccak256-tohex-tobytes)
8. [parseAbi](#8-parseabi)

---

---

# PART 1: Helia (Modern JS IPFS)

---

## 1. Current Status & Migration from js-ipfs

### js-ipfs is Deprecated

**js-ipfs is fully deprecated and the repository was archived on February 12, 2024.** It is now read-only. ([GitHub tracking issue](https://github.com/ipfs/js-ipfs/issues/4336), [IPFS Forums announcement](https://discuss.ipfs.tech/t/js-ipfs-deprecation-replaced-by-helia/16478))

> **TL;DR**: js-IPFS has been superseded by **Helia**. All npm modules from the js-ipfs monorepo (`ipfs`, `ipfs-core`, `ipfs-http-client`, etc.) are deprecated. Do not start new projects with them.

**Companion migration**: `ipfs-http-client` (for Kubo RPC) is superseded by [`kubo-rpc-client`](https://www.npmjs.com/package/kubo-rpc-client) — not by Helia. Helia is the replacement for the full embedded node (`ipfs-core`).

### Migration Path

| js-ipfs API | Helia Equivalent |
|---|---|
| `import { create } from 'ipfs-core'` | `import { createHelia } from 'helia'` |
| `ipfs.add(buf)` | `fs.addBytes(buf)` via `@helia/unixfs` |
| `ipfs.cat(cid)` | `fs.cat(cid)` via `@helia/unixfs` |
| `ipfs.dag.put({ hello: 'world' })` | `j.add({ hello: 'world' })` via `@helia/json` |
| `ipfs.pin.add(cid)` | `helia.pin.add(cid)` |
| `ipfs.block.get(cid)` | `helia.blockstore.get(cid)` |
| `ipfs.block.put(buf)` | `helia.blockstore.put(cid, buf)` |
| `ipfs.files.mkdir('/foo')` | `fs.mkdir('/foo')` via `@helia/mfs` |
| `ipfs.name.publish(cid)` | `name.publish(peerId, cid)` via `@helia/ipns` |
| `ipfs.id()` | `helia.libp2p.peerId` |
| `ipfs.repo.gc()` | `helia.gc()` |

Full migration guide: [https://github.com/ipfs/helia/wiki/Migrating-from-js-IPFS](https://github.com/ipfs/helia/wiki/Migrating-from-js-IPFS)

---

## 2. Installation & Package Versions

### Core Package

```bash
npm install helia
```

- **Latest version**: `6.0.20` (as of February 2026; [npm](https://www.npmjs.com/package/helia?activeTab=dependencies))
- **Node.js requirement**: Node.js 18+ (Helia and its dependencies dropped support for Node 16 in late 2023)

### All Main Packages

```bash
# Core node
npm install helia

# File data (binary/bytes, files, directories)
npm install @helia/unixfs       # v5.1.0 (latest as of ~Feb 2026)

# Mutable File System (like IPFS MFS)
npm install @helia/mfs          # v7.0.4

# Typed data modules
npm install @helia/strings      # strings ↔ CID
npm install @helia/json         # plain JSON objects ↔ CID
npm install @helia/dag-json     # DAG-JSON with CID links
npm install @helia/dag-cbor     # DAG-CBOR (compact binary)
npm install @helia/car          # CAR file export/import

# IPNS (mutable names)
npm install @helia/ipns

# HTTP-only mode (no p2p, uses IPFS gateways)
npm install @helia/http

# CID and multiformats
npm install multiformats        # CID, hashing, codecs
```

### TypeScript Support

All Helia packages ship native TypeScript types. No `@types/` packages needed.

---

## 3. Basic Usage

### createHelia() — Configuration Options

```typescript
import { createHelia } from 'helia'
import { MemoryBlockstore } from 'blockstore-core'
import { MemoryDatastore } from 'datastore-core'

// Minimal — uses defaults (in-memory blockstore/datastore, libp2p with sensible defaults)
const helia = await createHelia()

// Full configuration (HeliaInit type)
const helia = await createHelia({
  // Custom blockstore (default: in-memory)
  blockstore: new MemoryBlockstore(),

  // Custom datastore for metadata/IPNS records (default: in-memory)
  datastore: new MemoryDatastore(),

  // Custom libp2p configuration
  // libp2p: customLibp2pInstance,

  // Use only HTTP gateways (no p2p networking) — @helia/http
  // For @helia/http: import { createHeliaHTTP } from '@helia/http'
  // gateways: ['https://ipfs.io', 'https://cloudflare-ipfs.com'],

  // DNS resolvers for DNSLink
  // dns: customDnsResolver,
})

// Always stop the node when done
await helia.stop()
```

**For persistent storage (Node.js)**:

```typescript
import { createHelia } from 'helia'
import { FsBlockstore } from 'blockstore-fs'
import { FsDatastore } from 'datastore-fs'

const blockstore = new FsBlockstore('./ipfs/blocks')
const datastore = new FsDatastore('./ipfs/data')

const helia = await createHelia({ blockstore, datastore })
```

```bash
npm install blockstore-fs datastore-fs
```

**Lightweight HTTP-only mode** (no libp2p overhead, reads via public gateways):

```typescript
import { createHeliaHTTP } from '@helia/http'

const helia = await createHeliaHTTP()
// No p2p, reads content via HTTP gateways only
// Cannot add content to the DHT
```

---

### unixfs(helia) — Available Methods

```typescript
import { createHelia } from 'helia'
import { unixfs } from '@helia/unixfs'

const helia = await createHelia()
const fs = unixfs(helia)
```

**Complete method list**:

| Method | Signature | Description |
|--------|-----------|-------------|
| `addBytes` | `(bytes: Uint8Array, options?) => Promise<CID>` | Add raw bytes as a UnixFS file |
| `addFile` | `(file: { path?: string, content: AsyncIterable<Uint8Array> \| Uint8Array }, options?) => Promise<CID>` | Add a single file with optional path |
| `addDirectory` | `(options?) => Promise<CID>` | Create an empty directory node |
| `addAll` | `(source: ImportSource, options?) => AsyncGenerator<{ cid, path, size }>` | Add multiple files/directories |
| `cat` | `(cid: CID, options?) => AsyncIterable<Uint8Array>` | Read content by CID (async iterable of chunks) |
| `ls` | `(cid: CID, options?) => AsyncIterable<UnixFSEntry>` | List directory contents |
| `cp` | `(source: CID, dest: CID, name: string, options?) => Promise<CID>` | Copy a file into a directory |
| `rm` | `(cid: CID, name: string, options?) => Promise<CID>` | Remove a file from a directory |
| `stat` | `(cid: CID, options?) => Promise<UnixFSStat>` | Get file/directory metadata |
| `chmod` | `(cid: CID, mode: number, options?) => Promise<CID>` | Change permissions |
| `touch` | `(cid: CID, options?) => Promise<CID>` | Update mtime |

---

### fs.addBytes() — Adding Content

```typescript
import { createHelia } from 'helia'
import { unixfs } from '@helia/unixfs'

const helia = await createHelia()
const fs = unixfs(helia)

// Add raw bytes
const cid = await fs.addBytes(Uint8Array.from([0, 1, 2, 3]))
console.log(cid.toString())
// bafkreiaarb72fwwtlcvsyiip25xbwfhvxqfzh3dkxkr7xb3xhqjchzxwy  (CIDv1, base32)

// Add a UTF-8 string
const encoder = new TextEncoder()
const textCid = await fs.addBytes(encoder.encode('Hello, IPFS!'))

// Add JSON content (deterministic — use consistent serialization)
const jsonBytes = new TextEncoder().encode(JSON.stringify({ hello: 'world' }))
const jsonCid = await fs.addBytes(jsonBytes)

// Add with options
const cid2 = await fs.addBytes(bytes, {
  cidVersion: 1,       // default is 1 for Helia
  rawLeaves: true,     // store leaf nodes as raw bytes (changes CID)
  chunkSize: 262144,   // chunk size in bytes (256 KiB default)
  hasher: sha256,      // hash algorithm (default: sha2-256)
})

// Higher-level: @helia/json (recommended for JSON)
import { json } from '@helia/json'
const j = json(helia)
const jsonCid = await j.add({ hello: 'world' })
const retrieved = await j.get(jsonCid)  // { hello: 'world' }

// @helia/strings for text
import { strings } from '@helia/strings'
const s = strings(helia)
const strCid = await s.add('Hello, World!')
const str = await s.get(strCid)  // 'Hello, World!'
```

---

### fs.cat() — Reading Content by CID

```typescript
import { CID } from 'multiformats/cid'

// cat() returns an async iterable of Uint8Array chunks
const chunks: Uint8Array[] = []
for await (const chunk of fs.cat(cid)) {
  chunks.push(chunk)
}

// Reassemble all chunks into a single Uint8Array
const allBytes = new Uint8Array(chunks.reduce((acc, chunk) => acc + chunk.length, 0))
let offset = 0
for (const chunk of chunks) {
  allBytes.set(chunk, offset)
  offset += chunk.length
}

// Decode as UTF-8 string
const text = new TextDecoder().decode(allBytes)

// With a CID string (parse first)
const cid = CID.parse('bafkrei...')
for await (const chunk of fs.cat(cid)) { /* ... */ }

// Convenience helper:
async function collectCat(fs: any, cid: CID): Promise<Uint8Array> {
  const chunks: Uint8Array[] = []
  for await (const chunk of fs.cat(cid)) chunks.push(chunk)
  const total = chunks.reduce((n, c) => n + c.length, 0)
  const out = new Uint8Array(total)
  let i = 0
  for (const c of chunks) { out.set(c, i); i += c.length }
  return out
}
```

---

### CID Format — CIDv0 vs CIDv1

| Property | CIDv0 | CIDv1 |
|---|---|---|
| Starts with | `Qm` | `bafk`, `bafy`, `b`, etc. |
| Encoding | Base58btc | Multibase (default: base32) |
| Codec | dag-pb only | Any (dag-pb, dag-cbor, raw, etc.) |
| Length (chars) | 46 | Variable (~59 for base32) |
| Used by | Legacy IPFS, Pinata `cidVersion:0` | Helia default, modern IPFS |

```typescript
import { CID } from 'multiformats/cid'
import { sha256 } from 'multiformats/hashes/sha2'

// Parse either version
const cidv0 = CID.parse('QmZ4tDuvesekSs4qM5ZBKpXiZGun7S2CYtEZRB3DYXkjGx')
const cidv1 = CID.parse('bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi')

// Convert CIDv0 → CIDv1
const asV1 = cidv0.toV1()
console.log(asV1.toString())  // base32 CIDv1 equivalent

// Convert CIDv1 → CIDv0 (only works for dag-pb + sha2-256)
const asV0 = cidv1.toV0()
console.log(asV0.toString())  // Qm... 

// Check version
console.log(cid.version)  // 0 or 1

// Multibase encodings for CIDv1
console.log(cid.toString())          // base32 (default, 'b' prefix)
console.log(cid.toString('base58btc')) // base58btc ('z' prefix)
console.log(cid.toString('base64'))  // base64 ('m' prefix)

// CIDv1 anatomy:
// <multibase><version><multicodec><multihash>
// e.g. bafybeig...
//       b = base32
//       afy = version 1 + dag-pb codec
//       beig... = sha2-256 multihash
```

**Important**: Helia defaults to **CIDv1** with base32 encoding. The old `Qm...` CIDv0 format is still supported for reading, but new content added via Helia gets CIDv1 unless you force `cidVersion: 0`.

---

## 4. Pinning to Remote Services

### Strategy: Helia as Local Node + Remote Pinning

Helia is a local IPFS node. To persist content on the network, you need to **pin it to a remote service**. There are two main approaches:

1. **Use Helia locally to get the CID, then call the pinning service's REST API** (recommended — simpler)
2. **Configure Helia to replicate to a remote node** (complex, not well supported)

For most use cases (e.g., storing JSON metadata), **approach 1 is strongly recommended**:

```
your code → createHelia() → fs.addBytes() → get CID → call pinning service REST API with CID
```

---

### Pinning to Pinata

**Pinata is the most production-ready IPFS pinning service** with a simple REST API and a modern SDK.

#### Method 1: Modern Pinata SDK (Recommended)

```bash
npm install pinata
```

```typescript
import { PinataSDK } from 'pinata'

const pinata = new PinataSDK({
  pinataJwt: process.env.PINATA_JWT!,
  pinataGateway: 'your-gateway.mypinata.cloud',  // your dedicated gateway subdomain
})

// Upload JSON directly
const upload = await pinata.upload.public.json({
  id: 2,
  name: 'Bob Smith',
  email: 'bob@example.com',
  age: 34,
})
console.log(upload.cid)   // bafkrei...
console.log(upload.id)    // Pinata file ID

// Upload a file
const blob = new Blob(['Hello, IPFS!'], { type: 'text/plain' })
const file = new File([blob], 'hello.txt', { type: 'text/plain' })
const fileUpload = await pinata.upload.public.file(file)

// Upload base64
const b64Upload = await pinata.upload.public.base64('SGVsbG8gV29ybGQh')

// Pin an existing CID (from your Helia node or elsewhere)
const pin = await pinata.upload.public.cid('QmVLwvmGehsrNEvhcCnnsw5RQNseohgEkFNN1848zNzdng')
```

#### Method 2: Pinata REST API (No SDK dependency)

**Endpoint**: `POST https://api.pinata.cloud/pinning/pinJSONToIPFS`

```typescript
const JWT = process.env.PINATA_JWT!

async function pinJSONToIPFS(content: object, name?: string) {
  const data = JSON.stringify({
    pinataContent: content,
    pinataMetadata: {
      name: name ?? 'metadata.json',
    },
    pinataOptions: {
      cidVersion: 1,  // 0 for legacy Qm... CIDs, 1 for bafk... (default)
    },
  })

  const response = await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${JWT}`,
    },
    body: data,
  })

  if (!response.ok) throw new Error(`Pinata error: ${response.statusText}`)
  
  const result = await response.json()
  return result
  // {
  //   IpfsHash: "bafkrei...",      // CID of the pinned content
  //   PinSize: 1234,                // bytes
  //   Timestamp: "2024-01-01T..."   // ISO 8601
  // }
}

// Usage
const result = await pinJSONToIPFS({ hello: 'world' }, 'my-metadata')
console.log('CID:', result.IpfsHash)
```

**Upload a file (multipart)**:
```typescript
async function uploadFileToPinata(filePath: string): Promise<string> {
  const formData = new FormData()
  const fileBlob = new Blob([require('fs').readFileSync(filePath)])
  const fileName = require('path').basename(filePath)
  formData.append('file', fileBlob, fileName)
  formData.append('pinataMetadata', JSON.stringify({ name: fileName }))
  formData.append('pinataOptions', JSON.stringify({ cidVersion: 1 }))

  const response = await fetch('https://uploads.pinata.cloud/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.PINATA_JWT}`,
    },
    body: formData,
  })
  const result = await response.json()
  return result.data.cid  // Note: v3 API returns { data: { cid, ... } }
}
```

**Authentication**:
- **JWT** (recommended): `Authorization: Bearer <JWT>` — obtained from Pinata dashboard, scoped per endpoint
- **Legacy API keys**: `pinata_api_key` + `pinata_secret_api_key` headers (still supported but deprecated in favor of JWT)

**File size limit for pinJSONToIPFS**: 10 MB per the [Pinata docs](https://docs.pinata.cloud/llms-full.txt).

---

### Pinning to web3.storage (Now: Storacha)

> **Status**: web3.storage has been fully rebranded and rebuilt as **Storacha** (storacha.network). The old `web3.storage` JavaScript SDK is deprecated. The current package is `@storacha/client`. ([IPFS Forums](https://discuss.ipfs.tech/t/web3storage-sorchanetwork-api-token/19076))

**Key change**: Storacha uses **UCAN (User Controlled Authorization Networks)** instead of API tokens. Authentication is via email, generating a client-side key pair stored locally.

#### Installation & Authentication

```bash
npm install @storacha/client
```

```typescript
import { create } from '@storacha/client'

// Create client (generates/loads local key pair)
const client = await create()

// Authenticate via email (sends a confirmation email)
const account = await client.login('you@example.com')
await account.plan.wait()  // Wait until you've confirmed the email and have a paid/free plan

// Create a storage space
const space = await client.createSpace('my-app-space', { account })
await client.setCurrentSpace(space.did())
```

#### Uploading Files & JSON

```typescript
// Upload a single file (accepts Blob/File)
const fileCid = await client.uploadFile(new Blob(['Hello!']))
console.log(fileCid.toString())  // bafkrei...

// Upload JSON
const jsonBlob = new Blob([JSON.stringify({ hello: 'world' })], { type: 'application/json' })
const jsonCid = await client.uploadFile(jsonBlob)

// Upload multiple files as a directory
const files = [
  new File(['readme content'], 'readme.md'),
  new File([JSON.stringify({ data: 1 })], 'data.json'),
  new File([imageBinaryData], 'photo.png'),
]
const directoryCid = await client.uploadDirectory(files)
// Access: https://dweb.link/ipfs/<dirCid>/readme.md

// Upload a CAR file
const carCid = await client.uploadCAR(carBlob)
```

**No API tokens**: All auth is via UCAN capabilities delegated from your account to the agent. No static API keys in environment variables (except the locally stored private key).

---

### Infura IPFS

> **Status**: Infura IPFS is **NOT deprecated** but is now a **restricted service** — available only to pre-qualified/enterprise customers. ([infura.io/product/ipfs](https://www.infura.io/product/ipfs)). The **public Infura IPFS gateway** was disabled in 2022. If you already have Infura IPFS credentials (project ID + secret), they still work.

#### Infura IPFS API (if you have access)

Authentication uses HTTP Basic auth with `PROJECT_ID:PROJECT_SECRET`.

```typescript
const projectId = process.env.INFURA_PROJECT_ID!
const projectSecret = process.env.INFURA_PROJECT_SECRET!
const auth = 'Basic ' + Buffer.from(`${projectId}:${projectSecret}`).toString('base64')

// Upload via REST (multipart)
async function uploadToInfura(content: Buffer | string, fileName: string) {
  const formData = new FormData()
  const blob = content instanceof Buffer ? new Blob([content]) : new Blob([content])
  formData.append('file', blob, fileName)

  const response = await fetch('https://ipfs.infura.io:5001/api/v0/add', {
    method: 'POST',
    headers: { Authorization: auth },
    body: formData,
  })
  const result = await response.json()
  return result.Hash  // CID
}
```

**For new projects**: Use Pinata or Storacha instead — both have more accessible free tiers and better documentation.

---

### Fileverse as Alternative

[Fileverse](https://fileverse.io) is an alternative IPFS pinning and storage service focused on privacy. It does not have a standard IPFS pinning REST API — it wraps IPFS storage in its own dApp and SDK. Not recommended as a drop-in Pinata replacement for REST API workflows.

---

## 5. CID Verification

### How CID is Computed

A CID is **not simply `sha256(content)`**. It embeds additional metadata:

```
CID = <multibase-prefix> + <cid-version> + <multicodec> + <multihash>
```

Where:
- **multibase**: encoding (base32 = `b`, base58btc = `z`, etc.)
- **cid-version**: `0` or `1`
- **multicodec**: how to interpret the content (`dag-pb` = 0x70, `raw` = 0x55, `dag-json` = 0x0129, etc.)
- **multihash**: `<hash-algorithm><hash-length><hash-bytes>` (e.g., sha2-256 = `0x12`, length = `0x20`)

**Important caveat**: For files larger than one chunk (~256 KiB), IPFS splits content into a DAG. The CID is the hash of the **root node** (which contains links to child nodes), **not** a direct hash of the raw file bytes. For small files using `rawLeaves: true`, the multihash equals `sha256(rawFileBytes)`. ([IPFS Docs](https://docs.ipfs.tech/concepts/content-addressing/))

### When `multihash == sha256(content)`

Only for **small files** (single block, `< 256 KiB` typically) stored with the `raw` codec:

```typescript
import { createHelia } from 'helia'
import { unixfs } from '@helia/unixfs'

const helia = await createHelia()
const fs = unixfs(helia)

// For JSON metadata (typically small), the CID's hash IS directly computable
const content = JSON.stringify({ hello: 'world' })
const bytes = new TextEncoder().encode(content)

// Add with raw codec + raw leaves for direct hash verifiability
const cid = await fs.addBytes(bytes, { rawLeaves: true })
```

### Verifying a CID Against Content

```typescript
import { CID } from 'multiformats/cid'
import { sha256 } from 'multiformats/hashes/sha2'
import * as dagPb from '@ipld/dag-pb'
import * as raw from 'multiformats/codecs/raw'

async function verifyCID(cid: CID, bytes: Uint8Array): Promise<boolean> {
  // Get the hash function from the CID's multihash
  const digest = await sha256.digest(bytes)
  
  // For raw codec (0x55), direct comparison
  if (cid.code === raw.code) {
    const expectedCid = CID.createV1(raw.code, digest)
    return expectedCid.equals(cid)
  }
  
  // For dag-pb (UnixFS), you'd need to encode as dag-pb first
  // Use Helia's cat() → compare bytes as easier approach:
  return false  // Different codec — use content comparison instead
}

// Simpler verification: re-add content and compare CIDs
async function verifyByReAdding(fs: any, knownCid: CID, bytes: Uint8Array): Promise<boolean> {
  const recomputedCid = await fs.addBytes(bytes)
  return recomputedCid.equals(knownCid)
}
```

### Deterministic JSON Serialization

**`JSON.stringify` is NOT deterministic** — property order depends on insertion order and may vary across environments/JS engines.

```typescript
// PROBLEM: These produce different CIDs even though semantically equal
const a = JSON.stringify({ b: 2, a: 1 })  // '{"b":2,"a":1}'
const b = JSON.stringify({ a: 1, b: 2 })  // '{"a":1,"b":2}'

// SOLUTION 1: Use @helia/json (handles serialization internally via dag-json)
import { json } from '@helia/json'
const j = json(helia)
const cid = await j.add({ a: 1, b: 2 })  // dag-json codec, deterministic

// SOLUTION 2: Sort keys before stringifying
function stableStringify(obj: object): string {
  return JSON.stringify(obj, Object.keys(obj).sort())
}

// SOLUTION 3: Use a deterministic JSON library
// npm install json-stringify-deterministic
import stringify from 'json-stringify-deterministic'
const deterministicBytes = new TextEncoder().encode(stringify({ b: 2, a: 1 }))

// SOLUTION 4: Use @ipld/dag-json (canonical IPLD encoding)
import * as dagJson from '@ipld/dag-json'
const encoded = dagJson.encode({ b: 2, a: 1 })  // Always same bytes for same object
```

**Recommendation for ENS + IPFS workflows**: Use `@helia/json` or `@ipld/dag-json` to store JSON, as these produce deterministic dag-json encoded CIDs.

---

## 6. Alternative: Direct Pinata REST API (Simpler)

For use cases where you just need to store JSON on IPFS, you don't need to run a Helia node at all. The **Pinata REST API** is a much simpler approach.

### pinJSONToIPFS Endpoint

**URL**: `POST https://api.pinata.cloud/pinning/pinJSONToIPFS`  
**Auth**: `Authorization: Bearer <PINATA_JWT>`  
**Content-Type**: `application/json`

**Request body**:
```json
{
  "pinataContent": { /* any valid JSON object */ },
  "pinataMetadata": {
    "name": "my-file.json",
    "keyvalues": {
      "version": "1",
      "app": "my-dapp"
    }
  },
  "pinataOptions": {
    "cidVersion": 1
  }
}
```

**Response**:
```json
{
  "IpfsHash": "bafkreih5aznjvttude6c3wbvqeebb6rlx5wkbzyppv7garjiubll2ceym4",
  "PinSize": 1234,
  "Timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Complete Runnable Example

```typescript
const PINATA_JWT = process.env.PINATA_JWT!

interface PinataResponse {
  IpfsHash: string
  PinSize: number
  Timestamp: string
}

async function pinJSONToIPFS(content: object, name = 'metadata.json'): Promise<PinataResponse> {
  const response = await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${PINATA_JWT}`,
    },
    body: JSON.stringify({
      pinataContent: content,
      pinataMetadata: { name },
      pinataOptions: { cidVersion: 1 },
    }),
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`Pinata API error ${response.status}: ${errorText}`)
  }

  return response.json() as Promise<PinataResponse>
}

// Usage
const result = await pinJSONToIPFS({
  name: 'My NFT',
  description: 'An amazing NFT',
  image: 'ipfs://bafkreih5aznjvttude6c3wbvqeebb6rlx5wkbzyppv7garjiubll2ceym4',
  attributes: [{ trait_type: 'Color', value: 'Blue' }],
})

console.log('Stored at IPFS CID:', result.IpfsHash)
console.log('Gateway URL:', `https://ipfs.io/ipfs/${result.IpfsHash}`)
```

### Getting Your Pinata JWT

1. Sign up at [app.pinata.cloud](https://app.pinata.cloud)
2. Go to **API Keys** → **New Key**
3. Choose scope (Admin or specific endpoints)
4. Copy the JWT (only shown once)

---

## 7. Alternative: Storacha / web3.storage (w3up)

> **Current package**: `@storacha/client` (not `web3.storage` or `w3up-client` — those are deprecated/moved)

```bash
npm install @storacha/client
```

### Complete Runnable Example (JSON Upload)

```typescript
import { create } from '@storacha/client'

async function uploadJSON(data: object, spaceName = 'my-space') {
  const client = await create()

  // First-time setup: authenticate and create space
  // (Skip if already authenticated and space is set)
  const account = await client.login('your@email.com')
  await account.plan.wait()  // Confirm email, wait for plan activation
  const space = await client.createSpace(spaceName, { account })
  await client.setCurrentSpace(space.did())

  // Upload JSON as a Blob
  const blob = new Blob(
    [JSON.stringify(data, null, 2)],
    { type: 'application/json' }
  )

  const cid = await client.uploadFile(blob)
  console.log('CID:', cid.toString())
  console.log('URL:', `https://w3s.link/ipfs/${cid}`)
  return cid
}

// For subsequent calls (client persists auth locally):
async function uploadJSONFast(data: object) {
  const client = await create()  // Loads persisted auth from local store
  const blob = new Blob([JSON.stringify(data)], { type: 'application/json' })
  return client.uploadFile(blob)
}
```

**Key difference from Pinata**: Storacha uses decentralized identity (DIDs + UCANs). No JWT or API key in env vars — keys are stored in a local keystore (OS keychain / browser). This is more secure but more complex to set up in CI/serverless environments.

---

---

# PART 2: viem ENS Methods

---

## 1. getEnsText

Gets a text record for a specified ENS name. Internally calls `resolve(bytes, bytes)` on the ENS Universal Resolver Contract (CCIP-Read aware). ([viem docs](https://viem.sh/docs/ens/actions/getEnsText))

### Client Setup

```typescript
import { createPublicClient, http } from 'viem'
import { mainnet } from 'viem/chains'

const publicClient = createPublicClient({
  chain: mainnet,
  transport: http(),  // or http('https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY')
})
```

### Function Signature (as action method)

```typescript
publicClient.getEnsText({
  name: string,                    // Required: normalized ENS name
  key: string,                     // Required: text record key
  blockNumber?: bigint,            // Optional: specific block
  blockTag?: 'latest' | 'earliest' | 'pending' | 'safe' | 'finalized',  // default: 'latest'
  gatewayUrls?: string[],          // Optional: CCIP-Read gateway URLs
  strict?: boolean,                // Optional: throw on resolver errors (default: false)
  universalResolverAddress?: Address  // Optional: override Universal Resolver
}): Promise<string | null>
```

### Return Type

`Promise<string | null>` — `null` if the record is not set.

### How It Works Under the Hood

1. DNS-encodes the ENS name
2. ABI-encodes a call to `text(bytes32 node, string key)` on the resolver
3. Calls `resolve(bytes name, bytes data)` on the Universal Resolver
4. The Universal Resolver finds the name's resolver contract and forwards the call
5. Supports CCIP-Read (ERC-3668) for off-chain/L2 resolvers
6. Returns the decoded string value

### Common Text Record Keys (ENSIP-5)

| Key | Meaning |
|-----|---------|
| `com.twitter` | Twitter/X username |
| `com.github` | GitHub username |
| `com.discord` | Discord handle |
| `url` | Website URL |
| `email` | Email address |
| `description` | Bio/description |
| `avatar` | Avatar URL (IPFS, data URI, etc.) |
| `name` | Display name |
| `com.reddit` | Reddit username |
| Custom keys | Any `key.value` format (e.g., `org.myapp.metadata`) |

### Complete Examples

```typescript
import { createPublicClient, http } from 'viem'
import { mainnet } from 'viem/chains'
import { normalize } from 'viem/ens'

const client = createPublicClient({ chain: mainnet, transport: http() })

// Basic usage — always normalize the name first
const twitter = await client.getEnsText({
  name: normalize('wevm.eth'),
  key: 'com.twitter',
})
// 'wevm_dev' or null

// Read a custom key
const metadataUrl = await client.getEnsText({
  name: normalize('nick.eth'),
  key: 'url',
})

// At a specific block
const historical = await client.getEnsText({
  name: normalize('vitalik.eth'),
  key: 'description',
  blockNumber: 19000000n,
})

// With CCIP-Read gateway (for off-chain resolvers)
const ccip = await client.getEnsText({
  name: normalize('offchain.eth'),
  key: 'com.twitter',
  gatewayUrls: ['https://ccip.ens.xyz'],
})

// Strict mode: throws instead of returning null on resolver errors
try {
  const strict = await client.getEnsText({
    name: normalize('wevm.eth'),
    key: 'com.twitter',
    strict: true,
  })
} catch (err) {
  console.error('Resolver error:', err)
}

// Override Universal Resolver (for testing with older resolver)
const manual = await client.getEnsText({
  name: normalize('wevm.eth'),
  key: 'com.twitter',
  universalResolverAddress: '0x74E20Bd2A1fE0cdbe45b9A1d89cb7e0a45b36376',
})
```

**On Sepolia** (testing):
```typescript
import { sepolia } from 'viem/chains'

const sepoliaClient = createPublicClient({
  chain: sepolia,
  transport: http(),
})

// Same API, uses Sepolia's Universal Resolver automatically
const text = await sepoliaClient.getEnsText({
  name: normalize('mytest.eth'),
  key: 'url',
})
```

---

## 2. getEnsResolver

Gets the resolver contract address for an ENS name. Calls `findResolver(bytes)` on the Universal Resolver. ([viem docs](https://viem.sh/docs/ens/actions/getEnsResolver))

### Function Signature

```typescript
publicClient.getEnsResolver({
  name: string,
  blockNumber?: bigint,
  blockTag?: 'latest' | 'earliest' | 'pending' | 'safe' | 'finalized',
  universalResolverAddress?: Address
}): Promise<Address>
```

### Return Type

`Promise<Address>` — the address of the resolver contract. Throws if no resolver is found.

### How to Check if a Name Has a Resolver

```typescript
import { normalize } from 'viem/ens'

// Get resolver address
const resolverAddress = await client.getEnsResolver({
  name: normalize('wevm.eth'),
})
console.log(resolverAddress)
// '0x4976fb03C32e5B8cfe2b6cCB31c09Ba78EBaBa41'

// Check if it has a resolver (non-zero address)
function hasResolver(address: string): boolean {
  return address !== '0x0000000000000000000000000000000000000000'
}

// Safe check with error handling
async function getResolverSafe(name: string): Promise<string | null> {
  try {
    const resolver = await client.getEnsResolver({ name: normalize(name) })
    return hasResolver(resolver) ? resolver : null
  } catch {
    return null  // Name not registered or no resolver
  }
}

// Override Universal Resolver
const resolver = await client.getEnsResolver({
  name: normalize('wevm.eth'),
  universalResolverAddress: '0x74E20Bd2A1fE0cdbe45b9A1d89cb7e0a45b36376',
})

// At specific block
const historicalResolver = await client.getEnsResolver({
  name: normalize('wevm.eth'),
  blockNumber: 15121123n,
})
```

---

## 3. getEnsAddress

Resolves an ENS name to its Ethereum address (or address on another chain). ([viem docs](https://viem.sh/docs/ens/actions/getEnsAddress))

### Function Signature

```typescript
publicClient.getEnsAddress({
  name: string,
  blockNumber?: bigint,
  blockTag?: 'latest' | 'earliest' | 'pending' | 'safe' | 'finalized',
  coinType?: number,           // ENSIP-9 coin type for multi-chain
  gatewayUrls?: string[],
  strict?: boolean,
  universalResolverAddress?: Address
}): Promise<Address | null>
```

### Return Type

`Promise<Address | null>` — the resolved address or `null` if not set.

### Coin Type Parameter (Multi-Chain)

The `coinType` parameter follows [ENSIP-9](https://docs.ens.domains/ensip/9) for multi-chain address resolution. Use `toCoinType(chainId)` from `viem/ens` to convert an EVM chain ID.

| Chain | Coin Type |
|-------|-----------|
| Ethereum (default) | 60 (SLIP-44) |
| Bitcoin | 0 |
| Base | `toCoinType(8453)` |
| Arbitrum | `toCoinType(42161)` |
| Optimism | `toCoinType(10)` |

### Complete Examples

```typescript
import { createPublicClient, http } from 'viem'
import { mainnet, base } from 'viem/chains'
import { normalize, toCoinType } from 'viem/ens'

const client = createPublicClient({ chain: mainnet, transport: http() })

// Basic: resolve to Ethereum address
const address = await client.getEnsAddress({
  name: normalize('wevm.eth'),
})
// '0xd2135CfB216b74109775236E36d4b433F1DF507B' or null

// Multi-chain: resolve to Base address
const baseAddress = await client.getEnsAddress({
  name: normalize('test.ses.eth'),
  coinType: toCoinType(base.id),  // base.id = 8453
})

// Multi-chain with CCIP-Read gateway
const l2address = await client.getEnsAddress({
  name: normalize('myname.eth'),
  coinType: toCoinType(base.id),
  gatewayUrls: ['https://ccip.ens.xyz'],
})

// At specific block
const historical = await client.getEnsAddress({
  name: normalize('vitalik.eth'),
  blockNumber: 15000000n,
})

// Full null-safe pattern
const ensAddress = await client.getEnsAddress({ name: normalize('someone.eth') })
if (ensAddress === null) {
  console.log('No ETH address set for this name')
} else {
  console.log('Resolved:', ensAddress)
}
```

---

## 4. namehash and normalize

Both imported from `viem/ens`. ([viem normalize docs](https://viem.sh/docs/ens/utilities/normalize), [viem namehash docs](https://viem.sh/docs/ens/utilities/namehash))

### normalize()

Normalizes an ENS name according to **ENSIP-15** (which uses UTS-51 via `@adraffy/ens-normalize`). This is required before passing any name to ENS functions to prevent issues with invalid characters, homoglyphs, and encoding edge cases.

```typescript
import { normalize } from 'viem/ens'

// Signature
normalize(name: string): string  // Returns normalized string or throws on invalid name

// Examples
normalize('Vitalik.ETH')         // 'vitalik.eth'        (lowercase)
normalize('wagmi-d𝝣v.eth')       // 'wagmi-dξv.eth'      (emoji/unicode normalization)
normalize('wevm.eth')            // 'wevm.eth'           (already normalized)

// ALWAYS normalize before passing to ENS functions
const name = normalize('My.Name.ETH')  // 'my.name.eth'

// normalize throws on invalid names
try {
  normalize('_invalid.eth')  // Throws — underscore forbidden
} catch (err) {
  console.error('Invalid ENS name:', err)
}
```

**Why normalize?**: ENS names prohibit certain characters (underscores, etc.) and require specific Unicode handling. Passing un-normalized names to ENS contract calls can produce incorrect results or fail silently.

### namehash()

Computes the ENS node hash for a name — the `bytes32` identifier used in all ENS contracts internally.

```typescript
import { namehash, normalize } from 'viem/ens'

// Signature
namehash(name: string): `0x${string}`  // 32-byte hex hash

// Examples
namehash('wevm.eth')
// '0xf246651c1b9a6b141d19c2604e9a58f567973833990f830d882534a747801359'

namehash('eth')
// '0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae'

namehash('')
// '0x0000000000000000000000000000000000000000000000000000000000000000'

// Always normalize before hashing for consistent results
const node = namehash(normalize('Vitalik.ETH'))
```

**How namehash is computed** (EIP-137 algorithm):
```
namehash('') = 0x0000...0000
namehash('eth') = keccak256(namehash('') + keccak256('eth'))
namehash('wevm.eth') = keccak256(namehash('eth') + keccak256('wevm'))
```
Recursively: split on `.`, hash each label, combine from right to left.

### Practical Usage Together

```typescript
import { namehash, normalize } from 'viem/ens'

const ensName = 'vitalik.eth'
const normalized = normalize(ensName)  // 'vitalik.eth'
const node = namehash(normalized)      // '0xee6c4522aab0003e8d14cd40a6af439055fd2577951148c14b6cea9a53475835'

// node is what you pass to resolver contracts
// e.g., PublicResolver.setText(node, key, value)
```

---

## 5. Writing ENS Records via writeContract

To set ENS text records, you need to call `setText(bytes32 node, string key, string value)` on the **Public Resolver** contract that the name currently points to.

### Prerequisites

1. You own (or are authorized for) the ENS name
2. You know the resolver address (use `getEnsResolver` or the known Public Resolver address)
3. You have a wallet client (with a signer)

### ENS Public Resolver Addresses

| Network | Public Resolver Address |
|---------|------------------------|
| Mainnet | `0xF29100983E058B709F3D539b0c765937B804AC15` |
| Sepolia | `0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5` |

### Complete Runnable Example

```typescript
import { createPublicClient, createWalletClient, http, custom, parseAbi } from 'viem'
import { mainnet, sepolia } from 'viem/chains'
import { normalize, namehash } from 'viem/ens'
import { privateKeyToAccount } from 'viem/accounts'

// --- Client Setup ---
const publicClient = createPublicClient({
  chain: mainnet,  // or sepolia for testing
  transport: http(),
})

// Option A: Browser wallet (MetaMask)
const walletClient = createWalletClient({
  chain: mainnet,
  transport: custom(window.ethereum),
})
const [account] = await walletClient.getAddresses()

// Option B: Private key (server-side)
const account = privateKeyToAccount('0x...')
const walletClient = createWalletClient({
  chain: mainnet,
  transport: http(),
  account,
})

// --- setText ---

const ENS_NAME = 'yourname.eth'
const RESOLVER_ADDRESS = '0xF29100983E058B709F3D539b0c765937B804AC15'  // Mainnet Public Resolver

// Define the ABI inline with parseAbi
const resolverAbi = parseAbi([
  'function setText(bytes32 node, string calldata key, string calldata value) external',
  'function text(bytes32 node, string calldata key) external view returns (string memory)',
])

// Compute namehash
const node = namehash(normalize(ENS_NAME))

// Step 1: Simulate first (validates + gas estimate, no actual transaction)
const { request } = await publicClient.simulateContract({
  address: RESOLVER_ADDRESS,
  abi: resolverAbi,
  functionName: 'setText',
  args: [node, 'com.twitter', 'my_twitter_handle'],
  account,
})

// Step 2: Send the transaction
const txHash = await walletClient.writeContract(request)
console.log('Transaction hash:', txHash)

// Step 3: Wait for confirmation
const receipt = await publicClient.waitForTransactionReceipt({
  hash: txHash,
  confirmations: 1,
})
console.log('Status:', receipt.status)  // 'success' or 'reverted'

// --- Direct writeContract (skip simulation) ---
const hash = await walletClient.writeContract({
  address: RESOLVER_ADDRESS,
  abi: resolverAbi,
  functionName: 'setText',
  args: [node, 'url', 'https://mywebsite.com'],
  account,
  // Gas override (optional):
  // gas: 100000n,
  // maxFeePerGas: parseGwei('20'),
  // maxPriorityFeePerGas: parseGwei('2'),
})
```

### Setting Multiple Records in One Transaction (Multicall)

The Public Resolver supports `multicall(bytes[] calldata data)`:

```typescript
import { encodeFunctionData, parseAbi } from 'viem'
import { namehash, normalize } from 'viem/ens'

const resolverAbi = parseAbi([
  'function setText(bytes32 node, string calldata key, string calldata value) external',
  'function multicall(bytes[] calldata data) external returns (bytes[] memory results)',
])

const node = namehash(normalize('yourname.eth'))
const RESOLVER = '0xF29100983E058B709F3D539b0c765937B804AC15'

// Encode each setText call
const calls = [
  encodeFunctionData({
    abi: resolverAbi,
    functionName: 'setText',
    args: [node, 'com.twitter', 'my_twitter'],
  }),
  encodeFunctionData({
    abi: resolverAbi,
    functionName: 'setText',
    args: [node, 'url', 'https://example.com'],
  }),
  encodeFunctionData({
    abi: resolverAbi,
    functionName: 'setText',
    args: [node, 'description', 'My on-chain bio'],
  }),
]

// Send all in one transaction
const hash = await walletClient.writeContract({
  address: RESOLVER,
  abi: resolverAbi,
  functionName: 'multicall',
  args: [calls],
  account,
})
```

### Gas Estimation

```typescript
import { estimateContractGas } from 'viem'

const gasEstimate = await publicClient.estimateContractGas({
  address: RESOLVER_ADDRESS,
  abi: resolverAbi,
  functionName: 'setText',
  args: [node, 'com.twitter', 'handle'],
  account,
})
console.log('Gas estimate:', gasEstimate)  // bigint, e.g. 45000n

// Add 20% buffer
const gasWithBuffer = gasEstimate * 120n / 100n
```

---

## 6. viem Chain Configs & ENS Contract Addresses

### How viem Knows Which Universal Resolver to Use

Each chain object in `viem/chains` contains a `contracts` field with contract addresses. For ENS-supporting chains, this includes `ensUniversalResolver`. All ENS action methods (getEnsText, getEnsResolver, etc.) read from `client.chain.contracts.ensUniversalResolver.address` by default.

```typescript
import { mainnet, sepolia } from 'viem/chains'

// The chain objects include ENS contracts:
mainnet.contracts.ensUniversalResolver
// { address: '0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe', blockCreated: ... }

// viem internally does:
const resolverAddress = universalResolverAddress ?? client.chain?.contracts?.ensUniversalResolver?.address
```

### ENS Contract Addresses by Network

Source: [ENS Docs Deployments](https://docs.ens.domains/learn/deployments)

| Contract | Mainnet | Sepolia |
|----------|---------|---------|
| **Registry** | `0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e` | `0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e` |
| **Universal Resolver** | `0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe` | `0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe` |
| **Public Resolver** | `0xF29100983E058B709F3D539b0c765937B804AC15` | `0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5` |
| **Name Wrapper** | `0xD4416b13d2b3a9aBae7AcD5D6C2BbDBE25686401` | `0x0635513f179D50A207757E05759CbD106d7dFcE8` |
| **Base Registrar** | `0x57f1887a8BF19b14fC0dF6Fd9B2acc9Af147eA85` | `0x57f1887a8bf19b14fc0df6fd9b2acc9af147ea85` |
| **L1 Reverse Registrar** | `0xa58E81fe9b61B5c3fE2AFD33CF304c454AbFc7Cb` | `0xA0a1AbcDAe1a2a4A2EF8e9113Ff0e02DD81DC0C6` |

> **ENSv2 note**: The Universal Resolver at `0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe` is a **proxy contract owned by ENS DAO**. Its address will remain constant even as the underlying implementation is upgraded for ENSv2. This is the canonical address to use. ([ENS Docs](https://docs.ens.domains/resolvers/universal/))

### Setting Up Clients for Mainnet vs Sepolia

```typescript
import { createPublicClient, http } from 'viem'
import { mainnet, sepolia } from 'viem/chains'

// Mainnet — uses 0xeEeEEEeE... Universal Resolver automatically
const mainnetClient = createPublicClient({
  chain: mainnet,
  transport: http('https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY'),
})

// Sepolia — also uses 0xeEeEEEeE... Universal Resolver
const sepoliaClient = createPublicClient({
  chain: sepolia,
  transport: http('https://eth-sepolia.g.alchemy.com/v2/YOUR_KEY'),
})

// ENS read works identically on both
const mainnetText = await mainnetClient.getEnsText({
  name: normalize('vitalik.eth'),
  key: 'url',
})

const sepoliaText = await sepoliaClient.getEnsText({
  name: normalize('mytest.eth'),
  key: 'url',
})

// For ENSv2 + L2 resolution: always use a Mainnet client for ENS lookups
// even if your dapp operates on another chain
import { base } from 'viem/chains'
import { toCoinType } from 'viem/ens'

const l1Client = createPublicClient({ chain: mainnet, transport: http() })
const baseAddress = await l1Client.getEnsAddress({
  name: normalize('user.eth'),
  coinType: toCoinType(base.id),  // Get the Base address for this name
})
```

### Adding ENS Contracts to a Custom Chain

```typescript
import { defineChain } from 'viem'

const myChain = defineChain({
  id: 31337,
  name: 'Local',
  // ...
  contracts: {
    ensUniversalResolver: {
      address: '0x...your-local-universal-resolver...',
    },
    ensRegistry: {
      address: '0x...your-local-registry...',
    },
  },
})
```

---

## 7. keccak256, toHex, toBytes

All imported from `'viem'`. ([keccak256 docs](https://viem.sh/docs/utilities/keccak256), [toHex docs](https://viem.sh/docs/utilities/toHex), [toBytes docs](https://viem.sh/docs/utilities/toBytes))

### keccak256

```typescript
import { keccak256 } from 'viem'

// Signature
keccak256(value: Hex | ByteArray, to?: 'bytes' | 'hex'): Hex | ByteArray

// Accepts hex string
keccak256('0xdeadbeef')
// '0xd4fd4e189132273036449fc9e11198c739161b4c0116a9a2dccdfa1c492006f1'

// Accepts Uint8Array (ByteArray)
keccak256(new Uint8Array([72, 101, 108, 108, 111]))
// '0x06b3dfaec148fb1bb2b066f10ec285e7c9bf402ab32aa78a5d38e34566810cd2'

// Return as bytes instead of hex
keccak256(new Uint8Array([72, 101, 108, 108, 111]), 'bytes')
// Uint8Array [6, 179, ...]

// Hashing a JSON string (the correct pattern)
import { toHex } from 'viem'
const jsonString = JSON.stringify({ hello: 'world' })
const hash = keccak256(toHex(jsonString))
// Equivalent to: keccak256(stringToBytes(jsonString))

// Also works:
import { stringToBytes } from 'viem'
const hash2 = keccak256(stringToBytes(jsonString))
// Same result as above
```

**Important**: `keccak256` does NOT accept plain strings. You must convert a string to hex or bytes first:

```typescript
// WRONG - will throw or give unexpected results
keccak256('hello world')  // ❌

// CORRECT
keccak256(toHex('hello world'))    // ✅  converts UTF-8 string to hex, then hashes
keccak256(toBytes('hello world'))  // ✅  converts string to Uint8Array, then hashes
```

---

### toHex

```typescript
import { toHex, stringToHex, numberToHex, bytesToHex, boolToHex } from 'viem'

// Signature
toHex(value: string | number | bigint | ByteArray, options?: { size?: number }): Hex

// String → Hex (UTF-8 encoding)
toHex('Hello world')
// '0x48656c6c6f20776f726c64'

toHex('Hello world', { size: 32 })  // Right-padded to 32 bytes
// '0x48656c6c6f20776f726c640000000000000000000000000000000000000000000000'

// Number → Hex
toHex(420)           // '0x1a4'
toHex(420, { size: 4 }) // '0x000001a4'
toHex(420n)          // BigInt: '0x1a4'

// ByteArray → Hex
toHex(new Uint8Array([1, 2, 3]))  // '0x010203'

// Specific variants
stringToHex('Hello World!')   // '0x48656c6c6f20576f726c6421'
numberToHex(420)              // '0x1a4'
bytesToHex(new Uint8Array([1, 2, 3]))  // '0x010203'
boolToHex(true)               // '0x1'
```

---

### toBytes

```typescript
import { toBytes, stringToBytes, hexToBytes } from 'viem'

// Signature
toBytes(value: string | Hex, options?: { size?: number }): ByteArray  // Uint8Array

// String → bytes (UTF-8)
toBytes('Hello world')
// Uint8Array([72, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100])

// Hex → bytes
toBytes('0x48656c6c6f20576f726c6421')
// Uint8Array([72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33])

// With size padding
toBytes('Hello world', { size: 32 })
// Uint8Array of 32 bytes, right-padded with zeros

// Specific variants
stringToBytes('Hello world')                   // UTF-8 → Uint8Array
hexToBytes('0x48656c6c6f20576f726c6421')       // hex → Uint8Array
```

---

### Hashing a JSON String (Complete Pattern)

```typescript
import { keccak256, toHex, toBytes } from 'viem'
import stringify from 'json-stringify-deterministic'  // npm i json-stringify-deterministic

// For consistent CID/hash verification:
// 1. Deterministic serialization
const data = { timestamp: 1700000000, ipfsCid: 'bafkrei...' }
const jsonString = stringify(data)  // Keys sorted: { ipfsCid: ..., timestamp: ... }

// 2. Hash
const hash = keccak256(toHex(jsonString))
// or equivalently:
const hash2 = keccak256(toBytes(jsonString))

console.log(hash)   // '0x...' — 32-byte keccak256 hash of the JSON string

// Usage: store hash on-chain as proof of content
await walletClient.writeContract({
  address: myContractAddress,
  abi: parseAbi(['function storeHash(bytes32 hash) external']),
  functionName: 'storeHash',
  args: [hash as `0x${string}`],
  account,
})
```

---

## 8. parseAbi

Converts human-readable ABI strings to the JSON ABI format used by viem. ([viem docs](https://viem.sh/docs/abi/parseAbi))

### Function Signature

```typescript
import { parseAbi } from 'viem'

parseAbi(signatures: string[]): Abi
```

### Format Rules

| Type | Format |
|------|--------|
| Function | `'function name(type1 name1, type2 name2) [view|pure|payable] returns (type)'` |
| Event | `'event Name(type1 [indexed] name1, type2 name2)'` |
| Error | `'error Name(type1 name1)'` |
| Constructor | `'constructor(type1 name1) [payable]'` |

### Examples

```typescript
import { parseAbi } from 'viem'

// ERC-20 subset
const erc20Abi = parseAbi([
  'function balanceOf(address owner) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'event Transfer(address indexed from, address indexed to, uint256 amount)',
])

// ENS Public Resolver
const resolverAbi = parseAbi([
  'function text(bytes32 node, string calldata key) external view returns (string memory)',
  'function setText(bytes32 node, string calldata key, string calldata value) external',
  'function addr(bytes32 node) external view returns (address payable)',
  'function setAddr(bytes32 node, address addr) external',
  'function multicall(bytes[] calldata data) external returns (bytes[] memory results)',
])

// Custom contract with complex types
const myAbi = parseAbi([
  'function setRecord(bytes32 node, tuple(string key, string value)[] records) external',
  'function getRecord(bytes32 node, string key) view returns (string)',
  'error Unauthorized(address caller)',
  'event RecordSet(bytes32 indexed node, string key, string value)',
])

// Usage with readContract
const result = await publicClient.readContract({
  address: '0xF29100983E058B709F3D539b0c765937B804AC15',
  abi: parseAbi(['function text(bytes32 node, string calldata key) external view returns (string memory)']),
  functionName: 'text',
  args: [namehash(normalize('vitalik.eth')), 'url'],
})

// Usage with writeContract
await walletClient.writeContract({
  address: '0xF29100983E058B709F3D539b0c765937B804AC15',
  abi: parseAbi(['function setText(bytes32 node, string calldata key, string calldata value) external']),
  functionName: 'setText',
  args: [node, 'com.twitter', 'my_handle'],
  account,
})
```

---

## Complete Integration Example: Store JSON on IPFS → Record CID in ENS

This runnable example combines both halves — pinning JSON to IPFS via Pinata REST and writing the CID to an ENS text record via viem.

```typescript
import { createPublicClient, createWalletClient, http, custom, parseAbi } from 'viem'
import { mainnet } from 'viem/chains'
import { normalize, namehash } from 'viem/ens'
import { privateKeyToAccount } from 'viem/accounts'

// ---- Configuration ----
const ENS_NAME = 'yourname.eth'
const PINATA_JWT = process.env.PINATA_JWT!
const PRIVATE_KEY = process.env.PRIVATE_KEY as `0x${string}`
const PUBLIC_RESOLVER = '0xF29100983E058B709F3D539b0c765937B804AC15'

// ---- Clients ----
const account = privateKeyToAccount(PRIVATE_KEY)
const publicClient = createPublicClient({ chain: mainnet, transport: http() })
const walletClient = createWalletClient({ chain: mainnet, transport: http(), account })

// ---- Step 1: Pin JSON to IPFS via Pinata ----
async function pinJSON(data: object): Promise<string> {
  const res = await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${PINATA_JWT}`,
    },
    body: JSON.stringify({
      pinataContent: data,
      pinataMetadata: { name: 'ens-metadata.json' },
      pinataOptions: { cidVersion: 1 },
    }),
  })
  if (!res.ok) throw new Error(`Pinata: ${res.statusText}`)
  const json = await res.json()
  return json.IpfsHash  // e.g. 'bafkreih5aznjv...'
}

// ---- Step 2: Write CID to ENS text record ----
async function setEnsText(ensName: string, key: string, value: string) {
  const node = namehash(normalize(ensName))
  const abi = parseAbi([
    'function setText(bytes32 node, string calldata key, string calldata value) external',
  ])

  const { request } = await publicClient.simulateContract({
    address: PUBLIC_RESOLVER,
    abi,
    functionName: 'setText',
    args: [node, key, value],
    account,
  })

  const hash = await walletClient.writeContract(request)
  const receipt = await publicClient.waitForTransactionReceipt({ hash })
  return receipt
}

// ---- Main ----
async function main() {
  const metadata = {
    name: 'My Profile',
    description: 'On-chain metadata stored on IPFS',
    timestamp: Date.now(),
  }

  console.log('Pinning to IPFS...')
  const cid = await pinJSON(metadata)
  console.log('CID:', cid)  // bafkrei...

  const ipfsUri = `ipfs://${cid}`
  console.log('Writing to ENS...')
  const receipt = await setEnsText(ENS_NAME, 'url', ipfsUri)
  console.log('ENS record set! tx:', receipt.transactionHash)

  // Verify
  const stored = await publicClient.getEnsText({
    name: normalize(ENS_NAME),
    key: 'url',
  })
  console.log('Verified stored value:', stored)  // 'ipfs://bafkrei...'
}

main().catch(console.error)
```

---

## Quick Reference: Import Paths

```typescript
// Helia
import { createHelia } from 'helia'
import { unixfs } from '@helia/unixfs'
import { json } from '@helia/json'
import { strings } from '@helia/strings'
import { dagJson } from '@helia/dag-json'
import { dagCbor } from '@helia/dag-cbor'
import { CID } from 'multiformats/cid'
import { sha256 } from 'multiformats/hashes/sha2'

// Storacha
import { create } from '@storacha/client'

// viem core
import { createPublicClient, createWalletClient, http, custom, parseAbi } from 'viem'
import { mainnet, sepolia } from 'viem/chains'
import { privateKeyToAccount } from 'viem/accounts'

// viem ENS actions (available as publicClient methods when using ENS-compatible chain)
// publicClient.getEnsText(...)
// publicClient.getEnsResolver(...)
// publicClient.getEnsAddress(...)

// viem ENS utilities
import { normalize, namehash, toCoinType, packetToBytes } from 'viem/ens'

// viem utilities
import {
  keccak256,
  toHex, stringToHex, numberToHex, bytesToHex,
  toBytes, stringToBytes, hexToBytes,
} from 'viem'

// viem ABI
import { parseAbi, encodeFunctionData, decodeFunctionResult } from 'viem'
```

---

## Package Version Summary

| Package | Latest Version (Mar 2026) |
|---------|--------------------------|
| `helia` | 6.0.20 |
| `@helia/unixfs` | 5.1.0 |
| `@helia/mfs` | 7.0.4 |
| `@helia/json` | (check npm) |
| `@helia/strings` | (check npm) |
| `@helia/ipns` | (check npm) |
| `viem` | 2.x (check npm for latest) |
| `@storacha/client` | (check npm) |
| `pinata` | (check npm) |
| `multiformats` | (check npm) |

---

*Sources: [Helia GitHub](https://github.com/ipfs/helia) · [Helia Migration Wiki](https://github.com/ipfs/helia/wiki/Migrating-from-js-IPFS) · [npm/helia](https://www.npmjs.com/package/helia) · [npm/@helia/unixfs](https://www.npmjs.com/package/@helia/unixfs) · [viem docs](https://viem.sh/docs/ens/actions/getEnsText) · [ENS Deployments](https://docs.ens.domains/learn/deployments) · [ENS Universal Resolver](https://docs.ens.domains/resolvers/universal/) · [Pinata Docs](https://docs.pinata.cloud/api-reference/endpoint/ipfs/pin-json-to-ipfs) · [Storacha/web3.storage JS Client](https://docs.storacha.network/js-client/) · [IPFS CID concepts](https://docs.ipfs.tech/concepts/content-addressing/) · [js-ipfs deprecation tracking](https://github.com/ipfs/js-ipfs/issues/4336)*
