# ENSIP-25 & ENS Deep Research
> Exhaustive reference for hackathon builds involving AI agent identity, ENSIP-25, ERC-7930, ENS text records, and on-chain resolver mechanics.
> 
> **Sources**: [ENSIP-25 spec](https://docs.ens.domains/ensip/25) · [ENS Blog: ENSIP-25](https://ens.domains/blog/post/ensip-25) · [ERC-7930](https://eips.ethereum.org/EIPS/eip-7930) · [ENSIP-5](https://docs.ens.domains/ensip/5) · [ENS Deployments](https://docs.ens.domains/learn/deployments) · [Universal Resolver](https://docs.ens.domains/resolvers/universal) · [ENS Resolver Interaction](https://docs.ens.domains/resolvers/interacting) · [ERC-8004](https://eips.ethereum.org/EIPS/eip-8004)

---

## Table of Contents
1. [ENSIP-25 Full Specification](#1-ensip-25-full-specification)
2. [ERC-7930 Interoperable Address Encoding](#2-erc-7930-interoperable-address-encoding)
3. [ENSIP-25 Text Record Format](#3-ensip-25-text-record-format)
4. [ENS setText Mechanics (viem)](#4-ens-settext-mechanics-viem)
5. [ENS Sepolia Testnet](#5-ens-sepolia-testnet)
6. [ENS Public Resolver Details](#6-ens-public-resolver-details)
7. [ENS Universal Resolver](#7-ens-universal-resolver)
8. [Custom Text Record Best Practices](#8-custom-text-record-best-practices)
9. [ENSIP-5 Text Records Spec](#9-ensip-5-text-records-spec)
10. [ENS Subname Mechanics](#10-ens-subname-mechanics)
11. [ERC-8004 AI Agent Registry Context](#11-erc-8004-ai-agent-registry-context)

---

## 1. ENSIP-25 Full Specification

**Source**: https://docs.ens.domains/ensip/25  
**Blog**: https://ens.domains/blog/post/ensip-25  
**Authors**: premm.eth, raffy.eth, workemon.eth, ses.eth  
**Created**: October 2, 2025  
**Status**: Draft

### 1.1 Abstract

ENSIP-25 defines a standardized method for directly verifying, using ENS text records, the association between an ENS name and an AI agent identity registered in a specific on-chain AI agent registry (such as ERC-8004). It establishes a **bidirectional verification** pattern: the registry entry declares an ENS name, and the ENS name owner confirms the link by setting a text record.

### 1.2 Motivation

With on-chain AI agent identity registries (ERC-8004), agents may declare an associated ENS name. A standardized verification method is needed to establish trust between an AI agent identity and the ENS name it claims. ENSIP-25 defines a direct lookup method using a parameterized text record key that includes a unique agent identifier—no new resolver upgrades or registry-specific integrations required.

### 1.3 Core Spec: Parameterized Verification Text Record Key

```
agent-registration[<registry>][<agentId>]
```

**Parameters:**

| Parameter | Description |
|-----------|-------------|
| `<registry>` | The ERC-7930 interoperable address of the registry contract (hex string with `0x` prefix) |
| `<agentId>` | The registry-defined agent identifier (string). MUST NOT contain `[` or `]` characters |

**Value:** MUST be a non-empty string. Implementations SHOULD set the value to `"1"`. The specific value has no semantic meaning — the presence of a non-empty value is the attestation. Verification clients MUST NOT depend on the specific value beyond it being non-empty.

### 1.4 Verification Flow (Registry-to-ENS)

Steps clients MUST follow:

1. Obtain the claimed ENS name, agent identifier, and registry address from the AI agent registry entry
2. Construct the text record key: `agent-registration[<registry>][<agentId>]`
3. Resolve the text record with this key on the claimed ENS name
4. If the resolved value is **non-empty** → ENS name is **verified** for that specific agent registry entry

If the text record does not exist or resolves to an empty value, verification **MUST fail**.

### 1.5 Three Verification Scenarios

| Scenario | Registry lists ENS? | ENS has text record? | Result |
|----------|--------------------|--------------------|--------|
| Full verification | ✅ Yes | ✅ Yes | ✅ **Verified** |
| One-sided (registry only) | ✅ Yes | ❌ No | ❌ **Not verified** |
| One-sided (ENS only) | ❌ No | ✅ Yes | ❌ **Not verified** (stale/incorrect) |

### 1.6 Ethereum Example (Canonical)

For the ERC-8004 registry at `0x8004A169FB4a3325136EB29fA0ceB6D2e539a432` on Ethereum mainnet (chain ID 1):

**ERC-7930 encoding of the registry address:**
```
0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432
```

**Text record key for agent ID `167`:**
```
agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][167]
```

**Text record key for agent ID `42`:**
```
agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][42]
```

**Text record value (set this on the ENS name):**
```
1
```

### 1.7 Registry Compatibility Requirements

Registries using ENSIP-25 MUST:
- Assign **stable identifiers** to agent registrations
- Allow an ENS name to be declared as part of the agent's metadata (on-chain or off-chain)
- Document how agent identifiers and claimed ENS names are obtained

### 1.8 Rationale

- Leverages existing ENS text records without requiring resolver upgrades or registry-specific integrations
- Embedding registry entry identifier directly into the text record key enables deterministic verification from known inputs using a single resolver lookup
- Registry component encoded as ERC-7930 interoperable address → combines chain identification and registry contract address into canonical representation → unambiguous registry identification across chains

### 1.9 Security Considerations

- If an ENS name is transferred to a new owner, any existing verification text records may become **stale**
- Clients SHOULD consider ENS name ownership changes when evaluating the validity of prior attestations
- Clients MAY apply additional freshness or revocation checks

---

## 2. ERC-7930 Interoperable Address Encoding

**Source**: https://eips.ethereum.org/EIPS/eip-7930  
**Status**: Draft Standard Track (ERC)  
**Created**: 2025-02-02

### 2.1 Abstract

ERC-7930 defines a **versioned, length-prefixed binary envelope** to describe a chain-specific address. It binds together chain identification and the raw address in a compact format suitable for on-chain use.

### 2.2 Binary Format

```
┌─────────┬───────────┬──────────────────────┬────────────────┬───────────────┬─────────┐
│ Version │ ChainType │ ChainReferenceLength │ ChainReference │ AddressLength │ Address │
└─────────┴───────────┴──────────────────────┴────────────────┴───────────────┴─────────┘
```

| Field | Size | Description |
|-------|------|-------------|
| **Version** | 2 bytes | Version identifier. For version 1: `0x0001` (big-endian) |
| **ChainType** | 2 bytes | CASA namespace value. EVM/EIP-155 = `0x0000` |
| **ChainReferenceLength** | 1 byte | Length of ChainReference in bytes. MAY be zero |
| **ChainReference** | Variable | Binary representation of the CAIP-350 chain reference |
| **AddressLength** | 1 byte | Length of Address in bytes. MAY be zero (but NOT if ChainReferenceLength is also zero) |
| **Address** | Variable | Binary encoding of the address |

### 2.3 Step-by-Step Encoding of `eip155:1:0x8004A169FB4a3325136EB29fA0ceB6D2e539a432`

This is the ERC-8004 IdentityRegistry on Ethereum mainnet (chain ID 1).

**Step 1: Version**
- Version 1 → `0x0001`

**Step 2: ChainType**
- EVM/EIP-155 namespace → `0x0000`

**Step 3: ChainReferenceLength**
- Chain ID = 1 → fits in 1 byte → length = `0x01`

**Step 4: ChainReference**
- Chain ID 1 as big-endian bytes → `0x01`

**Step 5: AddressLength**
- EVM address is 20 bytes → `0x14` (= 20 in hex)

**Step 6: Address**
- Lowercase hex (no `0x` prefix): `8004a169fb4a3325136eb29fa0ceb6d2e539a432`

**Final Assembly:**
```
0x 0001 0000 01 01 14 8004a169fb4a3325136eb29fa0ceb6d2e539a432
   ^^^^ ^^^^ ^^ ^^ ^^ ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   |    |    |  |  |  Address (20 bytes)
   |    |    |  |  AddressLength = 0x14 (20)
   |    |    |  ChainReference = 0x01 (chain ID 1)
   |    |    ChainReferenceLength = 0x01
   |    ChainType = 0x0000 (EVM/EIP-155)
   Version = 0x0001
```

**Result:**
```
0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432
```

This matches the canonical encoding in the ENSIP-25 spec exactly.

### 2.4 More Examples

#### Ethereum mainnet address (vitalik.eth → `0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045`)

```
0x00010000010114d8da6bf26964af9d7eed9e03e53415d37aa96045
  ^^^^                                                    Version (0x0001)
      ^^^^                                                ChainType (0x0000 = EVM)
          ^^                                              ChainReferenceLength (0x01 = 1 byte)
            ^^                                            ChainReference (0x01 = chain ID 1)
              ^^                                          AddressLength (0x14 = 20)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  Address (20 bytes)
```

#### EVM address without chain reference

```
0x000100000014d8da6bf26964af9d7eed9e03e53415d37aa96045
  ^^^^                                                  Version
      ^^^^                                              ChainType
          ^^                                            ChainReferenceLength (0x00 = 0)
            ^^                                          AddressLength (0x14 = 20)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  Address
```

### 2.5 ChainType Values

| ChainType | Namespace | Description |
|-----------|-----------|-------------|
| `0x0000` | EVM (EIP-155) | Ethereum and EVM-compatible chains |
| `0x0002` | Solana | Solana mainnet/testnet |

### 2.6 Chain ID Encoding for Common EVM Networks

| Network | Chain ID | ChainReference (hex) | ChainReferenceLength |
|---------|----------|---------------------|---------------------|
| Ethereum Mainnet | 1 | `0x01` | `0x01` |
| Sepolia | 11155111 | `0xaa36a7` | `0x03` |
| Holesky | 17000 | `0x4268` | `0x02` |
| Polygon | 137 | `0x89` | `0x01` |
| Arbitrum | 42161 | `0xa4b1` | `0x02` |

### 2.7 Encoding Algorithm (JavaScript/TypeScript)

```typescript
function encodeERC7930(chainId: number, address: string): string {
  // Remove 0x prefix and lowercase
  const addrBytes = address.replace('0x', '').toLowerCase();
  
  // Encode chain ID as minimal big-endian bytes
  let chainHex = chainId.toString(16);
  if (chainHex.length % 2 !== 0) chainHex = '0' + chainHex;
  const chainRefLength = chainHex.length / 2;
  
  const version = '0001';
  const chainType = '0000'; // EVM
  const chainRefLen = chainRefLength.toString(16).padStart(2, '0');
  const addrLen = '14'; // 20 bytes always for EVM
  
  return '0x' + version + chainType + chainRefLen + chainHex + addrLen + addrBytes;
}

// Example
encodeERC7930(1, '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432');
// → '0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432'

encodeERC7930(11155111, '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432');
// → '0x00010000 03 aa36a7 14 8004a169fb4a3325136eb29fa0ceb6d2e539a432'
//   (Sepolia version)
```

---

## 3. ENSIP-25 Text Record Format

### 3.1 Exact Key Format

```
agent-registration[<encoded-registry>][<agentId>]
```

**Critical syntax rules:**
- Square brackets `[` and `]` are literal characters in the key
- `<encoded-registry>` is the **full hex string** of the ERC-7930 interoperable address, including `0x` prefix
- `<agentId>` is the registry-assigned identifier (typically a uint256 tokenId, but can be any string)
- `<agentId>` **MUST NOT** contain `[` or `]` characters
- The combination of `<encoded-registry>` and `<agentId>` must uniquely identify an agent

### 3.2 Canonical Real-World Example

Registry: `0x8004A169FB4a3325136EB29fA0ceB6D2e539a432` (ERC-8004 on mainnet, chain ID 1)

ERC-7930 encoding: `0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432`

Agent IDs and their keys:

```
# Agent ID 42
agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][42]

# Agent ID 167
agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][167]

# Agent ID 1
agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][1]
```

### 3.3 Value Format

```
"1"
```

- RECOMMENDED value is `"1"`
- ANY non-empty string is valid
- Empty string = verification FAILS
- No semantic meaning in the specific value content

### 3.4 Building the Key Programmatically (TypeScript)

```typescript
import { normalize, namehash } from 'viem/ens';

function buildAgentRegistrationKey(
  registryAddress: string,  // e.g. "0x8004A169..."
  chainId: number,          // e.g. 1
  agentId: string | number  // e.g. 42
): string {
  const erc7930 = encodeERC7930(chainId, registryAddress);
  return `agent-registration[${erc7930}][${agentId}]`;
}

// For Sepolia (chain ID 11155111):
function buildAgentKeyForSepolia(registryAddress: string, agentId: string | number): string {
  const erc7930 = encodeERC7930(11155111, registryAddress);
  return `agent-registration[${erc7930}][${agentId}]`;
}
```

### 3.5 Reading the Record (viem)

```typescript
import { createPublicClient, http } from 'viem';
import { mainnet } from 'viem/chains';
import { normalize } from 'viem/ens';

const client = createPublicClient({ chain: mainnet, transport: http() });

const key = 'agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][42]';

const value = await client.getEnsText({
  name: normalize('myagent.eth'),
  key,
});

const isVerified = value !== null && value !== '';
console.log('Verified:', isVerified);  // true if value is set and non-empty
```

---

## 4. ENS setText Mechanics (viem)

### 4.1 Public Resolver setText Interface

```solidity
interface ITextResolver {
    function setText(bytes32 node, string calldata key, string calldata value) external;
    function text(bytes32 node, string calldata key) external view returns (string memory);
}
```

**EIP-165 Interface ID for text resolution**: `0x59d1d43c`

### 4.2 Full setText ABI Fragment

```json
[
  {
    "inputs": [
      { "name": "node", "type": "bytes32" },
      { "name": "key", "type": "string" },
      { "name": "value", "type": "string" }
    ],
    "name": "setText",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "name": "node", "type": "bytes32" },
      { "name": "key", "type": "string" }
    ],
    "name": "text",
    "outputs": [
      { "name": "", "type": "string" }
    ],
    "stateMutability": "view",
    "type": "function"
  }
]
```

### 4.3 Complete Public Resolver ABI (Key Functions)

```json
[
  // Address resolution
  { "inputs": [{"name": "node", "type": "bytes32"}], "name": "addr", "outputs": [{"name": "", "type": "address"}], "stateMutability": "view", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "coinType", "type": "uint256"}], "name": "addr", "outputs": [{"name": "", "type": "bytes"}], "stateMutability": "view", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "a", "type": "address"}], "name": "setAddr", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "coinType", "type": "uint256"}, {"name": "a", "type": "bytes"}], "name": "setAddr", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  
  // Text records
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "key", "type": "string"}], "name": "text", "outputs": [{"name": "", "type": "string"}], "stateMutability": "view", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "key", "type": "string"}, {"name": "value", "type": "string"}], "name": "setText", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  
  // Content hash
  { "inputs": [{"name": "node", "type": "bytes32"}], "name": "contenthash", "outputs": [{"name": "", "type": "bytes"}], "stateMutability": "view", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "hash", "type": "bytes"}], "name": "setContenthash", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  
  // Name (reverse)
  { "inputs": [{"name": "node", "type": "bytes32"}], "name": "name", "outputs": [{"name": "", "type": "string"}], "stateMutability": "view", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "_name", "type": "string"}], "name": "setName", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  
  // ABI
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "contentTypes", "type": "uint256"}], "name": "ABI", "outputs": [{"name": "", "type": "uint256"}, {"name": "", "type": "bytes"}], "stateMutability": "view", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "contentType", "type": "uint256"}, {"name": "data", "type": "bytes"}], "name": "setABI", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  
  // Pubkey
  { "inputs": [{"name": "node", "type": "bytes32"}], "name": "pubkey", "outputs": [{"name": "x", "type": "bytes32"}, {"name": "y", "type": "bytes32"}], "stateMutability": "view", "type": "function" },
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "x", "type": "bytes32"}, {"name": "y", "type": "bytes32"}], "name": "setPubkey", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  
  // Interface detection
  { "inputs": [{"name": "interfaceID", "type": "bytes4"}], "name": "supportsInterface", "outputs": [{"name": "", "type": "bool"}], "stateMutability": "pure", "type": "function" },
  
  // Authorisation (older PublicResolver pattern)
  { "inputs": [{"name": "node", "type": "bytes32"}, {"name": "target", "type": "address"}, {"name": "isAuthorised", "type": "bool"}], "name": "setAuthorisation", "outputs": [], "stateMutability": "nonpayable", "type": "function" },
  
  // Multicall
  { "inputs": [{"name": "data", "type": "bytes[]"}], "name": "multicall", "outputs": [{"name": "results", "type": "bytes[]"}], "stateMutability": "nonpayable", "type": "function" },
  
  // Events
  { "anonymous": false, "inputs": [{"indexed": true, "name": "node", "type": "bytes32"}, {"indexed": true, "name": "indexedKey", "type": "string"}, {"indexed": false, "name": "key", "type": "string"}, {"indexed": false, "name": "value", "type": "string"}], "name": "TextChanged", "type": "event" },
  { "anonymous": false, "inputs": [{"indexed": true, "name": "node", "type": "bytes32"}, {"indexed": false, "name": "a", "type": "address"}], "name": "AddrChanged", "type": "event" }
]
```

### 4.4 How to Call setText via viem

#### Method 1: Direct writeContract (recommended)

```typescript
import { createWalletClient, createPublicClient, http } from 'viem';
import { mainnet } from 'viem/chains';
import { privateKeyToAccount } from 'viem/accounts';
import { namehash, normalize } from 'viem/ens';

const PUBLIC_RESOLVER_MAINNET = '0xF29100983E058B709F3D539b0c765937B804AC15';
const PUBLIC_RESOLVER_SEPOLIA = '0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5';

const resolverAbi = [
  {
    inputs: [
      { name: 'node', type: 'bytes32' },
      { name: 'key', type: 'string' },
      { name: 'value', type: 'string' }
    ],
    name: 'setText',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function'
  }
] as const;

const account = privateKeyToAccount('0xYOUR_PRIVATE_KEY');

const walletClient = createWalletClient({
  account,
  chain: mainnet,
  transport: http('https://your-rpc-url'),
});

const publicClient = createPublicClient({
  chain: mainnet,
  transport: http('https://your-rpc-url'),
});

// The ENS name you own
const ensName = normalize('myagent.eth');
const node = namehash(ensName);

// The ENSIP-25 text record key
const key = 'agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][42]';
const value = '1';

// Simulate first to check for errors
const { request } = await publicClient.simulateContract({
  address: PUBLIC_RESOLVER_MAINNET,
  abi: resolverAbi,
  functionName: 'setText',
  account,
  args: [node, key, value],
});

// Then write
const txHash = await walletClient.writeContract(request);
console.log('Transaction hash:', txHash);

// Wait for receipt
const receipt = await publicClient.waitForTransactionReceipt({ hash: txHash });
console.log('Confirmed in block:', receipt.blockNumber);
```

#### Method 2: Using multicall to set multiple records atomically

```typescript
import { encodeFunctionData, parseAbi } from 'viem';

const resolverAbi = parseAbi([
  'function setText(bytes32 node, string key, string value) external',
  'function setAddr(bytes32 node, address a) external',
  'function multicall(bytes[] data) external returns (bytes[] results)',
]);

const node = namehash(normalize('myagent.eth'));

const calls = [
  encodeFunctionData({
    abi: resolverAbi,
    functionName: 'setText',
    args: [node, 'agent-registration[0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432][42]', '1'],
  }),
  encodeFunctionData({
    abi: resolverAbi,
    functionName: 'setText',
    args: [node, 'description', 'AI research agent'],
  }),
];

const { request } = await publicClient.simulateContract({
  address: PUBLIC_RESOLVER_MAINNET,
  abi: resolverAbi,
  functionName: 'multicall',
  account,
  args: [calls],
});

const txHash = await walletClient.writeContract(request);
```

### 4.5 Gas Costs for setText

Gas costs depend on the length of the key and value strings (stored as dynamic-length strings on-chain).

| Operation | Approximate Gas Units | Notes |
|-----------|----------------------|-------|
| `setText` (short key + value) | ~45,000–55,000 | Short key like `avatar` + URL value |
| `setText` (ENSIP-25 key) | ~65,000–85,000 | Key is ~85 chars, value is `"1"` |
| `setText` (update existing) | ~30,000–40,000 | Updating an existing value (overwriting, cheaper storage) |
| `multicall` (3 records) | ~120,000–180,000 | Batch setting multiple records |

**Cost estimation at typical gas prices:**

| Network | Gas Price | setText cost (ENSIP-25 key) |
|---------|-----------|---------------------------|
| Mainnet (10 gwei) | 10 gwei | ~0.0007 ETH (~$2) |
| Mainnet (30 gwei) | 30 gwei | ~0.002 ETH (~$6) |
| Sepolia | Near-zero | Essentially free (testnet ETH) |

> **Note**: These are estimates. Always use `estimateContractGas` or `simulateContract` before submitting. The ENSIP-25 key is approximately 85 characters long, which adds to calldata and storage costs compared to short keys.

### 4.6 Who Can Call setText (Permissions)

**The rules differ for wrapped vs unwrapped names:**

#### Unwrapped Names
```
Manager = registry.owner(node)
```

The **owner/manager** of the name in the ENS Registry can call setText. Find this by:
```typescript
const manager = await publicClient.readContract({
  address: ENS_REGISTRY,  // 0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e
  abi: [{ inputs: [{name:'node',type:'bytes32'}], name:'owner', outputs:[{name:'',type:'address'}], stateMutability:'view', type:'function' }],
  functionName: 'owner',
  args: [namehash(normalize('myagent.eth'))],
});
```

The public resolver also supports **per-name authorisations** (older pattern):
```solidity
// Owner can authorise another address
function setAuthorisation(bytes32 node, address target, bool isAuthorised) external;

// This checks: owner == msg.sender || authorisations[node][owner][msg.sender]
function isAuthorised(bytes32 node) internal view returns(bool);
```

#### Wrapped Names (NameWrapper)
```
Manager = nameWrapper.ownerOf(tokenId)
```

The **owner** of the ERC-1155 token in the NameWrapper can call setText. The NameWrapper also supports `setApprovalForAll` (ERC-1155 operator approval).

### 4.7 How to Check Write Access

```typescript
import { namehash, normalize } from 'viem/ens';

const ENS_REGISTRY = '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e';
const NAME_WRAPPER_MAINNET = '0xD4416b13d2b3a9aBae7AcD5D6C2BbDBE25686401';
const NAME_WRAPPER_SEPOLIA = '0x0635513f179D50A207757E05759CbD106d7dFcE8';

async function checkWriteAccess(ensName: string, walletAddress: string): Promise<boolean> {
  const node = namehash(normalize(ensName));
  
  // Step 1: Check registry owner
  const registryOwner = await publicClient.readContract({
    address: ENS_REGISTRY,
    abi: [{ inputs:[{name:'node',type:'bytes32'}], name:'owner', outputs:[{name:'',type:'address'}], stateMutability:'view', type:'function' }],
    functionName: 'owner',
    args: [node],
  });
  
  // Step 2: If registry owner is NameWrapper → name is wrapped
  const isWrapped = registryOwner.toLowerCase() === NAME_WRAPPER_MAINNET.toLowerCase();
  
  if (isWrapped) {
    // For wrapped names, check ERC-1155 ownership
    const tokenId = BigInt(node);
    const wrappedOwner = await publicClient.readContract({
      address: NAME_WRAPPER_MAINNET,
      abi: [{ inputs:[{name:'id',type:'uint256'}], name:'ownerOf', outputs:[{name:'',type:'address'}], stateMutability:'view', type:'function' }],
      functionName: 'ownerOf',
      args: [tokenId],
    });
    return wrappedOwner.toLowerCase() === walletAddress.toLowerCase();
  } else {
    // For unwrapped names, check registry owner directly
    return registryOwner.toLowerCase() === walletAddress.toLowerCase();
  }
}
```

---

## 5. ENS Sepolia Testnet

### 5.1 Contract Addresses on Sepolia

**Source**: https://docs.ens.domains/learn/deployments

| Contract | Sepolia Address |
|----------|----------------|
| **Registry** | `0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e` |
| **Base Registrar** | `0x57f1887a8bf19b14fc0df6fd9b2acc9af147ea85` |
| **ETH Registrar Controller** | `0xfb3cE5D01e0f33f41DbB39035dB9745962F1f968` |
| **DNS Registrar** | `0x5a07C75Ae469Bf3ee2657B588e8E6ABAC6741b4f` |
| **L1 Reverse Registrar** | `0xA0a1AbcDAe1a2a4A2EF8e9113Ff0e02DD81DC0C6` |
| **Default Reverse Registrar** | `0x4F382928805ba0e23B30cFB75fC9E848e82DFD47` |
| **Name Wrapper** | `0x0635513f179D50A207757E05759CbD106d7dFcE8` |
| **Public Resolver** | `0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5` |
| **Universal Resolver** | `0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe` |

> The Registry address (`0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e`) is **identical** on mainnet, Sepolia, and Holesky.
> The Universal Resolver address (`0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe`) is also **identical** across networks.

### 5.2 How to Register a Name on Sepolia

The registration flow uses a **commit-reveal scheme** (prevents front-running):

1. **Generate secret** and create commitment hash
2. **Call `commit(bytes32 commitment)`** on ETHRegistrarController → wait 1 minute minimum
3. **Call `register(...)`** with the full parameters

```typescript
import { createWalletClient, createPublicClient, http, parseAbi } from 'viem';
import { sepolia } from 'viem/chains';
import { privateKeyToAccount } from 'viem/accounts';
import { normalize } from 'viem/ens';

const ETH_REGISTRAR_CONTROLLER_SEPOLIA = '0xfb3cE5D01e0f33f41DbB39035dB9745962F1f968';
const PUBLIC_RESOLVER_SEPOLIA = '0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5';

const registrarAbi = parseAbi([
  'function makeCommitment(string name, address owner, uint256 duration, bytes32 secret, address resolver, bytes[] data, bool reverseRecord, uint32 ownerControlledFuses) pure returns (bytes32)',
  'function commit(bytes32 commitment) external',
  'function register(string name, address owner, uint256 duration, bytes32 secret, address resolver, bytes[] data, bool reverseRecord, uint32 ownerControlledFuses) external payable',
  'function rentPrice(string name, uint256 duration) view returns (uint256 base, uint256 premium)',
  'function minCommitmentAge() view returns (uint256)',
]);

const account = privateKeyToAccount('0xYOUR_PRIVATE_KEY');
const walletClient = createWalletClient({ account, chain: sepolia, transport: http() });
const publicClient = createPublicClient({ chain: sepolia, transport: http() });

async function registerENSName(label: string) {
  // label = just the name part, e.g. "myagent" for myagent.eth
  const secret = `0x${crypto.getRandomValues(new Uint8Array(32)).reduce((acc, b) => acc + b.toString(16).padStart(2, '0'), '')}` as `0x${string}`;
  
  // Step 1: Create commitment
  const commitment = await publicClient.readContract({
    address: ETH_REGISTRAR_CONTROLLER_SEPOLIA,
    abi: registrarAbi,
    functionName: 'makeCommitment',
    args: [
      label,                  // "myagent" (not "myagent.eth")
      account.address,        // owner
      BigInt(365 * 24 * 3600), // duration: 1 year in seconds
      secret,
      PUBLIC_RESOLVER_SEPOLIA,
      [],                     // data: empty (no resolver records on registration)
      false,                  // reverseRecord
      0,                      // ownerControlledFuses
    ],
  });
  
  // Step 2: Commit
  const commitHash = await walletClient.writeContract({
    address: ETH_REGISTRAR_CONTROLLER_SEPOLIA,
    abi: registrarAbi,
    functionName: 'commit',
    args: [commitment],
  });
  
  console.log('Committed. Waiting 60 seconds...');
  await publicClient.waitForTransactionReceipt({ hash: commitHash });
  await new Promise(r => setTimeout(r, 65000)); // Wait 65 seconds
  
  // Step 3: Get price
  const { base, premium } = await publicClient.readContract({
    address: ETH_REGISTRAR_CONTROLLER_SEPOLIA,
    abi: registrarAbi,
    functionName: 'rentPrice',
    args: [label, BigInt(365 * 24 * 3600)],
  });
  const totalPrice = (base + premium) * BigInt(110) / BigInt(100); // 10% buffer
  
  // Step 4: Register
  const regHash = await walletClient.writeContract({
    address: ETH_REGISTRAR_CONTROLLER_SEPOLIA,
    abi: registrarAbi,
    functionName: 'register',
    args: [label, account.address, BigInt(365 * 24 * 3600), secret, PUBLIC_RESOLVER_SEPOLIA, [], false, 0],
    value: totalPrice,
  });
  
  await publicClient.waitForTransactionReceipt({ hash: regHash });
  console.log(`${label}.eth registered!`);
}
```

### 5.3 Sepolia ETH Faucets

| Faucet | Amount | Frequency |
|--------|--------|-----------|
| Google Cloud Faucet | 0.05 ETH | Per 24 hours |
| Chainlink Faucet | 0.1 ETH | Per 24 hours |
| ENS Manager App | Built-in | Via sepolia.app.ens.domains |
| Alchemy Sepolia Faucet | 0.5 ETH | Per day |

**ENS Sepolia Manager App**: https://sepolia.app.ens.domains

You can register `.eth` names on Sepolia through the standard ENS Manager interface — it supports the same commit-reveal flow with testnet ETH. Names on Sepolia are free (near-zero cost in SepoliaETH).

### 5.4 Does viem Handle Sepolia ENS Automatically?

Yes. viem has built-in chain definitions for both `mainnet` and `sepolia` that include the correct ENS contract addresses. When you create a client with `chain: sepolia`, ENS actions automatically use the Sepolia contracts:

```typescript
import { createPublicClient, http } from 'viem';
import { sepolia } from 'viem/chains';
import { normalize } from 'viem/ens';

// viem automatically uses Sepolia ENS contracts
const client = createPublicClient({
  chain: sepolia,
  transport: http(),
});

// getEnsText uses the Sepolia Universal Resolver automatically
const value = await client.getEnsText({
  name: normalize('mytest.eth'),
  key: 'description',
});
```

The `sepolia` chain object in viem contains:
```typescript
contracts: {
  ensUniversalResolver: {
    address: '0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe',
    blockCreated: 5717187,
  }
}
```

---

## 6. ENS Public Resolver Details

**Source**: https://docs.ens.domains/resolvers/public/

### 6.1 Contract Addresses

| Network | Public Resolver Address |
|---------|------------------------|
| **Mainnet** | `0xF29100983E058B709F3D539b0c765937B804AC15` (latest) |
| **Mainnet** (older, still used) | `0x231b0Ee14048e9dCcD1d247744d114a4EB5E8E63` |
| **Sepolia** | `0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5` |
| **Holesky** | `0x6925affDa98274FE0376250187CCC4aC62866dCd` |

> **Note**: Both mainnet addresses are live. Newer names registered through the ENS Manager use `0xF29100983E058B709F3D539b0c765937B804AC15`. Older names may still point to `0x231b0Ee14048e9dCcD1d247744d114a4EB5E8E63`. Always resolve the resolver address for a specific name using the ENS registry.

### 6.2 Supported EIPs/Features

| EIP/ENSIP | Function | Description |
|-----------|----------|-------------|
| EIP-137 | `addr(bytes32)` | Contract address interface |
| EIP-165 | `supportsInterface(bytes4)` | Interface Detection |
| EIP-181 | `name(bytes32)` | Reverse Resolution |
| EIP-205 | `ABI(bytes32, uint256)` | ABI Resolution |
| EIP-619 | `pubkey(bytes32)` | SECP256k1 public keys |
| EIP-634 (ENSIP-5) | `text(bytes32, string)` | Text records |
| EIP-1577 | `contenthash(bytes32)` | Content hash resolution |
| EIP-2304 | `addr(bytes32, uint256)` | Multicoin address support |
| ENSIP-19 | `addr(bytes32, uint256)` | Default EVM address resolution |

### 6.3 Resolving the Resolver for a Specific Name

Before calling setText, always resolve the correct resolver for a name:

```typescript
const ENS_REGISTRY = '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e';

async function getResolver(ensName: string): Promise<string> {
  const node = namehash(normalize(ensName));
  const resolver = await publicClient.readContract({
    address: ENS_REGISTRY,
    abi: [{ inputs:[{name:'node',type:'bytes32'}], name:'resolver', outputs:[{name:'',type:'address'}], stateMutability:'view', type:'function' }],
    functionName: 'resolver',
    args: [node],
  });
  return resolver;
}
```

### 6.4 Default EVM Address Resolution (ENSIP-19)

The latest resolver (`0xF29100983E058B709F3D539b0c765937B804AC15`) supports a "default EVM address" concept via `coinType = 0`. If set, this address is returned for any EVM chain lookup unless a more specific address is configured.

### 6.5 Checking if a Resolver Supports setText

```typescript
const TEXT_RESOLVER_INTERFACE_ID = '0x59d1d43c';

async function supportsTextRecords(resolverAddress: string): Promise<boolean> {
  return await publicClient.readContract({
    address: resolverAddress as `0x${string}`,
    abi: [{ inputs:[{name:'interfaceID',type:'bytes4'}], name:'supportsInterface', outputs:[{name:'',type:'bool'}], stateMutability:'pure', type:'function' }],
    functionName: 'supportsInterface',
    args: [TEXT_RESOLVER_INTERFACE_ID],
  });
}
```

---

## 7. ENS Universal Resolver

**Source**: https://docs.ens.domains/resolvers/universal

### 7.1 Address

The Universal Resolver uses the **same address** on all supported networks:
```
0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe
```

This is a proxy contract owned by the ENS DAO. It will be upgraded to support ENSv2 in the future.

### 7.2 Key Interfaces

```solidity
interface IUniversalResolver {
    // Forward resolution: resolve one or more records for a name
    function resolve(bytes calldata name, bytes calldata data) 
        external view returns (bytes memory result, address resolver);
    
    // Reverse resolution: address → primary ENS name
    function reverse(bytes calldata lookupAddress, uint256 coinType) 
        external view returns (string memory primary, address resolver, address reverseResolver);
    
    // Batch gateway list
    function batchGateways() external view returns (string[] memory gateways);
}
```

**ABI with error types:**
```typescript
const universalResolverAbi = parseAbi([
  'error ResolverNotFound(bytes name)',
  'error ResolverNotContract(bytes name, address resolver)',
  'error UnsupportedResolverProfile(bytes4 selector)',
  'error ResolverError(bytes errorData)',
  'error ReverseAddressMismatch(string primary, bytes primaryAddress)',
  'error HttpError(uint16 status, string message)',
  'function resolve(bytes name, bytes data) view returns (bytes result, address resolver)',
  'function reverse(bytes lookupAddress, uint256 coinType) view returns (string primary, address resolver, address reverseResolver)',
  'function batchGateways() view returns (string[] gateways)',
]);
```

### 7.3 How viem Uses the Universal Resolver

When you call `client.getEnsText()`, viem:
1. DNS-encodes and normalizes the name
2. Encodes the `text(bytes32, string)` call
3. Calls `resolve(dnsEncodedName, encodedTextCall)` on the Universal Resolver
4. Decodes the returned bytes as a string

This handles CCIP-Read (EIP-3668) automatically — if the resolver is an offchain resolver, viem follows the gateway protocol.

```typescript
// What viem does internally for getEnsText
import { namehash, normalize } from 'viem/ens';
import { encodeFunctionData, decodeFunctionResult, toHex } from 'viem';
import { packetToBytes } from 'viem/ens';

const name = normalize('myagent.eth');
const node = namehash(name);
const dnsEncodedName = toHex(packetToBytes(name));

const resolverAbi = parseAbi([
  'function text(bytes32 node, string key) view returns (string)',
]);

const callData = encodeFunctionData({
  abi: resolverAbi,
  functionName: 'text',
  args: [node, 'agent-registration[0x...][42]'],
});

const [result] = await client.readContract({
  address: '0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe',
  abi: universalResolverAbi,
  functionName: 'resolve',
  args: [dnsEncodedName, callData],
});

const decoded = decodeFunctionResult({
  abi: resolverAbi,
  functionName: 'text',
  data: result,
});
// decoded = "1" (or empty string if not set)
```

### 7.4 Batch CCIP Gateway

The Universal Resolver uses `https://ccip-v3.ens.xyz` as the batch gateway for parallel EIP-3668 (CCIP-Read) requests. This handles off-chain resolver lookups efficiently.

### 7.5 Test Case for Universal Resolver Support

To verify your app uses the Universal Resolver:
- Resolve `ur.integration-tests.eth`
- If it returns `0x2222222222222222222222222222222222222222` → Universal Resolver is working
- If it returns `0x1111111111111111111111111111111111111111` → not using Universal Resolver

---

## 8. Custom Text Record Best Practices

**Sources**: https://docs.ens.domains/web/records, https://docs.ens.domains/ensip/5

### 8.1 Key Naming Conventions

ENSIP-5 defines two namespacing patterns:

#### Global Keys (lowercase letters, numbers, hyphens only)
```
avatar
description
display
keywords
notice
location
phone
url
```

#### Service Keys (reverse dot notation, must contain at least one dot)
```
com.twitter
com.github
com.linkedin
io.keybase
org.telegram
vcr.policy         ← your example: valid service key format
app.yourapp.setting
```

For your `vcr.policy` example: this is valid ENSIP-5 service key format. The `vcr` namespace is yours to define. Consider using a more specific namespace like `com.yourapp.vcr.policy` or `io.yourprotocol.vcr.policy` to avoid collisions.

### 8.2 Size Limits

**The ENS text record system has NO protocol-level size limit** on string values. Both keys and values are stored as `string` (dynamic) types in Solidity, limited only by:

- **Practical gas cost**: Storing 1 byte of data on-chain costs approximately 20,000 gas (new storage) or 5,000 gas (updating existing). A 1KB value costs ~$3–50 at typical gas prices.
- **Block gas limit**: A single transaction can include at most ~30MB of data on mainnet, but costs would be extreme.
- **Recommended limit**: Keep values under 1KB for practical use. Large values are better stored on IPFS/Arweave with a hash or URI stored in ENS.

### 8.3 Character Restrictions

| Scope | Restrictions |
|-------|-------------|
| **Global keys** | Lowercase letters, numbers, hyphen (`-`) only |
| **Service keys** | Reverse dot notation; must contain at least one dot |
| **ENSIP-25 `agentId`** | MUST NOT contain `[` or `]` |
| **Values** | Any arbitrary UTF-8 string; no restrictions |
| **Key length** | No protocol limit, but shorter keys cost less gas |

### 8.4 Custom Record Patterns (Recommended)

```
# Use reverse DNS notation (like Java package naming)
com.yourapp.setting
io.yourprotocol.config

# Use dot-separated hierarchy for complex apps
com.yourapp.agent.policy
com.yourapp.agent.capabilities
com.yourapp.agent.version

# ENS-specific format for well-known protocols
# (your app registers a namespace like "vcr")
vcr.policy
vcr.version

# For ENSIP-25 style records
# Use the full canonical format exactly as specified
agent-registration[<erc7930-encoded-registry>][<agentId>]
```

### 8.5 Pattern for vcr.policy Key

```typescript
// If vcr is your namespace:
const key = 'vcr.policy';
const value = JSON.stringify({
  version: '1.0',
  allowedCallers: ['0x...', '0x...'],
  maxConcurrent: 5,
});

await walletClient.writeContract({
  address: resolverAddress,
  abi: resolverAbi,
  functionName: 'setText',
  args: [node, key, value],
});
```

---

## 9. ENSIP-5 Text Records Spec

**Source**: https://docs.ens.domains/ensip/5  
**Author**: ricmoo.eth  
**Created**: May 17, 2017  
**Status**: Final

### 9.1 Resolver Profile

```solidity
interface IERC634 {
    /// @notice Returns the text data associated with a key for an ENS name
    /// @param node A nodehash for an ENS name
    /// @param key A key to lookup text data for
    /// @return The text data
    function text(bytes32 node, string calldata key) external view returns (string memory text);
}
```

**EIP-165 Interface ID**: `0x59d1d43c`

The `text` data may be any arbitrary UTF-8 string. If the key is not present, the **empty string** must be returned (not a revert).

### 9.2 Standardized Global Keys

| Key | Description | Example Value |
|-----|-------------|---------------|
| `avatar` | Image URL for avatar or logo | `https://...` or `eip155:1/erc1155:0x...` |
| `description` | Description of the name | "Lead developer of ENS" |
| `display` | Canonical display name (case-folded match required) | "RicMoo.eth" |
| `keywords` | Comma-separated keywords (most significant first) | "ethereum,defi,dao" |
| `notice` | Notice regarding this name | "This address is deprecated" |
| `location` | Generic location | "Toronto, Canada" |
| `phone` | E.164 phone number | "+1-555-000-0000" |
| `url` | Website URL | "https://ens.domains" |

Additional global keys from ENSIP-18:

| Key | Description |
|-----|-------------|
| `header` | Image URL for header/banner |
| `alias` | Display alias |

### 9.3 Standardized Service Keys

| Key | Service |
|-----|---------|
| `com.github` | GitHub username |
| `com.twitter` | Twitter/X username |
| `com.linkedin` | LinkedIn username |
| `com.peepeth` | Peepeth username |
| `io.keybase` | Keybase username |
| `org.telegram` | Telegram username |

### 9.4 Key Naming Rules Summary

- **Global keys**: lowercase letters + numbers + hyphens only
- **Service keys**: reverse dot notation (e.g., `com.github`); must contain at least one dot
- Services should use their own namespace (e.g., `com.yourapp.setting`) without updating ENSIP-5

---

## 10. ENS Subname Mechanics

**Sources**: https://docs.ens.domains/web/subdomains, https://docs.ens.domains/wrapper/creating-subname-registrar

### 10.1 Types of Subnames

| Type | Gas Cost | Trustless | NFT | Best For |
|------|----------|-----------|-----|---------|
| **L1 (on-chain)** | High (mainnet gas) | Yes | ERC-1155 if wrapped | Small number of subnames |
| **L2 (on-chain L2)** | Low (L2 gas) | Yes (trustless bridge) | Varies | Scalable, many subnames |
| **Off-chain** | Near zero | No (centralized DB) | No | Maximum scale, simple use case |

### 10.2 Creating researcher.acmecorp.eth (On-Chain)

**Prerequisite**: `acmecorp.eth` must be **wrapped** in the NameWrapper.

#### Step 1: Check if name is wrapped

```typescript
const ENS_REGISTRY = '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e';
const NAME_WRAPPER = '0xD4416b13d2b3a9aBae7AcD5D6C2BbDBE25686401';

const node = namehash(normalize('acmecorp.eth'));
const owner = await publicClient.readContract({
  address: ENS_REGISTRY,
  abi: [{ inputs:[{name:'node',type:'bytes32'}], name:'owner', outputs:[{name:'',type:'address'}], stateMutability:'view', type:'function' }],
  functionName: 'owner',
  args: [node],
});

const isWrapped = owner.toLowerCase() === NAME_WRAPPER.toLowerCase();
```

#### Step 2: Create subname using NameWrapper

```typescript
const nameWrapperAbi = parseAbi([
  'function setSubnodeOwner(bytes32 parentNode, string label, address owner, uint32 fuses, uint64 expiry) external returns (bytes32)',
  'function setSubnodeRecord(bytes32 parentNode, string label, address owner, address resolver, uint64 ttl, uint32 fuses, uint64 expiry) external returns (bytes32)',
  'function setApprovalForAll(address operator, bool approved) external',
]);

const parentNode = namehash(normalize('acmecorp.eth'));
const subLabel = 'researcher'; // just the label, not the full name
const subnameOwner = '0xRESEARCHER_ADDRESS';
const resolver = PUBLIC_RESOLVER_MAINNET;
const fuses = 0; // no fuses burned
const expiry = BigInt(Math.floor(Date.now() / 1000) + 365 * 24 * 3600); // 1 year

// Option A: setSubnodeOwner (simpler, no resolver/ttl)
const txHash = await walletClient.writeContract({
  address: NAME_WRAPPER,
  abi: nameWrapperAbi,
  functionName: 'setSubnodeOwner',
  args: [parentNode, subLabel, subnameOwner, fuses, expiry],
});

// Option B: setSubnodeRecord (sets resolver and TTL too)
const txHash2 = await walletClient.writeContract({
  address: NAME_WRAPPER,
  abi: nameWrapperAbi,
  functionName: 'setSubnodeRecord',
  args: [parentNode, subLabel, subnameOwner, resolver, 0n, fuses, expiry],
});
```

#### For unwrapped names: use ENS Registry directly

```typescript
const registryAbi = parseAbi([
  'function setSubnodeRecord(bytes32 node, bytes32 label, address owner, address resolver, uint64 ttl) external',
  'function setSubnodeOwner(bytes32 node, bytes32 label, address owner) external returns (bytes32)',
]);
import { keccak256, toHex, stringToBytes } from 'viem';

const parentNode = namehash(normalize('acmecorp.eth'));
const labelHash = keccak256(toHex(stringToBytes('researcher')));

await walletClient.writeContract({
  address: ENS_REGISTRY,
  abi: registryAbi,
  functionName: 'setSubnodeRecord',
  args: [parentNode, labelHash, subnameOwner, resolver, 0n],
});
```

### 10.3 NameWrapper Fuses

Fuses are bit flags that control permissions on wrapped names. Key fuses:

| Fuse | Value | Description |
|------|-------|-------------|
| `CANNOT_UNWRAP` | `1` | Prevents unwrapping the name |
| `CANNOT_BURN_FUSES` | `2` | Prevents burning more fuses |
| `CANNOT_TRANSFER` | `4` | Makes the NFT non-transferable |
| `CANNOT_SET_RESOLVER` | `8` | Prevents changing the resolver |
| `CANNOT_SET_TTL` | `16` | Prevents changing TTL |
| `CANNOT_CREATE_SUBDOMAIN` | `32` | Prevents creating subnames |
| `CANNOT_APPROVE` | `64` | Prevents approval |
| `CAN_EXTEND_EXPIRY` | `0x1000000` | Parent-controlled: allows owner to extend expiry |
| `IS_DOT_ETH` | `0x20000000` | Automatically set for .eth 2LDs |

**For emancipated subnames** (giving full control to subname owner), burn `CANNOT_UNWRAP | CANNOT_BURN_FUSES` on the parent first, then the child can have independent locked fuses.

### 10.4 Setting Resolver Records During Subname Creation

To set records at creation time (e.g., setting the ENSIP-25 text record on a new researcher.acmecorp.eth):

```typescript
// Step 1: Create subname with CONTRACT as temporary owner
await walletClient.writeContract({
  address: NAME_WRAPPER,
  abi: nameWrapperAbi,
  functionName: 'setSubnodeOwner',
  args: [parentNode, 'researcher', CONTRACT_ADDRESS, 0, expiry],
});

// Step 2: Contract calls setText on the resolver

// Step 3: Contract calls setSubnodeRecord again with actual owner
await walletClient.writeContract({
  address: NAME_WRAPPER,
  abi: nameWrapperAbi,
  functionName: 'setSubnodeRecord',
  args: [parentNode, 'researcher', ACTUAL_OWNER, resolver, 0n, 0, expiry],
});
```

### 10.5 Off-Chain Subname Providers

For high-volume use cases (many agent subnames like `agent42.acmecorp.eth`):

| Provider | Type | Notes |
|----------|------|-------|
| **NameStone** | Off-chain (API) | REST API, managed service |
| **Namespace** | Off-chain (API) | REST API |
| **JustaName** | Off-chain (API) | REST API |
| **Durin** | L2 (opinionated) | Handles L1 resolver + CCIP-Read gateway |
| **gskril/ens-offchain-registrar** | Off-chain (self-hosted) | Open source reference |

---

## 11. ERC-8004 AI Agent Registry Context

**Source**: https://eips.ethereum.org/EIPS/eip-8004  
**Status**: Draft  
**Created**: 2025-08-13

### 11.1 Overview

ERC-8004 ("Trustless Agents") defines three registries for discovering and trusting AI agents:

1. **Identity Registry** — ERC-721 + URIStorage; agents are NFTs with stable `agentId`s
2. **Reputation Registry** — Feedback signals on-chain
3. **Validation Registry** — Hooks for third-party validator responses

### 11.2 Identity Registry Interface

```solidity
// Register a new agent
function register(string agentURI) external returns (uint256 agentId);
function register(string agentURI, MetadataEntry[] calldata metadata) external returns (uint256 agentId);
function register() external returns (uint256 agentId);

// Update agent URI
function setAgentURI(uint256 agentId, string calldata newURI) external;

// Agent wallet (for receiving payments)
function setAgentWallet(uint256 agentId, address newWallet, uint256 deadline, bytes calldata signature) external;
function getAgentWallet(uint256 agentId) external view returns (address);

// On-chain metadata (arbitrary key-value)
function getMetadata(uint256 agentId, string memory metadataKey) external view returns (bytes memory);
function setMetadata(uint256 agentId, string memory metadataKey, bytes memory metadataValue) external;
```

### 11.3 Agent Global Identifier

An agent is globally identified by:
```
agentRegistry = "{namespace}:{chainId}:{identityRegistry}"
agentId = <ERC-721 tokenId>
```

Example: `eip155:1:0x8004A169FB4a3325136EB29fA0ceB6D2e539a432` with `agentId = 42`

### 11.4 Registration File (agentURI → JSON)

```json
{
  "type": "https://eips.ethereum.org/EIPS/eip-8004#registration-v1",
  "name": "ResearchBot",
  "description": "An AI agent for on-chain research and analysis",
  "image": "https://example.com/agentimage.png",
  "services": [
    { "name": "A2A", "endpoint": "https://agent.example/.well-known/agent-card.json", "version": "0.3.0" },
    { "name": "MCP", "endpoint": "https://mcp.agent.eth/", "version": "2025-06-18" },
    { "name": "ENS", "endpoint": "myagent.eth", "version": "v1" }
  ],
  "active": true,
  "registrations": [
    {
      "agentId": 42,
      "agentRegistry": "eip155:1:0x8004A169FB4a3325136EB29fA0ceB6D2e539a432"
    }
  ]
}
```

### 11.5 ENSIP-25 + ERC-8004 Integration Flow

```
                    ERC-8004 Registry (on-chain)
                    ┌─────────────────────────────────────┐
                    │ agentId: 42                         │
                    │ agentURI: ipfs://QmXxx...           │
                    │ owner: 0xABCD...                    │
                    │                                     │
                    │ Registration File (off-chain):      │
                    │   services[ENS]: "myagent.eth"      │
                    └─────────────────────────────────────┘
                                    ↓
                           (ENSIP-25 Verification)
                                    ↓
                    ENS Name: myagent.eth
                    ┌─────────────────────────────────────┐
                    │ Text record:                        │
                    │ key: agent-registration[            │
                    │   0x000100000101148004...432][42]   │
                    │ value: "1"                          │
                    └─────────────────────────────────────┘
                                    ↓
                           BIDIRECTIONAL VERIFICATION ✅
```

---

## 12. Complete Code Reference

### 12.1 Full Working Example: Set ENSIP-25 Record on Sepolia

```typescript
import {
  createPublicClient,
  createWalletClient,
  http,
  parseAbi,
  encodeFunctionData,
  keccak256,
  toBytes,
} from 'viem';
import { sepolia } from 'viem/chains';
import { privateKeyToAccount } from 'viem/accounts';
import { namehash, normalize } from 'viem/ens';

// ─── Constants ────────────────────────────────────────────────────────────────

const PUBLIC_RESOLVER_SEPOLIA = '0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5' as const;
const ENS_REGISTRY = '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e' as const;

// ─── ERC-7930 Encoding ────────────────────────────────────────────────────────

function encodeERC7930(chainId: number, address: string): string {
  const addrBytes = address.replace('0x', '').toLowerCase();
  let chainHex = chainId.toString(16);
  if (chainHex.length % 2 !== 0) chainHex = '0' + chainHex;
  const chainRefLength = (chainHex.length / 2).toString(16).padStart(2, '0');
  return `0x0001000${chainRefLength}${chainHex}14${addrBytes}`;
  // Note: chainType is 0x0000 for EVM, not shown in simplified version above
  // Correct full version:
}

function encodeERC7930Full(chainId: number, address: string): string {
  const addrHex = address.replace('0x', '').toLowerCase();
  if (addrHex.length !== 40) throw new Error('Invalid EVM address');
  
  let chainIdHex = chainId.toString(16);
  if (chainIdHex.length % 2 !== 0) chainIdHex = '0' + chainIdHex;
  const chainRefLen = (chainIdHex.length / 2).toString(16).padStart(2, '0');
  
  const version   = '0001';
  const chainType = '0000'; // EVM/EIP-155
  const addrLen   = '14';   // 20 bytes
  
  return `0x${version}${chainType}${chainRefLen}${chainIdHex}${addrLen}${addrHex}`;
}

// Examples:
// encodeERC7930Full(1, '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432')
// → '0x000100000101148004a169fb4a3325136eb29fa0ceb6d2e539a432'
// encodeERC7930Full(11155111, '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432')
// → '0x000100000103aa36a7148004a169fb4a3325136eb29fa0ceb6d2e539a432'

// ─── ENSIP-25 Key Builder ─────────────────────────────────────────────────────

function buildENSIP25Key(
  registryAddress: string,
  chainId: number,
  agentId: string | number
): string {
  if (String(agentId).includes('[') || String(agentId).includes(']')) {
    throw new Error('agentId must not contain [ or ]');
  }
  const erc7930 = encodeERC7930Full(chainId, registryAddress);
  return `agent-registration[${erc7930}][${agentId}]`;
}

// ─── Main: Set ENSIP-25 Text Record ──────────────────────────────────────────

async function setENSIP25Record(config: {
  privateKey: `0x${string}`;
  ensName: string;          // e.g. 'myagent.eth'
  registryAddress: string;  // e.g. '0x8004A169...'
  chainId: number;          // registry's chain ID
  agentId: number | string; // e.g. 42
  rpcUrl?: string;
}) {
  const account = privateKeyToAccount(config.privateKey);
  
  const walletClient = createWalletClient({
    account,
    chain: sepolia,
    transport: http(config.rpcUrl),
  });
  
  const publicClient = createPublicClient({
    chain: sepolia,
    transport: http(config.rpcUrl),
  });
  
  const node = namehash(normalize(config.ensName));
  const key = buildENSIP25Key(config.registryAddress, config.chainId, config.agentId);
  const value = '1';
  
  console.log(`Setting text record on ${config.ensName}:`);
  console.log(`  Key: ${key}`);
  console.log(`  Value: ${value}`);
  
  const resolverAbi = parseAbi([
    'function setText(bytes32 node, string key, string value) external',
    'function text(bytes32 node, string key) view returns (string)',
  ]);
  
  // Simulate to estimate gas and check for errors
  const { request, result } = await publicClient.simulateContract({
    address: PUBLIC_RESOLVER_SEPOLIA,
    abi: resolverAbi,
    functionName: 'setText',
    account,
    args: [node, key, value],
  });
  
  const txHash = await walletClient.writeContract(request);
  console.log(`Transaction: ${txHash}`);
  
  const receipt = await publicClient.waitForTransactionReceipt({ hash: txHash });
  console.log(`Confirmed in block ${receipt.blockNumber}`);
  
  // Verify
  const readBack = await publicClient.readContract({
    address: PUBLIC_RESOLVER_SEPOLIA,
    abi: resolverAbi,
    functionName: 'text',
    args: [node, key],
  });
  console.log(`Verified: ${readBack === '1' ? '✅' : '❌'} (value: "${readBack}")`);
}

// ─── Main: Verify ENSIP-25 Record ────────────────────────────────────────────

async function verifyENSIP25(
  ensName: string,
  registryAddress: string,
  chainId: number,
  agentId: number | string,
  rpcUrl?: string
): Promise<boolean> {
  const client = createPublicClient({
    chain: sepolia,
    transport: http(rpcUrl),
  });
  
  const key = buildENSIP25Key(registryAddress, chainId, agentId);
  
  const value = await client.getEnsText({
    name: normalize(ensName),
    key,
  });
  
  return value !== null && value !== '';
}
```

### 12.2 Contract Addresses Quick Reference

| Contract | Mainnet | Sepolia |
|----------|---------|---------|
| Registry | `0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e` | `0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e` |
| ETH Registrar Controller | `0x59E16fcCd424Cc24e280Be16E11Bcd56fb0CE547` | `0xfb3cE5D01e0f33f41DbB39035dB9745962F1f968` |
| NameWrapper | `0xD4416b13d2b3a9aBae7AcD5D6C2BbDBE25686401` | `0x0635513f179D50A207757E05759CbD106d7dFcE8` |
| Public Resolver (latest) | `0xF29100983E058B709F3D539b0c765937B804AC15` | `0xE99638b40E4Fff0129D56f03b55b6bbC4BBE49b5` |
| Public Resolver (older) | `0x231b0Ee14048e9dCcD1d247744d114a4EB5E8E63` | — |
| Universal Resolver | `0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe` | `0xeEeEEEeE14D718C2B47D9923Deab1335E144EeEe` |
| L1 Reverse Registrar | `0xa58E81fe9b61B5c3fE2AFD33CF304c454AbFc7Cb` | `0xA0a1AbcDAe1a2a4A2EF8e9113Ff0e02DD81DC0C6` |
| Default Reverse Registrar | `0x283F227c4Bd38ecE252C4Ae7ECE650B0e913f1f9` | `0x4F382928805ba0e23B30cFB75fC9E848e82DFD47` |
| Base Registrar | `0x57f1887a8BF19b14fC0dF6Fd9B2acc9Af147eA85` | `0x57f1887a8bf19b14fc0df6fd9b2acc9af147ea85` |

### 12.3 Key Namehash Values for Reference

```typescript
import { namehash, normalize } from 'viem/ens';

// These are fixed values
namehash('')      // 0x0000000000000000000000000000000000000000000000000000000000000000
namehash('eth')   // 0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae
// namehash('myagent.eth') = keccak256(namehash('eth') || keccak256('myagent'))
```

---

## Summary: Hackathon Checklist

### Setting Up an ENSIP-25 Verified AI Agent

- [ ] Register or own an ENS name (e.g., `myagent.eth` on Sepolia)
- [ ] Register agent in ERC-8004 registry → receive `agentId`
- [ ] Encode registry address as ERC-7930: `encodeERC7930Full(chainId, registryAddress)`
- [ ] Build ENSIP-25 key: `agent-registration[<erc7930>][<agentId>]`
- [ ] Call `setText(node, key, "1")` on the Public Resolver
- [ ] Verify: call `getEnsText` and check value is non-empty

### Key Gotchas

1. **Always normalize** ENS names before computing namehash: `normalize('MYAGENT.ETH')` → `'myagent.eth'`
2. **Chain ID in ERC-7930** must be the registry's chain, not necessarily the chain you're writing from
3. **The mainnet registry** address `0x8004A169...432` used in ENSIP-25 examples is for chain ID 1
4. **Sepolia ERC-7930** for the same registry would be `encodeERC7930Full(11155111, '0x8004...')` = different bytes
5. **Only the name manager** can setText — for wrapped names, check NameWrapper ownership
6. **Stale records**: if a name transfers, ENSIP-25 records should be re-evaluated
7. **viem chain config**: use `chain: sepolia` and viem auto-selects the right Universal Resolver
