# BitGo SDK Deep Research — MPC Wallets on Ethereum (Hoodi/hteth)

> **Last updated:** March 13, 2026  
> **Scope:** Hackathon build reference — hteth (Hoodi testnet), MPC wallets, policies, forwarders, transactions

---

## Table of Contents

1. [SDK Packages](#1-sdk-packages)
2. [Authentication Flow](#2-authentication-flow)
3. [Hoodi Testnet (hteth)](#3-hoodi-testnet-hteth)
4. [MPC Wallet Creation](#4-mpc-wallet-creation)
5. [Wallet Policies — CRITICAL](#5-wallet-policies--critical)
6. [Forwarder Addresses](#6-forwarder-addresses)
7. [Sending Transactions](#7-sending-transactions)
8. [BitGo REST API Reference](#8-bitgo-rest-api-reference)
9. [Webhooks & Callbacks](#9-webhooks--callbacks)
10. [Error Handling & Known Issues](#10-error-handling--known-issues)
11. [Quick Reference Cheatsheet](#11-quick-reference-cheatsheet)

---

## 1. SDK Packages

### Package Architecture

BitGo's JavaScript SDK is a **modular monorepo**. The old monolithic `bitgo` package still works, but the modern approach splits into:

| Package | npm Version | Description |
|---|---|---|
| `@bitgo/sdk-api` | `1.63.2` | Core BitGoAPI class, REST wrapper, auth, session management |
| `@bitgo/sdk-coin-eth` | `25.0.1` | Eth/Hteth coin implementations, Hteth class, forwarder logic |
| `@bitgo/sdk-core` | (peer dep) | Base wallet, keychain, pending approvals, policy interfaces |
| `bitgo` | (legacy) | Old monolith — still works, all coins included by default |

**Source:** [npmjs @bitgo/sdk-api](https://www.npmjs.com/package/@bitgo/sdk-api), [npmjs @bitgo/sdk-coin-eth](https://www.npmjs.com/package/@bitgo/sdk-coin-eth)

### Installation

```bash
# Modern modular approach (recommended for hackathons — smaller bundle)
npm install @bitgo/sdk-api @bitgo/sdk-coin-eth

# Legacy monolith (works, heavier)
npm install bitgo
```

### `@bitgo/sdk-api` — `BitGoAPI` Class

The `BitGoAPI` class is the entry point for the new SDK. It replaces the old `BitGo` constructor.

```typescript
import { BitGoAPI } from '@bitgo/sdk-api';
import { Hteth } from '@bitgo/sdk-coin-eth';

// Initialize
const bitgo = new BitGoAPI({
  env: 'test',                   // 'test' | 'prod' | 'staging'
  accessToken: '<token>',        // optional — can set later
});

// Register coin(s) you need
bitgo.register('hteth', Hteth.createInstance);

// Now use
const coin = bitgo.coin('hteth');
```

**Key `BitGoAPI` constructor options:**

| Option | Type | Description |
|---|---|---|
| `env` | `'test' \| 'prod' \| 'staging' \| 'custom'` | Which BitGo environment to hit |
| `accessToken` | `string` | Long-lived or short-lived access token |
| `customRootURI` | `string` | For `env: 'custom'` — custom API base URL |
| `hmacVerification` | `boolean` | Whether to verify HMAC signatures (default true in prod) |

**Key `BitGoAPI` methods:**

```typescript
// Authentication
bitgo.authenticate({ username, password, otp })       // short-lived token
bitgo.authenticateWithAccessToken({ accessToken })    // long-lived token
bitgo.addAccessToken({ otp, label, scope, duration, spendingLimits })
bitgo.unlock({ otp, duration })   // unlock session for spending
bitgo.lock()                      // re-lock

// Session
bitgo.coin('hteth')               // returns coin instance
bitgo.me()                        // get current user info
bitgo.getEnv()                    // 'test' | 'prod'
bitgo.token()                     // current access token

// Enterprise
bitgo.enterprises().list()        // list enterprises (enterpriseId lives here)
```

### `@bitgo/sdk-coin-eth` — `Hteth` Class

```typescript
import { Hteth, Eth } from '@bitgo/sdk-coin-eth';

// Register Hoodi testnet
bitgo.register('hteth', Hteth.createInstance);

// Register mainnet ETH
bitgo.register('eth', Eth.createInstance);
```

**`Hteth.createInstance`** is the static factory method. It accepts a `BitGoBase` instance and returns the `Hteth` coin object.

The `Hteth` class extends `Eth`, which extends `AbstractEthLikeCoin`. Key coin-level methods available after `bitgo.coin('hteth')`:

```typescript
const coin = bitgo.coin('hteth');

// Wallet operations
coin.wallets()                    // WalletsAPI instance
coin.wallets().generateWallet({}) // create new wallet
coin.wallets().get({ id })        // fetch existing wallet
coin.wallets().list({})           // list all wallets

// Keychain operations
coin.keychains()
coin.keychains().create({ passphrase })  // user keychain
coin.keychains().createBackup({})        // backup keychain
coin.keychains().createBitGo({})         // BitGo keychain (requests from server)

// Pending approvals
coin.pendingApprovals().get({ id })
coin.pendingApprovals().list({ walletId, enterpriseId })

// Utilities
coin.getChain()                   // 'hteth'
coin.getFullName()                // 'Testnet Ethereum'
coin.isValidAddress('0x...')
coin.toBaseUnit('1')              // '1000000000000000000' (1 ETH in wei)
coin.fromBaseUnit('1000000000000000000') // '1'
```

**Node.js compatibility (from `package.json`):**
```
"engines": { "node": ">=20 <23" }
```

---

## 2. Authentication Flow

### Test Environment Overview

- **Test API base URL:** `https://app.bitgo-test.com`
- **Test web console:** `https://test.bitgo.com`
- The test environment is a **completely separate namespace** from production — sign up separately at [test.bitgo.com](https://test.bitgo.com)

**Source:** [BitGo Environments docs](https://developers.bitgo.com/docs/get-started-environments)

### Setting Up Test Credentials

1. Register at [test.bitgo.com](https://test.bitgo.com) — this auto-creates an enterprise in the test environment
2. Log in to the test dashboard and create a long-lived access token from Developer Settings
3. Your **Enterprise ID** is visible in the dashboard under "Manage Organization" (also returned in the login response under `user.enterprises[0].id`)

### OTP for Test Environment

> **CONFIRMED:** The test OTP is `0000000` (7 zeroes). Some docs also show `000000` (6 zeroes). The test environment does NOT require a real 2FA device.

From [official BitGo docs](https://developers.bitgo.com/docs/get-started-access-tokens):
> "OTP is always 0000000 in test environment"

From [BitGo CLI v2 repo](https://github.com/BitGo/bitgo-cli-v2):
> "in the test environment, while standard OAuth codes still work for 2FA, it is also possible to use a code of 0000000 (7 zeroes)."

**Use `0000000` (7 zeroes) to be safe. `000000` (6 zeroes) also appears in some SDK code examples.**

### Authentication Method 1: Username/Password/OTP (Short-lived token)

```typescript
import { BitGoAPI } from '@bitgo/sdk-api';

const bitgo = new BitGoAPI({ env: 'test' });

const response = await bitgo.authenticate({
  username: 'your@email.com',
  password: 'yourPassword',
  otp: '0000000',   // always this in test
});

// Response contains access_token (1-hour validity)
const shortLivedToken = response.access_token;
// And user info including enterprise ID:
const enterpriseId = response.user.enterprises[0].id;
```

**cURL equivalent:**
```bash
curl -X POST \
  https://app.bitgo-test.com/api/v2/user/login \
  -H 'Content-Type: application/json' \
  -d '{
    "email": "your@email.com",
    "password": "yourPassword",
    "otp": "0000000"
  }'
```

**Response JSON:**
```json
{
  "token_type": "bearer",
  "access_token": "cb4125818839d3695e51ad74443e8362105f315e2495b3e905454430e948d556",
  "expires_in": 86400,
  "expires_at": 1763745105,
  "scope": ["user_manage", "wallet_create", "wallet_spend_all", "..."],
  "grant_type": "password",
  "user": {
    "id": "62ab90e06dfda30007974f0a52a12995",
    "username": "your@email.com",
    "enterprises": [
      {
        "id": "61fab88a336c18000813831c85a3f2fe",
        "permissions": ["admin", "auditor"]
      }
    ]
  }
}
```

### Authentication Method 2: Create Long-Lived Access Token

Use the short-lived token to create a long-lived one (up to 10 years):

```typescript
const accessToken = await bitgo.addAccessToken({
  otp: '0000000',
  label: 'Hackathon Token',
  scope: [
    'openid', 'profile',
    'wallet_create',
    'wallet_manage_all',
    'wallet_approve_all',
    'wallet_spend_all',
    'wallet_edit_all',
    'wallet_view_all',
    'pending_approval_update',
    'enterprise_manage_all',
  ],
  // duration in seconds (optional — defaults to long-lived)
  // IP restriction required in production, optional in test
});

console.log(accessToken.token);  // save this — unrecoverable!
```

**Token prefix note:** v2/v3 tokens are prefixed with `v2x` (e.g., `v2x922bc...`). If your token starts with `v2x`, it uses HMAC authentication. Older tokens without the prefix fall back to v1 auth (less secure).

### Authentication Method 3: Direct Access Token (Simplest for Hackathon)

```typescript
const bitgo = new BitGoAPI({
  env: 'test',
  accessToken: process.env.BITGO_ACCESS_TOKEN,
});

// Or set it after construction:
bitgo.authenticateWithAccessToken({ accessToken: process.env.BITGO_ACCESS_TOKEN });
```

### Unlocking the Session for Spending

For send operations, you must unlock the session even when using a long-lived token:

```typescript
await bitgo.unlock({ otp: '0000000', duration: 3600 }); // 1-hour unlock
```

---

## 3. Hoodi Testnet (hteth)

### Testnet Status: Hoodi Replaces Holesky

**The Holesky testnet has been shut down.** Holesky was deprecated after Ethereum's Pectra upgrade in 2025 due to finality issues, with shutdown occurring two weeks after the Fusaka upgrade finalized (approximately November 2025).

**Current situation (as of March 2026):**
- `gteth` (Goerli) — deprecated, do not use
- `hteth` — historically pointed at Holesky but **now points at Hoodi** per BitGo's current documentation  
- `hteth` is the correct coin identifier for the Ethereum testnet in BitGo

From [BitGo Ethereum coin page](https://developers.bitgo.com/coins/Ethereum):
> "`gteth` (aka Goerli testnet) has been deprecated. Please use `hteth` (aka Holesky testnet) instead."

**Note:** The page still says "Holesky" but the faucet link on the current Ethereum coin page now points to `https://hoodi-faucet.pk910.de/#/` — confirming BitGo's `hteth` now targets the Hoodi testnet.

**Sources:**
- [Ethereum Foundation Blog: Holesky Shutdown Announcement](https://blog.ethereum.org/2025/09/01/holesky-shutdown-announcement)
- [BitGo Ethereum coin page](https://developers.bitgo.com/coins/ethereum) — faucet URL is `https://hoodi-faucet.pk910.de/#/`
- [eth-clients/hoodi GitHub](https://github.com/eth-clients/hoodi)

### Hoodi Network Details

| Property | Value |
|---|---|
| **Chain ID** | `560048` (hex: `0x88bb0`) |
| **Network ID** | `560048` |
| **Launch Date** | March 17, 2025 |
| **Status** | Active — expected EOL September 30, 2028 |
| **Expected lifetime** | Long-term (replaces Holesky) |

**Sources:** [hoodi.dev](https://hoodi.dev), [ChainList](https://chainlist.org/chain/560048), [GetBlock Hoodi announcement](https://getblock.io/blog/getblock-launches-ethereum-hoodi-testnet-rpc--holesky-endpoints-deprecated/)

### Block Explorers for Hoodi

| Explorer | URL |
|---|---|
| Dora (primary) | https://dora.hoodi.ethpandaops.io |
| Beacon chain light | https://light-hoodi.beaconcha.in |
| Etherscan (coming) | (check https://hoodi.etherscan.io) |

### Faucets for Hoodi ETH

| Faucet | URL | Notes |
|---|---|---|
| **BitGo-linked PoW faucet** | https://hoodi-faucet.pk910.de | Listed on BitGo's Ethereum coin page |
| Chainlink faucet | https://faucets.chain.link/hoodi | Requires wallet connect |
| Devconnect Hoodi faucet | https://www.devconnect-hoodi-faucet.pk910.de | Special instance |

**PoW faucet process:** Enter your ETH address, do browser-based mining work, then claim rewards. Prevents spam without requiring login.

### BitGo Gas Tank for hteth

Every BitGo enterprise has a **gas tank** (fee address) per network. ETH must be deposited into this gas tank before you can create wallets, create addresses, or send transactions. The gas tank is NOT a normal wallet — you cannot withdraw from it.

```bash
# Check gas tank balance
curl -X GET \
  "https://app.bitgo-test.com/api/v2/hteth/enterprise/$ENTERPRISE_ID/feeAddressBalance" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

**Workflow:**
1. Create your enterprise/account on test.bitgo.com
2. Find your gas tank address in the BitGo test dashboard (under "Network Gas Tanks")
3. Fund it with Hoodi ETH from the faucet
4. Only then can you create wallets and addresses

---

## 4. MPC Wallet Creation

### Wallet Types for Ethereum

From [BitGo Wallet Types docs](https://developers.bitgo.com/docs/wallet-types):

| Signature Scheme | Description | ETH Support |
|---|---|---|
| **Multisignature (onchain)** | Original BitGo scheme, smart-contract-based 2-of-3. Uses walletVersion 1-3. | ✅ |
| **TSS/MPC** | Threshold Signature Scheme. Keyshares instead of full keys. Uses walletVersion 4-6. | ✅ |

**For ETH/hteth specifically:**
- `multisigType: 'onchain'` → uses Ethereum smart contracts for multisig; default `walletVersion` is `3` (recommended for multisig)
- `multisigType: 'tss'` → uses MPC/TSS keyshare technology; requires `walletVersion: 6` (requires special enterprise enablement — contact BitGo support)

### `generateWallet` — Full Parameters

```typescript
const { wallet, userKeychain, backupKeychain, bitgoKeychain } =
  await bitgo.coin('hteth').wallets().generateWallet({
    // REQUIRED
    label: 'My HTeth Wallet',          // string: display name
    passphrase: 'VerySecurePass123!',  // string: encrypts the user private key
    enterprise: '5612c2beeecf83610b621b90964448cd', // string: your enterprise ID

    // OPTIONAL — multisig settings
    multisigType: 'onchain',    // 'onchain' (default) | 'tss' (MPC/TSS — requires v6)
    walletVersion: 3,           // 3 for ECDSA/multisig ETH; 6 for TSS (requires support enablement)
    type: 'hot',                // 'hot' | 'cold' | 'custodial' (default: 'hot')

    // OPTIONAL — MPC/TSS specific
    passcodeEncryptionCode: 'anotherSecret', // used to recover passphrase during key recovery

    // OPTIONAL — cold wallet (TSS cold)
    coldDerivationSeed: '...',  // for deterministic cold wallets
  });
```

**Source:** [BitGo Create Wallets guide](https://developers.bitgo.com/docs/wallets-create-wallets), [BitGo Ethereum coin page](https://developers.bitgo.com/coins/ethereum)

### walletVersion Meanings

| walletVersion | Type | Description |
|---|---|---|
| `1` | Multisig onchain | Legacy ETH multisig |
| `2` | Multisig onchain | Improved ETH multisig |
| `3` | Multisig onchain | **Current recommended** for ECDSA/onchain wallets |
| `4` | TSS | Early TSS implementation |
| `5` | TSS | TSS with improvements |
| `6` | TSS/MPC | **Current MPC/TSS wallet** — requires enterprise enablement via support@bitgo.com |

**For a hackathon:** Use `walletVersion: 3` with `multisigType: 'onchain'` unless you specifically need TSS.  
**For true MPC:** Use `walletVersion: 6` with `multisigType: 'tss'` — but you must contact BitGo support to enable v6 for your enterprise.

From the [BitGo Ethereum docs](https://developers.bitgo.com/coins/ethereum):
> "Ethereum MPC wallets use wallet version 6. To enable v6 wallets in your enterprise, contact support@bitgo.com"

### TSS vs ECDSA (onchain) for ETH

| Feature | ECDSA / onchain (v3) | TSS / MPC (v6) |
|---|---|---|
| Architecture | Smart contract multisig | Threshold signature scheme |
| Forwarder support | ✅ Auto-deployed forwarders | Manual consolidation required |
| Address creation | Deploy contract on-chain (costs gas) | Standard EOA-style |
| Balance consolidation | Auto via forwarders | Manual consolidation needed |
| Enterprise setup | Works out of box | Requires support enablement |
| Best for hackathon | ✅ Yes | Only if TSS is the hackathon requirement |

**Key difference for forwarders:** With `walletVersion: 3` (onchain multisig), forwarder contracts are deployed automatically when you create addresses. With `walletVersion: 6` (TSS), you must manually consolidate balances from receive addresses to the base address.

### `generateWallet` Full Response

```json
{
  "wallet": {
    "id": "6849948ac0623f81f74f63dbd8351d4f",
    "users": [
      {
        "user": "62ab90e06dfda30007974f0a52a12995",
        "permissions": ["admin", "spend", "view"]
      }
    ],
    "coin": "hteth",
    "label": "My HTeth Wallet",
    "m": 2,
    "n": 3,
    "keys": [
      "68499487e6c77351bd3bbf04281fa8bb",  // user key ID
      "68499487cd07fc57de18f6481baa1903",  // backup key ID
      "6849948902be620840a384c148d19979"   // BitGo key ID
    ],
    "keySignatures": {
      "backupPub": "204119...",
      "bitgoPub": "20784a..."
    },
    "enterprise": "62c5ae8174ac860007aff138a2d74df7",
    "bitgoOrg": "BitGo Trust",
    "tags": ["6849948ac0623f81f74f63dbd8351d4f", "62c5ae..."],
    "approvalsRequired": 1,
    "isCold": false,
    "coinSpecific": {
      "feeAddress": "0x94bbb7c3582ae9fbb829daa9fd81e112184df260"  // gas tank address
    },
    "admin": {},
    "type": "hot",
    "multisigType": "onchain",
    "balance": 0,
    "balanceString": "0",
    "confirmedBalance": 0,
    "confirmedBalanceString": "0",
    "spendableBalance": 0,
    "spendableBalanceString": "0",
    "receiveAddress": {
      "id": "6849948ac0623f81f74f63ead377af97",
      "address": "0x...",   // THE main wallet contract address
      "pendingChainInitialization": true  // TRUE until the deployment tx confirms!
    },
    "pendingApprovals": []
  },
  "userKeychain": {
    "id": "68499487e6c77351bd3bbf04281fa8bb",
    "pub": "xpub661My...",
    "ethAddress": "0x944b592f...",
    "source": "user",
    "type": "independent",
    "encryptedPrv": "{\"iv\":\"...\",\"ct\":\"...\"}",  // encrypted with passphrase
    "prv": "xprv9s21ZrQ..."  // ONLY returned at creation — store this securely!
  },
  "backupKeychain": {
    "id": "68499487cd07fc57de18f6481baa1903",
    "pub": "xpub661My...",
    "ethAddress": "0x1907...",
    "source": "backup",
    "type": "independent",
    "encryptedPrv": "{...}",
    "prv": "xprv9s21ZrQ..."  // ONLY returned at creation!
  },
  "bitgoKeychain": {
    "id": "6849948902be620840a384c148d19979",
    "pub": "xpub661My...",
    "ethAddress": "0x92f4...",
    "source": "bitgo",
    "isBitGo": true,
    "hsmType": "institutional"
  },
  "responseType": "WalletWithKeychains",
  "warning": "Be sure to backup the backup keychain -- it is not stored anywhere else!"
}
```

**CRITICAL:** The `prv` fields in `userKeychain` and `backupKeychain` are **only returned once** at wallet creation. Store them securely.

**CRITICAL:** ETH wallets are **not usable immediately**. The `pendingChainInitialization: true` flag means the wallet contract deployment transaction is pending. Do NOT deposit to the wallet until this becomes `false`.

### Getting Your Enterprise ID

```typescript
// Method 1: From login response
const response = await bitgo.authenticate({ username, password, otp: '0000000' });
const enterpriseId = response.user.enterprises[0].id;

// Method 2: Via API
const enterprises = await bitgo.enterprises().list();
// Or REST:
// GET https://app.bitgo-test.com/api/v2/enterprise
```

From the [Environments docs](https://developers.bitgo.com/docs/get-started-environments):
> "Creating an account for the developer portal automatically creates an enterprise in the test environment."

---

## 5. Wallet Policies — CRITICAL

### Two Policy Systems: Old (Wallet-Level) vs New (Enterprise-Level)

BitGo has **two distinct policy APIs**:

| System | API Path | Applies To | Notes |
|---|---|---|---|
| **Old wallet-policy API** (v2) | `/api/v2/{coin}/wallet/{id}/policy/rule` | Individual wallets | Uses `advancedWhitelist`, `velocityLimit`, etc. Per-wallet rules. |
| **New enterprise policy API** (policy/v1) | `/api/policy/v1/enterprises/{id}/touchpoints/{tp}/rules` | Enterprise-wide | Uses touchpoints/conditions/actions model. More flexible. |

For a hackathon using self-custody multisig wallets, both are relevant. The **old API** gives simpler per-wallet controls; the **new API** is more powerful and enterprise-wide.

### 5a. Old Wallet Policy API — `createPolicyRule`

**Endpoint:** `POST /api/v2/{coin}/wallet/{walletId}/policy/rule`  
**SDK method:** `wallet.createPolicyRule(policy)`

#### advancedWhitelist (coinAddressWhitelist equivalent)

Creates an address whitelist. Transactions to non-whitelisted addresses will trigger `deny` or `getApproval`.

```typescript
// Create whitelist with DENY action for non-whitelisted addresses
const result = await wallet.createPolicyRule({
  id: 'my-whitelist',            // string: unique rule ID (you choose the name)
  type: 'advancedWhitelist',
  condition: {
    add: {
      item: '0xRecipientAddress',  // address to whitelist
      type: 'address',
      metaData: {
        label: 'Recipient Wallet'  // optional label
      }
    }
  },
  action: {
    type: 'getApproval'   // 'deny' | 'getApproval'
    // 'deny' = auto-block; 'getApproval' = require approval from wallet admin
  }
});
```

**cURL equivalent:**
```bash
curl -X POST \
  "https://app.bitgo-test.com/api/v2/$COIN/wallet/$WALLET_ID/policy/rule" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -d '{
    "coin": "hteth",
    "id": "my-whitelist",
    "type": "advancedWhitelist",
    "condition": {
      "add": {
        "type": "address",
        "item": "0xRecipientAddress"
      }
    },
    "action": {
      "type": "deny"
    }
  }'
```

**Add more addresses to existing whitelist:**
```typescript
await wallet.updatePolicyRule({
  id: 'my-whitelist',
  type: 'advancedWhitelist',
  condition: {
    add: {
      item: ['0xAddress1', '0xAddress2'],  // can be array
      type: 'address'
    }
  },
  action: { type: 'deny' }
});
```

**Remove address from whitelist:**
```typescript
await wallet.removePolicyRule({
  id: 'my-whitelist',
  type: 'advancedWhitelist',
  condition: {
    remove: {
      item: '0xAddressToRemove',
      type: 'address'
    }
  },
  action: { type: 'deny' }
});
```

**Whitelist response when no approval needed (immediate):**
```json
{
  "id": "66e9f4bb549f6c3957f8977fe3ed6ab4",
  "coin": "hteth",
  "label": "My Wallet",
  "admin": {
    "policy": {
      "date": "2024-09-18T22:05:21.220Z",
      "id": "66e9f4bb549f6c3957f897824915d45f",
      "label": "default",
      "rules": [
        {
          "id": "my-whitelist",
          "lockDate": "2025-09-18T22:05:21.219Z",
          "coin": "hteth",
          "type": "advancedWhitelist",
          "action": { "type": "deny", "userIds": [] },
          "condition": {
            "entries": [
              { "item": "0xRecipientAddress", "type": "address" }
            ]
          }
        }
      ],
      "version": 5,
      "latest": true
    }
  }
}
```

**When approval IS required (pendingApproval returned):**
```json
{
  "pendingApproval": {
    "id": "66edb22fbef3fef723292c7b14ae01f3",
    "coin": "hteth",
    "wallet": "66e9aba320e050e4334b23285bfe3b2e",
    "state": "pending",
    "scope": "wallet",
    "info": {
      "type": "policyRuleRequest",
      "policyRuleRequest": {
        "action": "create",
        "update": { "id": "my-whitelist", "type": "advancedWhitelist", "..." }
      }
    }
  }
}
```

#### velocityLimit Policy

Limits total spend in a time window:

```typescript
await wallet.createPolicyRule({
  id: 'daily-limit',
  type: 'velocityLimit',
  condition: {
    timeWindow: 86400,            // seconds: 86400 = 24 hours, 3600 = 1 hour
    limit: '1000000000000000000', // in WEI (1 ETH = 1e18 wei) for ETH
    // Note: velocityLimit uses crypto base units (wei for ETH), NOT USD
    currency: 'base',             // 'base' = use the coin's base unit
  },
  action: {
    type: 'getApproval'  // or 'deny'
  }
});
```

> **IMPORTANT:** The `limit` for `velocityLimit` policies on ETH is in **wei** (base units), NOT USD. 
> `1 ETH = 1,000,000,000,000,000,000 wei = 1e18 wei`

#### Other Old Policy Rule Types

| Type | Description |
|---|---|
| `advancedWhitelist` | Address/wallet whitelist — deny or require approval for unlisted destinations |
| `velocityLimit` | Cap total spending in a time window |
| `allocationLimit` | Maximum per-transaction amount |

### 5b. New Enterprise Policy API (policy/v1)

This is the modern API for more complex enterprise-wide rules.

**Step 1: Get scope ID**
```bash
GET /api/policy/v1/enterprises/$ENTERPRISE_ID/scopes
```

**Step 2: Get touchpoint name**
```bash
GET /api/policy/v1/enterprises/$ENTERPRISE_ID/scopes/$SCOPE_ID/touchpoints
```

**Available touchpoints:**
- `wallet.segregated.transfer` — Withdrawal from a BitGo Wallet
- `goaccount.settlement.signed` — Settlement initiated from Go Account
- `goaccount.settlement.countersigned` — Settlement accepted

**Step 3: Create policy rule**
```bash
POST /api/policy/v1/enterprises/$ENTERPRISE_ID/touchpoints/$TOUCHPOINT/rules
```

```json
{
  "name": "Require approval for withdrawals over 0.5 HTeth",
  "adminOnly": false,
  "clauses": [
    {
      "conditions": [
        {
          "name": "transfer.amount",
          "parameters": {
            "operator": ">",
            "amount": "500000000000000000",
            "coin": "hteth"
          }
        }
      ],
      "actions": [
        {
          "name": "approvals.customer.enterpriseUser",
          "parameters": {
            "userIds": ["USER_ID_TO_APPROVE"],
            "minRequired": "1",
            "initiatorIsAllowedToApprove": false
          }
        }
      ]
    }
  ],
  "filteringConditions": [
    {
      "name": "wallet.ids",
      "parameters": {
        "walletId": ["WALLET_ID"]
      }
    }
  ]
}
```

**Available conditions:**
- `transfer.amount` — Amount operators: `>`, `<`, `>=`, `<=`, `==`
- `wallet.type` — wallet type (`hot`, `cold`, `custodial`, `trading`)
- `wallet.ids` — specific wallet IDs

**Available actions:**
- `approvals.customer.enterpriseUser` — require approval from specific users
- `approvals.customer.walletAdmin` — require approval from any wallet admin
- (automatic approval is the default if no action clause matches)

**Policy rule response (NEW API):**
```json
{
  "uniqueId": "835c75f8-49e2-4d5b-82f0-0c8829d52a05",
  "id": "5e43e1b6-665d-4406-b59a-b9e1d2e9dfad",
  "name": "Require approval for withdrawals over 0.5 HTeth",
  "status": "PENDING_APPROVAL",
  "locked": false,
  "lockType": "LOCK_AFTER_DATE",
  "lockDate": "2024-04-14T18:52:07.955224Z",
  "createdDate": "2024-04-12T18:52:07.955235Z"
}
```

### 5c. The 48-Hour Lock — CRITICAL for Hackathon

> **The most important policy gotcha:** All wallet policies lock **48 hours after creation**. Once locked, they cannot be modified without contacting BitGo support (and only institutional customers can get them unlocked).

**What "locked" means:**
- `locked: false` → within the 48-hour window; you can update/delete freely
- `locked: true` → past 48 hours; **frozen forever** unless you have an institutional account
- The `lockDate` field in policy responses shows exactly when it will lock

**What happens at 48h:**
- The policy rule becomes immutable
- Any transaction to a non-whitelisted address (if using whitelist policy) will be permanently blocked
- Updates require emailing support@bitgo.com — only available to institutional customers

**Real-world warning:** A Reddit user ([source](https://www.reddit.com/r/mtgoxinsolvency/comments/1emnjza/bitgo_users_beware_policy_unlocks_are_only/)) reported:
> "Policy Unlocks are only provided for Institutional Customers. They lock after 48 hours, and if you actually do contact them, support will refuse to help because 'Policy Unlocks are only provided for Institutional Customers.' If you have a starter-level account, they'll just hold your wallet hostage."

**Hackathon strategy:**
1. Plan your policies carefully before setting them
2. Test policy behavior within the 48-hour window
3. For a hackathon, you can create fresh test wallets/enterprises each time policies need changing
4. Use `getApproval` action type (rather than `deny`) for more flexibility — you can manually approve transactions even after lock

### 5d. Getting Wallet Policies (getPolicies)

```typescript
const wallet = await bitgo.coin('hteth').wallets().get({ id: walletId });

// Policies are embedded in the wallet object:
const policies = wallet._wallet.admin.policy;

console.log(policies);
// {
//   "date": "...",
//   "id": "policy-id",
//   "label": "default",
//   "rules": [
//     {
//       "id": "my-whitelist",
//       "lockDate": "2025-09-18T22:05:21.219Z",
//       "coin": "hteth",
//       "type": "advancedWhitelist",
//       "action": { "type": "deny", "userIds": [] },
//       "condition": {
//         "entries": [
//           { "item": "0xWhitelistedAddress", "type": "address" }
//         ]
//       }
//     }
//   ],
//   "version": 5,
//   "latest": true
// }
```

**Via REST (new policy API):**
```bash
GET /api/policy/v1/enterprises/$ENTERPRISE_ID/touchpoints/$TOUCHPOINT/rules
```

### 5e. Testing Policies Before 48h Lock

Yes, you can absolutely test policies within the 48-hour window:

```typescript
// 1. Create policy with getApproval action
await wallet.createPolicyRule({
  id: 'test-whitelist',
  type: 'advancedWhitelist',
  condition: { add: { item: '0xApprovedAddress', type: 'address' } },
  action: { type: 'getApproval' }
});

// 2. Try sending to non-whitelisted address (triggers pendingApproval)
const sendResult = await wallet.sendMany({
  recipients: [{ address: '0xNonWhitelistedAddress', amount: '1000000000000000' }],
  walletPassphrase: 'yourPassphrase'
});
// sendResult.pendingApproval will have the approval ID

// 3. Check the pending approval
const approval = sendResult.pendingApproval;
console.log('Pending approval ID:', approval.id);

// 4. Approve it (simulating the approval flow)
const pa = await bitgo.coin('hteth').pendingApprovals().get({ id: approval.id });
await pa.approve({ otp: '0000000', walletPassphrase: 'yourPassphrase' });

// 5. Modify policy within 48h window (before lockDate)
await wallet.updatePolicyRule({ id: 'test-whitelist', ... });
```

---

## 6. Forwarder Addresses

### What Is a Forwarder Address?

In BitGo's Ethereum smart-contract wallet architecture (walletVersion 1–3, `multisigType: 'onchain'`):

- **Root wallet address** = the main wallet contract. This is the address that holds funds and can initiate sends.
- **Forwarder address** = a lightweight "child" contract deployed at a separate address that automatically forwards received ETH/ERC-20 to the root address.

**Purpose:** Enables each transaction/customer to have a unique deposit address while all funds flow to one wallet contract. Privacy, accounting, and deposit tracking.

**How funds flow:**
```
Customer sends ETH → Forwarder Address (0xABC...)
                            ↓ (auto-forward on receipt)
                      Root Wallet Contract (0xDEF...)
                            ↓ (when you call send)
                      Recipient Address
```

### Creating a Forwarder Address

```typescript
const wallet = await bitgo.coin('hteth').wallets().get({ id: walletId });

const address = await wallet.createAddress({
  walletVersion: 3,  // REQUIRED for ECDSA/multisig ETH addresses
  label: 'Customer Deposit Address #1',  // optional label
  // gasPrice: '50000000000',  // optional: explicit gas price for deployment (gwei)
  // lowPriority: false,       // optional: use low-priority fee key
});
```

**cURL equivalent:**
```bash
curl -X POST \
  "https://app.bitgo-test.com/api/v2/hteth/wallet/$WALLET_ID/address" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
# No body needed for default parameters
```

**Address creation response:**
```json
{
  "id": "631283e10e052800066295e210da142a",
  "address": "0x2N9wCEV3KGEFsyo9xoUGjVYaSVwjSueutjz",
  "chain": 10,
  "index": 2,
  "coin": "hteth",
  "wallet": "6312824bf3281c0006fedaad1d667e67",
  "pendingChainInitialization": true,  // WAIT for false before using!
  "coinSpecific": {
    "baseAddress": "0xRootWalletAddress",  // the root wallet
    "forwarderVersion": 1
  },
  "keychains": [
    { "id": "...", "source": "user", "pub": "xpub...", "ethAddress": "0x..." },
    { "id": "...", "source": "backup", "pub": "xpub..." },
    { "id": "...", "source": "bitgo", "pub": "xpub...", "isBitGo": true }
  ]
}
```

**CRITICAL:** `pendingChainInitialization: true` means the forwarder contract deployment transaction has not yet confirmed. Do NOT send assets to this address until it is `false`.

### Gas Costs for Forwarder Operations

From [BitGo Ethereum docs](https://developers.bitgo.com/coins/Ethereum):

| Operation | Gas Cost |
|---|---|
| Creating forwarder contract address | ~102,000 gas |
| Deploying forwarder contract (first ETH received) | ~154,000 gas |
| Moving assets from forwarder to root | ~63,662 gas |

**Creating a forwarder address costs gas** (paid from your gas tank). The deployment transaction confirms on-chain before the address is usable.

### Forwarder Address Flow (walletVersion 3)

```
1. wallet.createAddress({ walletVersion: 3 })
   → BitGo deploys forwarder contract on-chain using gas tank
   → Returns address with pendingChainInitialization: true

2. Wait for pendingChainInitialization: false
   → Poll wallet.getAddress({ id }) or listen for webhook

3. Customer sends ETH to forwarder address
   → Forwarder contract auto-forwards to root wallet

4. wallet.sendMany() from the root wallet
   → Funds come from root wallet balance (post-consolidation)
```

### `walletVersion: 3` Requirement

The `walletVersion: 3` parameter in `createAddress()` is only required if your wallet was created with ECDSA/onchain multisig. For TSS wallets (v6), addresses don't use forwarders — they use direct consolidation.

From the [BitGo Create Addresses docs](https://developers.bitgo.com/guides/wallets/create/addresses):
> "walletVersion: 3 — Required for ECDSA assets, such as ETH and MATIC"

---

## 7. Sending Transactions

### `wallet.sendMany()` — Recommended Send Method

```typescript
const wallet = await bitgo.coin('hteth').wallets().get({ id: walletId });

const result = await wallet.sendMany({
  // REQUIRED
  recipients: [
    {
      address: '0xRecipientAddress',
      amount: '1000000000000000000',  // in WEI (string!) — 1 ETH = 1e18 wei
    },
    // ETH supports multiple recipients in one tx (sendMany)
    // BUT: ERC-20 tokens only support single recipient!
  ],
  walletPassphrase: 'yourWalletPassphrase',

  // OPTIONAL
  type: 'transfer',              // 'transfer' | 'stake' | etc.
  comment: 'Payment for X',
  minConfirms: 0,                // minimum confirmations required for unspents
  enforceMinConfirmsForChange: false,
  sequenceId: 'unique-id-123',  // idempotency key — prevents double-send on retry
  
  // Fee options (ETH)
  feeOptions: {
    maxFeePerGas: '50000000000',      // max fee per gas in wei (EIP-1559)
    maxPriorityFeePerGas: '2000000000', // max tip per gas in wei
    // OR legacy:
    gasPrice: '50000000000',          // in wei
    gasLimit: 21000,                  // optional gas limit override
  },
});
```

**SDK wrapper: `wallet.send()` for single recipient:**
```typescript
// Convenience wrapper — internally calls sendMany with 1 recipient
const result = await wallet.send({
  address: '0xRecipient',
  amount: '1000000000000000000',  // wei, as string
  walletPassphrase: 'pass',
});
```

### Amount Format: ALWAYS WEI AS STRING

```typescript
// 1 ETH in wei
const oneEth = '1000000000000000000';  // 1e18 as string

// 0.01 ETH in wei
const pointZeroOneEth = '10000000000000000';  // 1e16 as string

// Conversion helpers
const weiString = (ethAmount: number): string =>
  (BigInt(Math.round(ethAmount * 1e18))).toString();

// Or use ethers.js
import { parseEther } from 'ethers';
const amount = parseEther('0.01').toString(); // '10000000000000000'
```

> **CRITICAL:** Amount must be a **string** (not number). JavaScript numbers lose precision for large integers. Always use BigInt or string math for wei amounts.

From [BitGo Ethereum docs](https://developers.bitgo.com/coins/ethereum):
> "Ether balances are only in string format: balanceString, confirmedBalanceString, spendableBalanceString"

### `wallet.sendMany()` Response: Two Cases

**Case 1: Transaction sent immediately (no policy trigger):**
```json
{
  "txid": "0xabc123...",
  "tx": "0xf86c...",
  "transfer": {
    "id": "transfer-id",
    "coin": "hteth",
    "wallet": "wallet-id",
    "value": -1000000000000000000,
    "valueString": "-1000000000000000000",
    "state": "unconfirmed",
    "type": "send",
    "txid": "0xabc123..."
  }
}
```

**Case 2: Policy triggered → Pending Approval created:**
```json
{
  "error": "Policy violation: transaction requires approval",
  "pendingApproval": {
    "id": "66edb22fbef3fef723292c7b14ae01f3",
    "coin": "hteth",
    "wallet": "wallet-id",
    "state": "pending",
    "scope": "wallet",
    "info": {
      "type": "transactionRequest",
      "transactionRequest": {
        "recipients": [{ "address": "0x...", "amount": "1000000000000000000" }]
      }
    },
    "approvalsRequired": 1
  }
}
```

### Fee Handling

Ethereum fees are dynamic (EIP-1559). BitGo handles fee estimation automatically if you don't specify `feeOptions`. The gas tank (enterprise fee address) pays for deployment-related gas; transaction gas is paid from the sending wallet's ETH balance.

**Estimate fees before sending:**
```bash
GET https://app.bitgo-test.com/api/v2/hteth/tx/fee
Authorization: Bearer $ACCESS_TOKEN
```

Response:
```json
{
  "feeEstimate": "21000",
  "gasPrice": "50000000000",
  "baseFeePerGas": "...",
  "maxPriorityFeePerGas": "..."
}
```

### Pending Approvals Flow

When a `wallet.sendMany()` triggers a policy (whitelist violation, spending limit exceeded, etc.):

```typescript
// 1. Send returns with pendingApproval
const sendResult = await wallet.sendMany({ ... });

if (sendResult.pendingApproval) {
  const approvalId = sendResult.pendingApproval.id;
  
  // 2. A second user/approver fetches the pending approval
  const pa = await bitgo.coin('hteth').pendingApprovals().get({ id: approvalId });
  
  // 3. Approver approves it (must be a different user from the initiator if
  //    "initiatorIsAllowedToApprove: false" was set in the policy)
  const approved = await pa.approve({
    otp: '0000000',
    walletPassphrase: 'approverPassphrase',
  });
}
```

**cURL to approve:**
```bash
curl -X PUT \
  https://app.bitgo-test.com/api/v2/pendingApprovals/$APPROVAL_ID \
  -H "Authorization: Bearer $APPROVER_ACCESS_TOKEN" \
  -d '{"state": "approved", "otp": "0000000"}'
```

**List all pending approvals:**
```bash
GET https://app.bitgo-test.com/api/v2/pendingApprovals
Authorization: Bearer $ACCESS_TOKEN
```

---

## 8. BitGo REST API Reference

### Base URLs

| Environment | Base URL |
|---|---|
| **Test** | `https://app.bitgo-test.com` |
| **Production** | `https://app.bitgo.com` |
| **BitGo Express (local)** | `http://localhost:3080` |

### Authentication Headers

```
Authorization: Bearer <ACCESS_TOKEN>
Content-Type: application/json
```

### Key REST Endpoints

#### Authentication

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/v2/user/login` | Get short-lived access token |
| `POST` | `/api/v2/user/accesstoken` | Create long-lived access token |
| `POST` | `/api/v2/user/unlock` | Unlock session for spending |
| `POST` | `/api/v2/user/lock` | Re-lock session |

#### Wallet Management

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/v2/{coin}/wallet/generate` | Generate new wallet (via Express) |
| `GET` | `/api/v2/{coin}/wallet` | List wallets |
| `GET` | `/api/v2/{coin}/wallet/{walletId}` | Get wallet by ID |
| `POST` | `/api/v2/{coin}/wallet/{walletId}/address` | Create address/forwarder |
| `GET` | `/api/v2/{coin}/wallet/{walletId}/addresses` | List addresses |

#### Transactions

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/v2/{coin}/wallet/{walletId}/sendcoins` | Send (via Express — handles signing) |
| `POST` | `/api/v2/{coin}/wallet/{walletId}/sendmany` | Send to multiple (via Express) |
| `GET` | `/api/v2/{coin}/wallet/{walletId}/transfers` | List transfers |
| `GET` | `/api/v2/{coin}/tx/fee` | Get fee estimate |

#### Policies (Old API)

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/v2/{coin}/wallet/{walletId}/policy/rule` | Add policy rule |
| `PUT` | `/api/v2/{coin}/wallet/{walletId}/policy/rule` | Update policy rule |
| `DELETE` | `/api/v2/{coin}/wallet/{walletId}/policy/rule` | Delete policy rule |

#### Policies (New Enterprise API)

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/policy/v1/enterprises/{id}/scopes` | List scopes |
| `GET` | `/api/policy/v1/enterprises/{id}/scopes/{scopeId}/touchpoints` | List touchpoints |
| `POST` | `/api/policy/v1/enterprises/{id}/touchpoints/{tp}/rules` | Create rule |
| `PUT` | `/api/policy/v1/enterprises/{id}/touchpoints/{tp}/rules/{ruleId}` | Update rule |
| `GET` | `/api/policy/v1/enterprises/{id}/touchpoints/{tp}/rules` | List rules |

#### Pending Approvals

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/v2/pendingApprovals` | List pending approvals |
| `GET` | `/api/v2/{coin}/pendingapprovals/{approvalId}` | Get one approval |
| `PUT` | `/api/v2/pendingApprovals/{approvalId}` | Approve/reject |

#### Gas Tank

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/v2/{coin}/enterprise/{enterpriseId}/feeAddressBalance` | Check gas tank balance |

### Minimal Example: Create Wallet via REST (No SDK)

```bash
# Step 1: Login
export ACCESS_TOKEN=$(curl -s -X POST https://app.bitgo-test.com/api/v2/user/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"your@email.com","password":"pass","otp":"0000000"}' \
  | jq -r '.access_token')

# Step 2: Unlock session
curl -X POST https://app.bitgo-test.com/api/v2/user/unlock \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -d '{"otp":"0000000","duration":3600}'

# Step 3: Generate wallet (must go through BitGo Express for signing)
# BitGo Express handles key generation locally, then registers with BitGo
curl -X POST http://localhost:3080/api/v2/hteth/wallet/generate \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "label": "My Hoodi Wallet",
    "passphrase": "SecurePass123",
    "enterprise": "'$ENTERPRISE_ID'"
  }'
```

**BitGo Express** is required for operations that involve signing (wallet generation, transaction signing). It runs locally and handles private key operations.

### BitGo Express Setup

```bash
# Run via Docker
docker run -p 3080:3080 bitgo/express:latest \
  --env test \
  --bind 0.0.0.0

# Or via npm
npx @bitgo/express --env test --bind 0.0.0.0 --port 3080
```

---

## 9. Webhooks & Callbacks

### Overview

BitGo supports webhooks for real-time notifications on wallet events. Events are POSTed to your server.

**Source:** [BitGo Webhooks Overview](https://developers.bitgo.com/docs/webhooks-overview)

### Webhook Types

| Webhook Type | Description | Use Case |
|---|---|---|
| **Transfer** | Fires on any transfer (deposit or withdrawal) | Deposit detection, withdrawal confirmation |
| **Pending Approval** | Fires when a policy triggers requiring approval | Approval workflow notifications |
| **Transaction** | On-chain transaction events | Confirmation tracking |

### Creating a Wallet Webhook

```bash
curl -X POST \
  "https://app.bitgo-test.com/api/v2/hteth/wallet/$WALLET_ID/webhooks" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -d '{
    "type": "transfer",
    "url": "https://your-server.com/webhook/bitgo",
    "numConfirmations": 1,
    "allToken": true,
    "listenToFailureStates": false
  }'
```

**For pendingApproval notifications:**
```bash
-d '{
    "type": "pendingapproval",
    "url": "https://your-server.com/webhook/approval",
    "numConfirmations": 0
  }'
```

### Webhook Security

```bash
# Create webhook secret (for HMAC verification)
POST https://app.bitgo-test.com/api/v2/webhooks/secret
```

BitGo signs each webhook payload with HMAC-SHA256 using your secret. The signature is in the `x-signature-sha256` header:

```typescript
import crypto from 'crypto';

function verifyWebhook(payload: string, signature: string, secret: string): boolean {
  const expected = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return `sha256=${expected}` === signature;
}

// In your Express handler:
app.post('/webhook/bitgo', (req, res) => {
  const sig = req.headers['x-signature-sha256'];
  const body = JSON.stringify(req.body);
  
  if (!verifyWebhook(body, sig, process.env.WEBHOOK_SECRET)) {
    return res.status(401).send('Invalid signature');
  }
  
  // Process webhook
  if (req.body.type === 'pendingapproval') {
    handlePendingApproval(req.body);
  }
  
  res.status(200).send('OK');
});
```

### Webhook Retry Policy

- BitGo retries failed webhooks (no `HTTP 200` response)
- Up to 7 retries after initial attempt
- Retry intervals: `1, 5, 10, 30, 60, 120, 240 minutes`
- Suspends after 100 failures in 1 week or 500 lifetime failures

### Idempotency

Use `idempotency-key` header in requests to avoid processing duplicate webhooks.

### Webhook Payload — Transfer Event

```json
{
  "type": "transfer",
  "version": 2,
  "walletId": "wallet-id",
  "enterpriseId": "enterprise-id",
  "coin": "hteth",
  "transfer": {
    "id": "transfer-id",
    "coin": "hteth",
    "wallet": "wallet-id",
    "txid": "0xabc123...",
    "value": 1000000000000000000,
    "valueString": "1000000000000000000",
    "confirmedTime": "...",
    "type": "receive",
    "state": "confirmed",
    "entries": [
      { "address": "0xForwarderAddress", "value": 1000000000000000000 }
    ]
  }
}
```

### Webhook Payload — Pending Approval Event

```json
{
  "type": "pendingapproval",
  "version": 2,
  "walletId": "wallet-id",
  "enterpriseId": "enterprise-id",
  "pendingApprovalId": "66edb22fbef3fef723292c7b14ae01f3",
  "state": "pending"
}
```

---

## 10. Error Handling & Known Issues

### Common HTTP Error Codes

| Code | Meaning | Common Cause |
|---|---|---|
| `400` | Bad Request | Missing required parameter (e.g., no enterprise ID for ETH wallet) |
| `401` | Unauthorized | Missing/expired token, or session not unlocked for spending |
| `403` | Forbidden | Insufficient scope/permission on access token |
| `404` | Not Found | Wallet/address ID doesn't exist |
| `409` | Conflict | Duplicate sequenceId (idempotency hit) |
| `429` | Rate Limited | Too many requests |

### Common SDK Errors

#### "enterprise is required when creating ETH wallet"
```
Error: expecting enterprise when adding BitGo key.
If you want to create a new ETH bitgo key, set the newFeeAddress parameter to true.
```
**Fix:** Always pass `enterprise: '<enterpriseId>'` when creating ETH/hteth wallets.

#### Gas Tank Not Funded
When creating a wallet or address, if the gas tank is empty:
```
Error: insufficient balance to pay for gas
```
**Fix:** Fund your enterprise gas tank address with Hoodi ETH before wallet/address creation.

#### Pending Chain Initialization
```
Error: wallet is pending chain initialization
```
**Fix:** Wait for `pendingChainInitialization: false` on the wallet before transacting. Poll `wallet.get()` or set up a webhook.

#### "key count must equal 3"
When using the low-level `wallets().add()` API:
```json
{"error": "key count must equal 3", "name": "Invalid"}
```
**Fix:** Use `generateWallet()` instead of `add()` for automatic key creation.

#### "items must be object, received item of type: string"
When adding addresses to whitelist policy.
**Fix:** Wrap the address in an object: `{ item: ['0xAddress'], type: 'address' }` — use array format.

#### OTP Required for Spending
```
Error: session is locked
```
**Fix:** Call `await bitgo.unlock({ otp: '0000000', duration: 3600 })` before any send operation.

### Known SDK Issues (from [GitHub issues](https://github.com/bitgo/bitgojs/issues))

| Issue | Status | Workaround |
|---|---|---|
| `window is not defined` in Node environments | Ongoing | Use `globalThis` shim or server-side only |
| `Cannot find module 'node:crypto'` | Ongoing | Use Node 18+ |
| USDC support for test purposes | Bug | Use hteth:usdc or contact BitGo support |
| Priority fee for stuck transactions | Open | Manually set `maxPriorityFeePerGas` in feeOptions |
| npm install issues with latest bitgo | Periodic | Pin to a specific version (e.g., `[email protected]`) |

### Rate Limits

BitGo doesn't publish specific rate limit numbers. General guidance:
- Avoid rapid-fire requests in loops — add small delays (100-500ms)
- Use `sequenceId` for transaction idempotency to avoid retrying already-sent transactions
- The transaction list endpoint is paginated at 250 per page

### The 48-Hour Policy Lock: A Critical Gotcha

Repeated here because it's the #1 gotcha for hackathon builders:

1. Create policies within the first 48 hours
2. Test them thoroughly during this window
3. Set `action: { type: 'getApproval' }` instead of `deny` — this allows transaction flow even with policy triggers (you just need to approve)
4. For truly flexible hackathon builds: use enterprise policies (new API) at the touchpoint level rather than wallet-level whitelist policies, as enterprise policies are easier to manage

### sendMany Unsupported Coins

`wallet.sendMany()` does NOT work for:
- `HTETH:BGERCH` (BitGo ERC-20 token)
- ALGO, ARBETH, AVAXC, CELO, DOT, EOS, NEAR, OPETH, STX, TON, TRX, XLM, XRP, XTZ

For unsupported coins, use the raw transaction build/sign/send flow.

### Wallet Policy: "Wallet-policies apply only to transactions that involve the BitGo key"

From [Create Whitelists docs](https://developers.bitgo.com/docs/wallets-whitelists-create):
> "Wallet-policies apply only to transactions that involve the BitGo key. Transactions that use the user key and the backup key bypass wallet policies."

This means: if someone uses the backup key directly (e.g., via wallet recovery), wallet policies are bypassed.

---

## 11. Quick Reference Cheatsheet

### Setup Boilerplate (TypeScript)

```typescript
import { BitGoAPI } from '@bitgo/sdk-api';
import { Hteth } from '@bitgo/sdk-coin-eth';
import dotenv from 'dotenv';
dotenv.config();

// Initialize SDK
const bitgo = new BitGoAPI({ env: 'test' });
bitgo.register('hteth', Hteth.createInstance);
const coin = bitgo.coin('hteth');

// Authenticate
async function init() {
  await bitgo.authenticate({
    username: process.env.BITGO_USERNAME!,
    password: process.env.BITGO_PASSWORD!,
    otp: '0000000',  // always in test
  });
  await bitgo.lock();
  await bitgo.unlock({ otp: '0000000', duration: 3600 });
}

// OR with pre-made access token:
// bitgo.authenticateWithAccessToken({ accessToken: process.env.BITGO_ACCESS_TOKEN! });
```

### Create Wallet + First Address

```typescript
async function createWallet() {
  const { wallet } = await coin.wallets().generateWallet({
    label: 'Hackathon HTeth Wallet',
    passphrase: process.env.WALLET_PASSPHRASE!,
    enterprise: process.env.ENTERPRISE_ID!,
    // walletVersion: 3,  // default for onchain multisig
  });
  
  console.log('Wallet ID:', wallet.id());
  console.log('Receive address:', wallet.receiveAddress());
  
  // Wait for on-chain init before creating addresses
  // (poll wallet.get() until pendingChainInitialization === false)
  
  return wallet;
}
```

### Create Forwarder Address

```typescript
async function createForwarder(walletId: string) {
  const wallet = await coin.wallets().get({ id: walletId });
  const address = await wallet.createAddress({
    walletVersion: 3,
    label: `Deposit #${Date.now()}`,
  });
  
  // address.pendingChainInitialization === true — wait before using
  return address;
}
```

### Send ETH

```typescript
async function sendEth(walletId: string, toAddress: string, amountEth: number) {
  const wallet = await coin.wallets().get({ id: walletId });
  const amountWei = (BigInt(Math.round(amountEth * 1e15)) * BigInt(1e3)).toString();
  
  const result = await wallet.sendMany({
    recipients: [{ address: toAddress, amount: amountWei }],
    walletPassphrase: process.env.WALLET_PASSPHRASE!,
    sequenceId: `send-${Date.now()}`,
  });
  
  if (result.pendingApproval) {
    console.log('Policy triggered! Approval needed:', result.pendingApproval.id);
  } else {
    console.log('Sent! TXID:', result.txid);
  }
  
  return result;
}
```

### Set Address Whitelist Policy

```typescript
async function setWhitelist(wallet: any, addresses: string[]) {
  for (const addr of addresses) {
    await wallet.createPolicyRule({
      id: 'hackathon-whitelist',
      type: 'advancedWhitelist',
      condition: {
        add: { item: addr, type: 'address' }
      },
      action: { type: 'getApproval' }  // not 'deny' — keeps flexibility
    });
  }
}
```

### Environment Variables Template

```env
BITGO_ENV=test
BITGO_USERNAME=your@email.com
BITGO_PASSWORD=yourPassword
BITGO_ACCESS_TOKEN=v2xYourLongLivedToken
ENTERPRISE_ID=yourEnterpriseId
WALLET_ID=yourWalletId
WALLET_PASSPHRASE=yourWalletPassphrase
WEBHOOK_SECRET=yourWebhookSecret
```

### Key Numbers to Remember

| Constant | Value |
|---|---|
| Test OTP | `0000000` (7 zeroes) |
| 1 ETH in wei | `1000000000000000000` (1e18) |
| Hoodi Chain ID | `560048` |
| hteth coin ID | `hteth` |
| walletVersion for ECDSA ETH | `3` |
| walletVersion for TSS/MPC ETH | `6` |
| Policy lock window | 48 hours |
| Forwarder deployment cost | ~102,000 gas |
| Webhook retries | 7 (intervals: 1, 5, 10, 30, 60, 120, 240 min) |
| SDK min Node version | 20 |
| @bitgo/sdk-api version | 1.63.2 |
| @bitgo/sdk-coin-eth version | 25.0.1 |

---

## Sources

- [BitGo Developer Portal](https://developers.bitgo.com)
- [BitGo Ethereum Coin Page](https://developers.bitgo.com/coins/ethereum) — faucet, wallet types, tx examples
- [BitGo Create Addresses Guide](https://developers.bitgo.com/guides/wallets/create/addresses) — forwarder creation, walletVersion
- [BitGo Create Whitelists Guide](https://developers.bitgo.com/docs/wallets-whitelists-create) — advancedWhitelist API
- [BitGo Create Policy Rules Guide](https://developers.bitgo.com/docs/policies-create) — new enterprise policy API
- [BitGo Access Tokens Guide](https://developers.bitgo.com/docs/get-started-access-tokens) — authentication, OTP
- [BitGo Webhooks Overview](https://developers.bitgo.com/docs/webhooks-overview) — webhook setup and security
- [BitGo Create Wallets Guide](https://developers.bitgo.com/docs/wallets-create-wallets) — generateWallet parameters and response
- [BitGo Wallet Types](https://developers.bitgo.com/docs/wallet-types) — multisig vs MPC, wallet versions
- [BitGo Changelog](https://developers.bitgo.com/changelog) — SDK v3.8.0+ required, v2x token prefix
- [@bitgo/sdk-api on npm](https://www.npmjs.com/package/@bitgo/sdk-api) — v1.63.2
- [@bitgo/sdk-coin-eth on npm](https://www.npmjs.com/package/@bitgo/sdk-coin-eth) — v25.0.1
- [BitGoJS GitHub](https://github.com/BitGo/BitGoJS) — source code
- [BitGo CLI v2 GitHub](https://github.com/BitGo/bitgo-cli-v2) — OTP confirmation (0000000)
- [eth-clients/hoodi GitHub](https://github.com/eth-clients/hoodi) — Chain ID 560048
- [hoodi.dev](https://hoodi.dev) — Hoodi testnet details
- [Ethereum Foundation Blog: Holesky Shutdown](https://blog.ethereum.org/2025/09/01/holesky-shutdown-announcement)
- [GetBlock Hoodi RPC announcement](https://getblock.io/blog/getblock-launches-ethereum-hoodi-testnet-rpc--holesky-endpoints-deprecated/)
- [hoodi-faucet.pk910.de](https://hoodi-faucet.pk910.de) — official Hoodi faucet
- [BitGoJS Issues — GitHub](https://github.com/bitgo/bitgojs/issues) — known bugs
- [Reddit: BitGo policy lock gotcha](https://www.reddit.com/r/mtgoxinsolvency/comments/1emnjza/bitgo_users_beware_policy_unlocks_are_only/)
