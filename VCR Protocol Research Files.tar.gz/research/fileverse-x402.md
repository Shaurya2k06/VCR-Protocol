# Fileverse Agents SDK & x402 Protocol — Exhaustive Research
> Compiled: March 13, 2026 | For hackathon build reference

---

## TABLE OF CONTENTS

- [PART 1: Fileverse Agents SDK](#part-1-fileverse-agents-sdk)
  - [1. NPM Package Overview](#1-npm-package-overview)
  - [2. Full API — Agent Class Methods](#2-full-api--agent-class-methods)
  - [3. Constructor Parameters](#3-constructor-parameters)
  - [4. Storage Model — IPFS + Gnosis Chain](#4-storage-model--ipfs--gnosis-chain)
  - [5. Gnosis Chain Details](#5-gnosis-chain-details)
  - [6. GitHub Repos & Examples](#6-github-repos--examples)
  - [7. Known Issues & Limitations](#7-known-issues--limitations)
  - [8. Alternative IPFS Approaches (Fallbacks)](#8-alternative-ipfs-approaches-fallbacks)
- [PART 2: x402 Protocol](#part-2-x402-protocol)
  - [1. What is x402?](#1-what-is-x402)
  - [2. Full Protocol Flow](#2-full-protocol-flow)
  - [3. HTTP Header Format (v2)](#3-http-header-format-v2)
  - [4. Payment Payload Type Specifications](#4-payment-payload-type-specifications)
  - [5. Exact Scheme on EVM — Deep Dive](#5-exact-scheme-on-evm--deep-dive)
  - [6. Coinbase x402 Implementation — Packages & Code](#6-coinbase-x402-implementation--packages--code)
  - [7. Integration with canAgentSpend() / VCR Policy](#7-integration-with-canagenspend--vcr-policy)
  - [8. Networks, Assets, Facilitators](#8-networks-assets-facilitators)
  - [9. Ecosystem: Other Implementations](#9-ecosystem-other-implementations)
  - [10. x402 V2 Changes](#10-x402-v2-changes)

---

# PART 1: Fileverse Agents SDK

## 1. NPM Package Overview

**Package:** [`@fileverse/agents`](https://www.npmjs.com/package/@fileverse/agents)  
**Latest Version:** `2.0.1`  
**Last Published:** 2025-03-17 (approximately 6 months before this research)  
**License:** AGPL-3.0 (matches Fileverse's general open-source licensing)  
**Zero dependents:** No other public NPM packages depend on it yet.

```bash
npm install @fileverse/agents
```

**Required peer dependencies (you must install separately):**
- `viem` — for account creation (`privateKeyToAccount`)
- `pinata` or equivalent — as the `storageProvider`

**Key dependencies included transitively:**
- `permissionless` — for ERC-4337 Safe smart account creation via Pimlico
- `viem` — Ethereum interaction library
- Pimlico SDK — for account abstraction/bundler

---

## 2. Full API — Agent Class Methods

The main export is the `Agent` class from `@fileverse/agents`. Based on the official README, GitHub repo, and agents.fileverse.io documentation:

### Exported Symbols

```typescript
import { Agent } from '@fileverse/agents';
import { PinataStorageProvider } from '@fileverse/agents/storage';
```

### Complete Method List

| Method | Signature | Description |
|---|---|---|
| `constructor` | `new Agent(config: AgentConfig)` | Creates agent instance (does NOT deploy contract yet) |
| `setupStorage` | `async setupStorage(namespace: string): Promise<void>` | Deploys Safe + Portal contract OR loads existing from `creds/${namespace}.json`. This is your "init". |
| `create` | `async create(content: string): Promise<FileResult>` | Uploads markdown content to IPFS via storageProvider, registers CID onchain |
| `getFile` | `async getFile(fileId: string): Promise<FileData>` | Retrieves a file by its fileId (CID-derived identifier) |
| `update` | `async update(fileId: string, content: string): Promise<FileResult>` | Updates file content — creates new IPFS pin, updates registry |
| `delete` | `async delete(fileId: string): Promise<DeleteResult>` | Removes file from onchain registry (IPFS pin may persist) |
| `getBlockNumber` | `async getBlockNumber(): Promise<bigint>` | Returns latest block number on the configured chain |

> **Note on `writeFile` / `readFile` / `listFiles`:** These exact method names do NOT appear in the SDK. The SDK uses `create`, `getFile`, `update`, `delete`. There is no `listFiles` in the public API — file listing is done through the onchain portal contract or the agents.fileverse.io explorer UI.

### Return Type of `create()`

The `create()` call returns a `FileResult` object. Based on the example code:

```javascript
const file = await agent.create('Hello World');
console.log(`File created: ${file}`);
// file.fileId — the identifier used for subsequent operations
```

The `fileId` is likely a CID or CID-derived string. The exact shape is:
```typescript
type FileResult = {
  fileId: string;    // Unique identifier (CID or registry ID)
  // possibly: cid, txHash, etc.
}
```

> **Clarification needed:** The README does not explicitly document whether `file.cid` is separately exposed or just `file.fileId`. For a hackathon, log the full object to inspect.

---

## 3. Constructor Parameters

```typescript
import { Agent } from '@fileverse/agents';
import { privateKeyToAccount } from 'viem/accounts';
import { PinataStorageProvider } from '@fileverse/agents/storage';

const storageProvider = new PinataStorageProvider({
  jwt: process.env.PINATA_JWT,           // Required: Pinata JWT token
  gateway: process.env.PINATA_GATEWAY   // Required: e.g. "cyan-adjacent-jay-350.mypinata.cloud"
});

const agent = new Agent({
  chain: process.env.CHAIN,             // Required: 'gnosis' or 'sepolia'
  viemAccount: privateKeyToAccount(process.env.PRIVATE_KEY), // Required: viem Account instance
  pimlicoAPIKey: process.env.PIMLICO_API_KEY,               // Required: Pimlico bundler API key
  storageProvider                                            // Required: storage provider instance
});
```

### Parameter Details

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `chain` | `'gnosis' \| 'sepolia'` | Yes | Only two chains supported. `gnosis` = Gnosis mainnet (chainId 100). `sepolia` = Ethereum Sepolia testnet (chainId 11155111). |
| `viemAccount` | `Account` (viem) | Yes | Created via `privateKeyToAccount(privateKey)`. This is the EOA that owns the Safe. |
| `pimlicoAPIKey` | `string` | Yes | Get from [pimlico.io](https://pimlico.io). Used for ERC-4337 bundler + paymaster (enabling gasless txns). |
| `storageProvider` | `StorageProvider` | Yes | Currently only `PinataStorageProvider` is documented. See below for interface. |

### PinataStorageProvider Config

```typescript
new PinataStorageProvider({
  jwt: string,      // Pinata JWT — get from pinata.cloud Keys page
  gateway: string   // Your dedicated Pinata gateway domain (from pinata.cloud)
})
```

---

## 4. Storage Model — IPFS + Gnosis Chain

### Architecture Overview

```
Agent private key (EOA)
    │
    ▼
Safe Smart Account (ERC-4337 / AA)
    │ owns
    ▼
Fileverse Portal Smart Contract (Gnosis chain or Sepolia)
    │ stores registry of
    ▼
[ fileId → IPFS CID ] mappings
    │
    ▼
IPFS (via Pinata) — actual file content stored as .md
```

### How IPFS Works in the SDK

- **Storage backend:** Pinata (required). The `PinataStorageProvider` uses Pinata's API to pin files.
- **Content:** Files are stored as `.md` (Markdown) format. The SDK explicitly makes outputs human-readable markdown.
- **CID returned:** When you call `agent.create(content)`, the content is pinned to IPFS via Pinata, producing a CID. This CID (or a derived ID) is registered onchain.
- **Reading back by CID:** You can retrieve files via `agent.getFile(fileId)`. The SDK likely fetches the content through the Pinata gateway URL configured in `PinataStorageProvider`. Since Pinata pins are public by default, any IPFS gateway can serve the content by CID (e.g., `https://ipfs.io/ipfs/<CID>`).
- **Encryption:** **Not supported.** The README explicitly states: *"We don't support encryption of files yet. Please implement it on the application level if needed."*

### Gnosis Chain Registry

- A **"Portal"** smart contract is deployed on Gnosis (or Sepolia) per agent namespace.
- This contract acts as a **permissionless, public registry** of all the agent's outputs (file IDs/CIDs).
- The `setupStorage(namespace)` call either deploys a new Portal contract or loads an existing one (credentials stored in `creds/${namespace}.json`).
- The contract registry is queryable on-chain — it's what powers the [agents.fileverse.io](https://agents.fileverse.io) explorer feed.

### Safe Smart Account

- The agent uses a **Safe (formerly Gnosis Safe) Smart Account** via ERC-4337 Account Abstraction.
- Created during `setupStorage()` using Pimlico as the ERC-4337 bundler.
- The Safe's owner is the `viemAccount` (your EOA private key).
- Pimlico can **sponsor gas fees** (gasless transactions) if configured with a paymaster.
- **Key file:** `creds/${namespace}.json` stores the Safe address and portal contract address. **Keep this out of git.**

### File Monitoring / Explorer

- **URL:** https://agents.fileverse.io/
- Lists all agent outputs across chains. You can filter by chain (Gnosis / Sepolia) and see files, CIDs, and agent addresses.

---

## 5. Gnosis Chain Details

### Does the SDK need xDAI for gas?

**Short answer: Usually NO**, because Pimlico acts as a paymaster and sponsors gas via Account Abstraction (ERC-4337). The Safe smart account submits UserOperations, and Pimlico's paymaster covers the xDAI gas cost.

**Exception:** If you run out of Pimlico credits or don't configure a paymaster, you'd need xDAI in the Safe to pay gas. In practice for hackathons, the free Pimlico tier should suffice.

### Gnosis Chain Gas Costs

- Gnosis (xDAI) gas is **extremely cheap**: ~$0.0000003 per swap / ~< $0.01 per transaction
- A typical ERC-4337 UserOperation on Gnosis costs fractions of a cent
- The Portal contract deployment (first `setupStorage`) costs a bit more (smart contract deployment)

### Gnosis Chain Info

| Property | Value |
|---|---|
| Chain ID | 100 |
| Native token | xDAI (pegged to USD) |
| Gas price | ~1–4 Gwei (< $0.01/tx) |
| Block explorer | [gnosisscan.io](https://gnosisscan.io) |
| RPC | `https://rpc.gnosischain.com` |

### Testnet (Chiado)

- Chiado testnet (Chain ID: 10200) for Gnosis testing
- The SDK uses `sepolia` as testnet (Ethereum Sepolia, not Gnosis Chiado)
- **Sepolia faucets:** https://sepoliafaucet.com, https://faucet.sepolia.dev/

### xDAI Faucets (for Gnosis mainnet testing)

- Bridge DAI from Ethereum: https://bridge.gnosischain.com/
- Gnosis faucet: https://gnosisfaucet.com/

---

## 6. GitHub Repos & Examples

### Primary Repos

| Repo | URL | Description |
|---|---|---|
| SDK source | [github.com/fileverse/agents](https://github.com/fileverse/agents) | Main SDK. JavaScript. Last updated Mar 17, 2025. |
| Example app | [github.com/fileverse/agents-example](https://github.com/fileverse/agents-example) | Demonstrates AI model interaction + IPFS storage. JavaScript. |

### Fileverse Organization

- **GitHub org:** [github.com/fileverse](https://github.com/fileverse)
- 35 repositories including `agents`, `agents-example`, `fileverse-storage-service` (Go), `gun` (GUN relay)

### agents-example Key File: `index.js`

The example repo (`fileverse/agents-example`) is a ~31 line JavaScript file showing basic usage. Core pattern:

```javascript
import { Agent } from '@fileverse/agents';
import { privateKeyToAccount } from 'viem/accounts';
import { PinataStorageProvider } from '@fileverse/agents/storage';
import { config } from 'dotenv';

config();

const storageProvider = new PinataStorageProvider({
  jwt: process.env.PINATA_JWT,
  gateway: process.env.PINATA_GATEWAY
});

const agent = new Agent({
  chain: process.env.CHAIN,
  viemAccount: privateKeyToAccount(process.env.PRIVATE_KEY),
  pimlicoAPIKey: process.env.PIMLICO_API_KEY,
  storageProvider
});

// === INITIALIZATION ===
// This deploys (or loads) the Safe + Portal contract
// Writes credentials to creds/${namespace}.json
await agent.setupStorage('my-namespace');

// === BLOCK NUMBER (sanity check) ===
const latestBlockNumber = await agent.getBlockNumber();
console.log(`Latest block number: ${latestBlockNumber}`);

// === CREATE ===
const file = await agent.create('# Hello World\nThis is stored on IPFS and registered on Gnosis.');
console.log(`File created:`, file);
// file.fileId — use this for subsequent operations

// === READ ===
const fileData = await agent.getFile(file.fileId);
console.log(`File:`, fileData);

// === UPDATE ===
const updatedFile = await agent.update(file.fileId, '# Updated Content');
console.log(`File updated:`, updatedFile);

// === DELETE ===
const deletedFile = await agent.delete(file.fileId);
console.log(`File deleted:`, deletedFile);
```

### .env Template

```env
CHAIN=gnosis           # or 'sepolia'
PRIVATE_KEY=0x...      # EOA private key (owner of Safe)
PIMLICO_API_KEY=...    # From dashboard.pimlico.io
PINATA_JWT=...         # From pinata.cloud Keys page
PINATA_GATEWAY=...     # e.g. cyan-adjacent-jay-350.mypinata.cloud
```

> **IMPORTANT:** Add `creds/` to `.gitignore`. The credentials file contains the Safe's private keys for your agent's portal.

---

## 7. Known Issues & Limitations

### Official / Documented Limitations

1. **No file encryption.** All content stored on IPFS is public. Must implement app-level encryption if needed.
2. **Only two chains.** Only `gnosis` and `sepolia` are supported. No Base, Polygon, Arbitrum, etc.
3. **Only Pinata as storage.** `PinataStorageProvider` is the only documented storage provider. Other providers (web3.storage, Helia) are not officially supported.
4. **Markdown output only.** The SDK is designed for `.md` format. Binary files are not the primary use case.
5. **No `listFiles` method.** You can't list all files from the SDK; must use the onchain explorer or query the Portal contract directly.
6. **creds file risk.** `setupStorage()` writes `creds/${namespace}.json` to the filesystem — contains sensitive keys. Must be secured and gitignored.

### Potential Issues for Hackathon Builds

1. **SDK is relatively young** (first published ~Feb 2025, v2.0.1 in Mar 2025). Low adoption (0 dependents), small community.
2. **Pimlico API key required** — free tier available but you must sign up at [pimlico.io](https://pimlico.io).
3. **Pinata JWT + gateway required** — free tier available at [pinata.cloud](https://pinata.cloud). Note: as of 2025, Pinata has split into "public" and "private" networks.
4. **setupStorage is slow** on first run (deploys Safe + Portal contract = 2 onchain transactions).
5. **No TypeScript definitions explicitly mentioned** — SDK is JavaScript-first.
6. **Version 2.0.1 may have breaking changes** from v1.x — no changelog published in the README.
7. **IPFS pinning via Pinata means files are persistent** but unencrypted and public.

### GitHub Issues

The [fileverse/agents GitHub](https://github.com/fileverse/agents) shows very low activity (2 stars, 1 fork as of mid-2025). No public issue tracker activity noted in search results.

---

## 8. Alternative IPFS Approaches (Fallbacks)

### Option A: Pinata SDK (Recommended Fallback)

Pinata is already the backing storage for `@fileverse/agents`, so you can use it directly without the Fileverse SDK.

**Package:** `pinata` ([npm](https://www.npmjs.com/package/pinata))  
**Docs:** [docs.pinata.cloud/sdk/getting-started](https://docs.pinata.cloud/sdk/getting-started)

```bash
npm install pinata
```

```typescript
import { PinataSDK } from "pinata";

const pinata = new PinataSDK({
  pinataJwt: process.env.PINATA_JWT!,
  pinataGateway: "example-gateway.mypinata.cloud",
});

// Upload a file
const file = new File(["hello world!"], "hello.txt", { type: "text/plain" });
const upload = await pinata.upload.public.file(file);
console.log(upload);
// {
//   id: "0195f815-5c5e-716d-9240-d3ae380e2002",
//   name: "hello.txt",
//   cid: "bafkreidvbhs33ighmljlvr7zbv2ywwzcmp5adtf4kqvlly67cy56bdtmve",
//   created_at: "2025-04-02T19:58:24.616Z",
//   size: 12,
//   mime_type: "text/plain",
//   network: "public",
// }

// Retrieve a file by CID
const data = await pinata.gateways.public.get(
  "bafkreibm6jg3ux5qumhcn2b3flc3tyu6dmlb4xa7u5bf44yegnrjhc4yeq"
);

// Get a gateway URL for a CID
const url = await pinata.gateways.public.convert(
  "bafkreib4pqtikzdjlj4zigobmd63lig7u6oxlug24snlr6atjlmlza45dq"
);
```

**REST API (no SDK needed):**

```bash
# Pin a file
curl -X POST https://api.pinata.cloud/pinning/pinFileToIPFS \
  -H "Authorization: Bearer $PINATA_JWT" \
  -F "file=@./yourfile.txt"
# Returns: { "IpfsHash": "Qm...", "PinSize": 123, "Timestamp": "..." }

# Pin JSON
curl -X POST https://api.pinata.cloud/pinning/pinJSONToIPFS \
  -H "Authorization: Bearer $PINATA_JWT" \
  -H "Content-Type: application/json" \
  -d '{"pinataContent": {"key": "value"}, "pinataMetadata": {"name": "my-json"}}'

# Retrieve via gateway
GET https://{your-gateway}.mypinata.cloud/ipfs/{CID}
```

**Getting API Keys:**
1. Sign up at [pinata.cloud](https://pinata.cloud)
2. Go to API Keys → New Key → Grant `pinFileToIPFS` and `pinJSONToIPFS` permissions
3. Copy the JWT (not the API key/secret pair — the JWT is preferred)

---

### Option B: web3.storage / Storacha

> **Note:** web3.storage has rebranded and migrated to **Storacha** (storacha.network). The old API keys/tokens are deprecated. The new system uses DID-based authentication instead of API tokens.

**Old API (still works for existing tokens):**

```bash
# Upload via HTTP
curl -X POST https://api.web3.storage/upload \
  -H "Authorization: Bearer $WEB3_STORAGE_TOKEN" \
  -F "file=@./yourfile.txt"

# Add a pin
curl -X POST https://api.web3.storage/pins \
  -H "Authorization: Bearer $WEB3_STORAGE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"cid": "bafyXXX", "name": "myfile"}'

# List pins
GET https://api.web3.storage/pins
```

**New Storacha approach:** Email/GitHub auth, DID-based, CLI-first. Less suited for quick hackathon integrations compared to Pinata.

---

### Option C: Direct Helia (Node.js IPFS)

[Helia](https://github.com/ipfs/helia) is the current successor to `js-ipfs` for in-process IPFS nodes.

```bash
npm install helia @helia/unixfs
```

```typescript
import { createHelia } from 'helia';
import { unixfs } from '@helia/unixfs';

const helia = await createHelia();
const fs = unixfs(helia);

// Add a file
const encoder = new TextEncoder();
const cid = await fs.addBytes(encoder.encode('Hello, World!'));
console.log('Added file:', cid.toString());
// e.g. bafkreigtdiuapttqqa42ejxf7ngqnr3yvhsz6p4lzgqzufsocnkmxbxgua

// Read it back
const decoder = new TextDecoder();
let content = '';
for await (const chunk of fs.cat(cid)) {
  content += decoder.decode(chunk, { stream: true });
}
console.log('Retrieved:', content);

// Stop Helia
await helia.stop();
```

**Tradeoffs:**
- No external service needed
- Data not pinned externally — lost when node stops unless you add a remote pin service
- Good for local testing, not production persistence

---

### Summary Comparison

| Approach | Ext Service | Persistence | Free Tier | Complexity |
|---|---|---|---|---|
| Pinata SDK | Yes | Yes (pinned) | 1GB free | Low |
| Pinata REST API | Yes | Yes (pinned) | 1GB free | Very low |
| web3.storage/Storacha | Yes | Yes (Filecoin) | 5GB free | Medium |
| Helia (direct) | No | No (unless pinned) | n/a | High |

---

# PART 2: x402 Protocol

## 1. What is x402?

**x402** is an open, internet-native payment protocol that activates the long-dormant HTTP `402 Payment Required` status code, turning it into a fully-functional on-chain micropayment mechanism.

- **Developed by:** Coinbase Developer Platform (CDP), launched May 2025
- **GitHub:** [github.com/coinbase/x402](https://github.com/coinbase/x402) (4.2k stars, 763 forks, 88 contributors, 239 dependents)
- **Website:** [x402.org](https://x402.org)
- **Whitepaper:** [x402.org/x402.pdf](https://www.x402.org/x402.pdf)
- **License:** Apache-2.0
- **Current stats:** 75.41M transactions, $24.24M volume, 94.06K buyers, 22K sellers

### Core Design Principles

| Principle | Description |
|---|---|
| Open standard | Never forces reliance on a single party |
| HTTP Native | Fits existing HTTP request-response without extra round-trips |
| Chain & token agnostic | Supports any network, any ERC-20 token |
| Trust minimizing | Facilitator can only broadcast; cannot redirect funds |
| Easy to use | 1 line for server, 1 function call for client |
| Gasless | Client and server don't need to think about gas |

### Key Terms

- **Resource:** Any HTTP-accessible API, webpage, or service
- **Client:** Entity wanting to pay (AI agent, browser, app)
- **Facilitator Server:** Third-party service that verifies/settles on-chain payments (handles gas)
- **Resource Server:** HTTP server that enforces payment via middleware

---

## 2. Full Protocol Flow

### V1 Protocol Sequence (11 Steps)

```
CLIENT                   RESOURCE SERVER              FACILITATOR SERVER
  │                           │                              │
  │──── GET /resource ────────▶│                              │
  │                           │                              │
  │◀─── 402 Payment Required ─│                              │
  │     Body: PaymentRequired JSON                           │
  │     (x402Version, accepts[], error)                      │
  │                           │                              │
  │  [Client selects payment requirement]                    │
  │  [Client creates Payment Payload from scheme]            │
  │                           │                              │
  │──── GET /resource ────────▶│                              │
  │     X-PAYMENT: <base64 PaymentPayload>                   │
  │                           │                              │
  │                           │──── POST /verify ───────────▶│
  │                           │     {x402Version,            │
  │                           │      paymentHeader,          │
  │                           │      paymentRequirements}    │
  │                           │                              │
  │                           │◀─── {isValid, invalidReason}─│
  │                           │                              │
  │                    [if valid: do work]                   │
  │                           │                              │
  │                           │──── POST /settle ───────────▶│
  │                           │                              │
  │                           │                    [Submit to blockchain]
  │                           │                    [Wait for confirmation]
  │                           │                              │
  │                           │◀─── {success, txHash, ───────│
  │                           │      networkId, error}        │
  │                           │                              │
  │◀─── 200 OK ───────────────│                              │
  │     X-PAYMENT-RESPONSE: <base64 SettlementResponse>     │
  │     Body: requested resource                             │
```

### Simplified Flow (for hackathon understanding)

1. **Client → Server:** `GET /resource` (no payment)
2. **Server → Client:** `402 Payment Required` with payment details
3. **Client:** Creates signed payment payload (EIP-3009 authorization for USDC)
4. **Client → Server:** `GET /resource` with `X-PAYMENT` header
5. **Server → Facilitator:** Verify payment
6. **Facilitator → Server:** `{isValid: true}`
7. **Server → Facilitator:** Settle payment (submit to blockchain)
8. **Facilitator → Blockchain:** Broadcast transaction
9. **Facilitator → Server:** `{success: true, txHash: "0x..."}`
10. **Server → Client:** `200 OK` with resource + `X-PAYMENT-RESPONSE` header

> **Note on steps 1-2:** Optional if client already knows payment requirements.

---

## 3. HTTP Header Format (v2)

x402 **V2** uses three headers (note: V1 used `X-PAYMENT`; V2 switched to without the `X-` prefix):

| Header | Direction | Format | Purpose |
|---|---|---|---|
| `PAYMENT-REQUIRED` | Server → Client | Base64-encoded JSON | Returned with 402, contains payment requirements |
| `PAYMENT-SIGNATURE` | Client → Server | Base64-encoded JSON | Client sends signed payment payload |
| `PAYMENT-RESPONSE` | Server → Client | Base64-encoded JSON | Returned with 200, confirms settlement |

> **V1 used:** `X-PAYMENT` (client header) and `X-PAYMENT-RESPONSE` (server header). V2 dropped the `X-` prefix.

### PAYMENT-REQUIRED Header — Raw Example

```
HTTP/1.1 402 Payment Required
Content-Type: application/json
PAYMENT-REQUIRED: eyJ4NDAyVmVyc2lvbiI6MiwiZXJyb3IiOiJQQVlNRU5...

{}
```

The base64 decodes to:
```json
{
  "x402Version": 2,
  "error": "PAYMENT-SIGNATURE header is required",
  "resource": {
    "url": "https://api.example.com/premium-data",
    "description": "Access to premium market data",
    "mimeType": "application/json"
  },
  "accepts": [
    {
      "scheme": "exact",
      "network": "eip155:84532",
      "amount": "10000",
      "asset": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
      "payTo": "0x209693Bc6afc0C5328bA36FaF03C514EF312287C",
      "maxTimeoutSeconds": 60,
      "extra": {
        "name": "USDC",
        "version": "2"
      }
    }
  ]
}
```

### PAYMENT-SIGNATURE Header — Raw Example

```
POST /premium-data HTTP/1.1
Host: api.example.com
PAYMENT-SIGNATURE: eyJ4NDAyVmVyc2lvbiI6MiwicmVzb3VyY2Ui...
Content-Type: application/json
```

The base64 decodes to:
```json
{
  "x402Version": 2,
  "resource": {
    "url": "https://api.example.com/premium-data",
    "description": "Access to premium market data",
    "mimeType": "application/json"
  },
  "accepted": {
    "scheme": "exact",
    "network": "eip155:84532",
    "amount": "10000",
    "asset": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
    "payTo": "0x209693Bc6afc0C5328bA36FaF03C514EF312287C",
    "maxTimeoutSeconds": 60,
    "extra": {
      "name": "USDC",
      "version": "2"
    }
  },
  "payload": {
    "signature": "0x2d6a7588d6acca505cbf0d9a4...",
    "authorization": {
      "from": "0x857b06519E91e3A54538791bDbb0E22373e36b66",
      "to": "0x209693Bc6afc0C5328bA36FaF03C514EF312287C",
      "value": "10000",
      "validAfter": "1740672089",
      "validBefore": "1740672154",
      "nonce": "0xf3746613c2d920b5fdabc0856f2aeb2d4f88ee6037b8cc5d04a71a4462f13480"
    }
  }
}
```

### PAYMENT-RESPONSE Header (Success)

```
HTTP/1.1 200 OK
PAYMENT-RESPONSE: eyJzdWNjZXNzIjp0cnVlLCJ0cmFuc2Fj...

{ "data": "premium market data response" }
```

Decodes to:
```json
{
  "success": true,
  "transaction": "0x1234567890abcdef...",
  "network": "eip155:84532",
  "payer": "0x857b06519E91e3A54538791bDbb0E22373e36b66"
}
```

### Error Mapping

| x402 Error | HTTP Status |
|---|---|
| Payment Required | 402 |
| Invalid Payment | 400 |
| Payment Failed | 402 |
| Server Error | 500 |
| Success | 200 |

---

## 4. Payment Payload Type Specifications

### PaymentRequired Response (body of 402)

```typescript
type PaymentRequiredResponse = {
  x402Version: number;          // Protocol version (currently 2)
  accepts: PaymentRequirements[]; // List of accepted payment methods
  error: string;                // Error message (if any)
}
```

### PaymentRequirements (one item in `accepts[]`)

```typescript
type PaymentRequirements = {
  scheme: string;              // "exact" (more schemes coming: "upto", "stream")
  network: string;             // CAIP-2 identifier, e.g. "eip155:8453" (Base mainnet)
  maxAmountRequired: string;   // uint256 as string, in token's atomic units (e.g. USDC = 6 decimals)
  resource: string;            // URL of resource being paid for
  description: string;         // Human-readable description
  mimeType: string;            // MIME type of the response
  outputSchema?: object | null;// Optional JSON schema for response structure
  payTo: string;               // Ethereum address to receive payment
  maxTimeoutSeconds: number;   // Max seconds for resource server to respond
  asset: string;               // ERC-20 contract address (e.g. USDC on Base)
  extra: object | null;        // Scheme-specific extra data
}
```

### PaymentPayload (in `PAYMENT-SIGNATURE` header)

```typescript
type PaymentPayload = {
  x402Version: number;  // Protocol version
  scheme: string;       // "exact"
  network: string;      // CAIP-2 identifier
  payload: object;      // Scheme-dependent (see EIP-3009 example below)
}
```

### Facilitator API

**Base URL (Coinbase):** `https://api.developer.coinbase.com/rpc/v1/base/x402/facilitator`  
**Community facilitator:** `https://x402.org/facilitator`

```
POST /verify
Request:  { x402Version: number, paymentHeader: string, paymentRequirements: PaymentRequirements }
Response: { isValid: boolean, invalidReason: string | null }

POST /settle
Request:  { x402Version: number, paymentHeader: string, paymentRequirements: PaymentRequirements }
Response: { success: boolean, error: string | null, txHash: string | null, networkId: string | null }

GET /supported
Response: { kinds: [{ scheme: string, network: string }] }
```

---

## 5. Exact Scheme on EVM — Deep Dive

The `exact` scheme is the primary (and currently only) scheme available in production. It supports two asset transfer methods:

### AssetTransferMethod Comparison

| Method | Use Case | Recommendation |
|---|---|---|
| EIP-3009 | Tokens with native `transferWithAuthorization` (e.g., USDC) | **Recommended** — gasless, native |
| Permit2 | Any ERC-20 token | Universal fallback — works for any token |

### EIP-3009 Payment Payload (USDC on Base)

```json
{
  "x402Version": 2,
  "resource": {
    "url": "https://api.example.com/premium-data",
    "description": "Access to premium market data",
    "mimeType": "application/json"
  },
  "accepted": {
    "scheme": "exact",
    "network": "eip155:84532",
    "amount": "10000",
    "asset": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
    "payTo": "0x209693Bc6afc0C5328bA36FaF03C514EF312287C",
    "maxTimeoutSeconds": 60,
    "extra": {
      "assetTransferMethod": "eip3009",
      "name": "USDC",
      "version": "2"
    }
  },
  "payload": {
    "signature": "0x2d6a7588...",
    "authorization": {
      "from": "0x857b06519E91e3A54538791bDbb0E22373e36b66",
      "to": "0x209693Bc6afc0C5328bA36FaF03C514EF312287C",
      "value": "10000",
      "validAfter": "1740672089",
      "validBefore": "1740672154",
      "nonce": "0xf3746613c2d920b5fdabc0856f2aeb2d4f88ee6037b8cc5d04a71a4462f13480"
    }
  }
}
```

**Key security properties:**
- Signature covers: `from`, `to`, `value`, `validAfter`, `validBefore`, `nonce`
- Facilitator cannot change the destination or amount
- Time-bounded: payment authorization expires at `validBefore`
- Replay-protected: unique `nonce` per payment

### Permit2 Proxy Contract

For tokens without EIP-3009, the `x402ExactPermit2Proxy` is used:

- **Canonical address:** `0x402085c248EeA27D92E8b30b2C58ed07f9E20001`
- Deployed at the same address across all EVM chains via CREATE2
- The proxy enforces that funds go only to the `witness.to` address (cannot be redirected by facilitator)

---

## 6. Coinbase x402 Implementation — Packages & Code

### Package Ecosystem

| Package | Version | Use Case |
|---|---|---|
| `x402` | 0.3.4 | Core types, schemas, utilities |
| `x402-express` | 0.6.0 | Express.js server middleware |
| `x402-fetch` | 0.4.2 | Fetch API wrapper (client) |
| `x402-axios` | — | Axios interceptor (client) |
| `x402-next` | — | Next.js middleware |
| `x402-hono` | — | Hono middleware |
| `@x402/express` | — | v2 Express middleware (scoped package) |
| `@x402/evm` | — | EVM scheme implementation |
| `@x402/axios` | — | v2 Axios client |
| `@x402/fetch` | — | v2 Fetch client |
| `@x402/core` | — | v2 core types |

> **v1 vs v2 packages:** `x402-express` is v1 style. `@x402/express` is v2 style. The v2 packages use scoped `@x402/*` naming and CAIP-2 network identifiers.

### Server: Express Middleware (v1 style)

```typescript
import express from "express";
import { paymentMiddleware, Network } from "x402-express";

const app = express();

app.use(paymentMiddleware(
  "0xYourAddress",
  {
    "/protected-route": {
      price: "$0.10",
      network: "base-sepolia",
      config: {
        description: "Access to premium content",
      }
    }
  }
));

app.get("/protected-route", (req, res) => {
  res.json({ message: "This content is behind a paywall" });
});

app.listen(3000);
```

### Server: Express Middleware (v2 style — recommended)

```typescript
import express from "express";
import cors from "cors";
import { paymentMiddleware } from "@x402/express";
import { x402ResourceServer, HTTPFacilitatorClient } from "@x402/core/server";
import { registerExactEvmScheme } from "@x402/evm/exact/server";

const app = express();
const payTo = "0xYOUR_WALLET_ADDRESS";

app.use(cors({
  origin: true,
  exposedHeaders: ["payment-required", "payment-response"],
}));

const facilitator = new HTTPFacilitatorClient({
  url: "https://x402.org/facilitator"  // or Coinbase CDP facilitator
});
const resourceServer = new x402ResourceServer(facilitator);
registerExactEvmScheme(resourceServer);

app.use(paymentMiddleware({
  "POST /api/data": {
    accepts: [{
      scheme: "exact",
      price: "$0.01",
      network: "eip155:8453",  // Base mainnet
      payTo,
    }],
    description: "Access to premium data endpoint",
    mimeType: "application/json",
  },
}, resourceServer));

app.post("/api/data", async (req, res) => {
  // Only runs after payment verified + settled
  res.json({ data: "premium content" });
});
```

### Client: Fetch Wrapper

```typescript
import { createWalletClient, http } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { wrapFetchWithPayment } from "x402-fetch";
import { baseSepolia } from "viem/chains";

const account = privateKeyToAccount("0xYourPrivateKey");
const client = createWalletClient({
  account,
  transport: http(),
  chain: baseSepolia,
});

const fetchWithPay = wrapFetchWithPayment(
  fetch,
  client,
  100000  // maxValue: optional, defaults to 0.1 USDC (in atomic units)
);

// Automatically handles 402 → signs payment → retries
const response = await fetchWithPay("https://api.example.com/paid-endpoint");
const data = await response.json();
```

### Client: Axios Interceptor

```typescript
import { createWalletClient, http } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { withPaymentInterceptor } from "x402-axios";
import axios from "axios";
import { baseSepolia } from "viem/chains";

const account = privateKeyToAccount("0xYourPrivateKey");
const client = createWalletClient({
  account,
  transport: http(),
  chain: baseSepolia,
});

const api = withPaymentInterceptor(
  axios.create({ baseURL: "https://api.example.com" }),
  client
);

// Automatically handles 402 responses
const response = await api.get("/paid-endpoint");
```

### Minimal Manual Client Implementation

```typescript
// Step 1: Initial request (will get 402)
let response = await fetch("https://api.example.com/paid-endpoint");

if (response.status === 402) {
  // Step 2: Parse payment requirements
  const paymentRequiredHeader = response.headers.get("PAYMENT-REQUIRED");
  const requirements = JSON.parse(
    Buffer.from(paymentRequiredHeader, "base64").toString("utf8")
  );
  
  // Step 3: Select a payment requirement and create payment header
  const selected = requirements.accepts[0]; // pick first option
  const paymentPayload = await createPaymentPayload(selected, walletClient);
  const paymentHeader = Buffer.from(
    JSON.stringify(paymentPayload)
  ).toString("base64");
  
  // Step 4: Retry with payment
  response = await fetch("https://api.example.com/paid-endpoint", {
    headers: {
      "PAYMENT-SIGNATURE": paymentHeader,
      "Access-Control-Expose-Headers": "PAYMENT-RESPONSE",
    },
  });
  
  // Step 5: Handle response
  const settlementHeader = response.headers.get("PAYMENT-RESPONSE");
  const settlement = JSON.parse(
    Buffer.from(settlementHeader, "base64").toString("utf8")
  );
  console.log("Settlement:", settlement.txHash);
}

const data = await response.json();
```

---

## 7. Integration with canAgentSpend() / VCR Policy

### The Problem: Autonomous Agent Spending Controls

x402 enables agents to pay autonomously, but this creates risk: an agent could overspend, pay for unauthorized resources, or be manipulated into making payments via prompt injection. **VCR (Verifiable Credential Resource)** `canAgentSpend()` is a spending policy mechanism that addresses this.

### Where Policy Verification Fits in the x402 Flow

```
CLIENT (Agent)          POLICY ENGINE (VCR)       RESOURCE SERVER       FACILITATOR
     │                        │                         │                     │
     │                        │                         │                     │
     │──── GET /resource ──────────────────────────────▶│                     │
     │                        │                         │                     │
     │◀─── 402 + PAYMENT-REQUIRED ─────────────────────│                     │
     │                        │                         │                     │
     │                        │                         │                     │
     │──── canAgentSpend()────▶│                         │                     │
     │    {agentId,            │                         │                     │
     │     resource: URL,      │                         │                     │
     │     amount: "$0.01",    │                         │                     │
     │     asset: "USDC",      │                         │                     │
     │     network: "base"}    │                         │                     │
     │                        │                         │                     │
     │◀─── {allowed: true} ───│                         │                     │
     │     OR {allowed: false, │                         │                     │
     │         reason: "..."}  │                         │                     │
     │                        │                         │                     │
     │   [if allowed=true]     │                         │                     │
     │──── GET /resource ──────────────────────────────▶│                     │
     │     PAYMENT-SIGNATURE: <signed payload>          │                     │
     │                        │                         │                     │
     │                        │                         │──── verify ────────▶│
     │                        │                         │◀─── {isValid} ──────│
     │                        │                         │──── settle ────────▶│
     │                        │                         │◀─── {txHash} ───────│
     │                        │                         │                     │
     │◀─── 200 OK + PAYMENT-RESPONSE ──────────────────│                     │
```

### canAgentSpend() — Policy Check Inputs

A `canAgentSpend()` function should check:

```typescript
interface SpendCheckInput {
  agentId: string;           // Which agent is requesting payment
  resource: string;          // URL of the resource (from PAYMENT-REQUIRED)
  amount: string;            // Payment amount (e.g., "0.01")
  asset: string;             // Token contract address
  network: string;           // CAIP-2 network (e.g., "eip155:8453")
  payTo: string;             // Recipient address
  scheme: string;            // Payment scheme ("exact")
  cumulative?: {             // For budget tracking
    daily: string;           // Amount spent today
    session: string;         // Amount spent this session
  };
}

interface SpendCheckResult {
  allowed: boolean;
  reason?: string;           // Why denied (if not allowed)
  suggestedMaxAmount?: string; // Override amount if needed
}
```

### Policy Enforcement Patterns

**Pattern 1: Pre-payment check (recommended)**
```typescript
// Before creating the PAYMENT-SIGNATURE header
async function handleX402(paymentRequirements, agentContext) {
  const policyCheck = await canAgentSpend({
    agentId: agentContext.agentId,
    resource: paymentRequirements.resource,
    amount: formatUnits(BigInt(paymentRequirements.maxAmountRequired), 6), // USDC
    asset: paymentRequirements.asset,
    network: paymentRequirements.network,
    payTo: paymentRequirements.payTo,
    scheme: paymentRequirements.scheme,
  });
  
  if (!policyCheck.allowed) {
    throw new Error(`Payment blocked by policy: ${policyCheck.reason}`);
  }
  
  // Proceed with signing and submitting payment
  return signPayment(paymentRequirements);
}
```

**Pattern 2: Custom wrapFetchWithPayment (intercept before signing)**

```typescript
import { wrapFetchWithPayment } from "x402-fetch";

// Override paymentRequirementsSelector to inject policy check
const fetchWithPolicyCheck = wrapFetchWithPayment(
  fetch,
  walletClient,
  100000, // maxValue
  async (paymentRequirements, selectedRequirement) => {
    // This is called before creating the payment payload
    const allowed = await canAgentSpend({
      resource: selectedRequirement.resource,
      amount: selectedRequirement.maxAmountRequired,
      // ...
    });
    
    if (!allowed) return null; // Returning null blocks the payment
    return selectedRequirement;
  }
);
```

**Pattern 3: Server-side spending controls (via smart account policy)**

x402 can be combined with smart account spending policies (e.g., Privy's policy engine, OpenZeppelin smart contracts):
- Set per-agent daily spending caps in the smart account
- Configure per-domain allowlists
- Require multi-sig approval above threshold amounts

```typescript
// Example: Privy session signer with spend limit
const sessionSigner = await privy.createSessionSigner({
  permissions: {
    maxAmountPerTx: parseUnits("0.10", 6),   // $0.10 max per x402 payment
    dailySpendLimit: parseUnits("1.00", 6),   // $1.00 per day
    allowedDomains: ["api.example.com"],      // Whitelist
  }
});
```

### Summary: Where canAgentSpend() Fits

1. **Client-side, before signing:** Most common. Agent receives 402 → checks policy → proceeds/aborts.
2. **Client-side, in wrapFetchWithPayment selector:** Using the `paymentRequirementsSelector` callback.
3. **Smart account level:** Spending policy enforced at the wallet/contract level (can't be bypassed by the agent).
4. **Off-chain budget tracking:** Maintain a ledger of agent expenditures; canAgentSpend() checks against daily/session limits before each payment.

---

## 8. Networks, Assets, Facilitators

### CDP Facilitator — Supported Networks (as of March 2026)

| Network | CAIP-2 Identifier | Asset | Status | Pricing |
|---|---|---|---|---|
| Base Mainnet | `eip155:8453` | USDC | Live | 1000 free/month, then $0.001/tx |
| Base Sepolia | `eip155:84532` | USDC | Testnet | Free |
| Solana Mainnet | `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp` | SPL Tokens | Live | 1000 free/month |
| Solana Devnet | `solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1` | SPL Tokens | Testnet | Free |

**USDC on Base Sepolia (testnet):**  
Contract: `0x036CbD53842c5426634e7929541eC2318f3dCF7e`

**USDC on Base Mainnet:**  
Contract: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`

### Community Facilitators

| Name | URL | Networks |
|---|---|---|
| x402.org | `https://x402.org/facilitator` | Base, Base Sepolia, others |
| CDP (Coinbase) | `https://api.developer.coinbase.com/rpc/v1/base/x402/facilitator` | Base, Polygon, Solana |

### Why Base?

x402 is primarily developed on **Base** (Coinbase's L2):
- ~2 second settlement
- Very low fees (~$0.001/tx)
- USDC native support via EIP-3009
- Coinbase CDP tooling integration
- However: protocol is chain-agnostic. Solana support exists, Ethereum L1 works too.

---

## 9. Ecosystem: Other Implementations

### npm Packages

| Package | Description |
|---|---|
| `x402` | Core TypeScript types and schemas |
| `x402-express` | Express.js middleware (v1) |
| `x402-fetch` | Fetch wrapper (v1) |
| `x402-axios` | Axios interceptor (v1) |
| `@x402/express` | Express middleware (v2, scoped) |
| `@x402/fetch` | Fetch wrapper (v2) |
| `@x402/axios` | Axios interceptor (v2) |
| `@x402/evm` | EVM scheme (v2) |
| `@x402/svm` | Solana scheme (v2) |
| `@x402/next` | Next.js middleware |
| `@x402/hono` | Hono middleware |
| `@x402/mcp` | MCP server integration |
| `x402-analytics` | Analytics wrapper for x402 payments |

### Framework/Infrastructure Support

| Provider | Implementation |
|---|---|
| Cloudflare | x402 Foundation partnership; Agents SDK + MCP integration |
| Stellar | x402 on Stellar with OpenZeppelin smart accounts |
| Solana | Community + official `@x402/svm` |
| Privy | Embedded wallets + x402 policy engine |
| Thirdweb | x402 GitHub repo |
| MCPay | MCP server monetization via x402 |
| Faremeter | TypeScript Facilitator + Middleware |
| x402-rs | Rust Facilitator & SDK |
| x402-dotnet | .NET community implementation |

### Cloudflare x402 MCP Integration (Example)

```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { McpAgent } from "agents/mcp";
import { withX402 } from "agents/x402";

export class PayMCP extends McpAgent {
  server = withX402(
    new McpServer({ name: "PayMCP", version: "1.0.0" }),
    X402_CONFIG
  );
  
  // Free tool
  this.server.tool("free-tool", "Does something free", { ... }, handler);
  
  // Paid tool — responds with 402 if no payment
  this.server.tool("paid-tool", "Does something paid", { ... }, handler);
}
```

---

## 10. x402 V2 Changes

x402 V2 (launched December 2025) introduced:

1. **Reusable sessions** — agents can negotiate a session token to avoid signing every request
2. **Multi-chain support** — CAIP-2 identifiers standardized across all networks
3. **Automatic service discovery** — Bazaar extension for finding x402-enabled APIs
4. **`deferred` payment scheme** (proposed by Cloudflare) — decouples cryptographic handshake from settlement; supports batch settlements, subscriptions, pre-negotiated agreements
5. **Renamed headers** — from `X-PAYMENT` (v1) to `PAYMENT-SIGNATURE` (v2); from `X-PAYMENT-RESPONSE` (v1) to `PAYMENT-RESPONSE` (v2)
6. **Extensions system** — opt-in features: Bazaar (service discovery), Sign-in-with-x (auth)
7. **`@x402/*` scoped packages** — cleaner separation from v1 `x402-*` packages

### V1 → V2 Migration Quick Reference

| Aspect | V1 | V2 |
|---|---|---|
| Client header | `X-PAYMENT` | `PAYMENT-SIGNATURE` |
| Server response header | `X-PAYMENT-RESPONSE` | `PAYMENT-RESPONSE` |
| Network format | `"base-sepolia"` (string) | `"eip155:84532"` (CAIP-2) |
| Packages | `x402-express`, `x402-fetch` | `@x402/express`, `@x402/fetch` |
| Resource server | Simple middleware | `x402ResourceServer` + scheme registration |

---

## Quick Integration Checklist for Hackathon

### Fileverse Setup

- [ ] `npm install @fileverse/agents`
- [ ] Get Pinata account → copy JWT + gateway domain
- [ ] Get Pimlico API key from dashboard.pimlico.io
- [ ] Set env vars: `CHAIN`, `PRIVATE_KEY`, `PIMLICO_API_KEY`, `PINATA_JWT`, `PINATA_GATEWAY`
- [ ] Add `creds/` to `.gitignore`
- [ ] Call `await agent.setupStorage('namespace')` once to bootstrap
- [ ] Use `agent.create()` to write files, `agent.getFile()` to read

### x402 Server Setup (Express)

- [ ] `npm install x402-express` (v1) or `@x402/express @x402/evm` (v2)
- [ ] Set up wallet address to receive payments
- [ ] Configure routes with prices (e.g., `"$0.01"`)
- [ ] Configure CORS to expose `payment-required` and `payment-response` headers
- [ ] Point to facilitator: `https://x402.org/facilitator` (testnet works)

### x402 Client Setup

- [ ] `npm install x402-fetch` (v1) or `@x402/fetch @x402/evm` (v2)
- [ ] Fund a wallet with testnet USDC on Base Sepolia
  - Bridge testnet USDC: https://faucet.circle.com/ (USDC faucet for Base Sepolia)
- [ ] Wrap `fetch` with `wrapFetchWithPayment(fetch, walletClient)`
- [ ] All 402 responses handled automatically

### Spending Policy Integration

```typescript
// Integrate canAgentSpend() before x402 payment
const policyAwareFetch = wrapFetchWithPayment(
  fetch,
  walletClient,
  parseUnits("0.50", 6), // Hard cap: max $0.50 per request
  async (requirements) => {
    const ok = await canAgentSpend(requirements);
    return ok ? requirements : null; // null = abort payment
  }
);
```

---

## Sources

- [NPM: @fileverse/agents](https://www.npmjs.com/package/@fileverse/agents) — package page, v2.0.1 documentation
- [GitHub: fileverse/agents](https://github.com/fileverse/agents) — source code, README
- [GitHub: fileverse/agents-example](https://github.com/fileverse/agents-example) — example application
- [GitHub: fileverse org](https://github.com/orgs/fileverse/repositories) — all repositories
- [agents.fileverse.io](https://agents.fileverse.io) — agent activity explorer
- [GitHub: coinbase/x402](https://github.com/coinbase/x402) — x402 protocol source, specs, examples
- [x402.org](https://www.x402.org) — official website, stats
- [x402.org/x402.pdf](https://www.x402.org/x402.pdf) — whitepaper
- [Coinbase CDP x402 docs](https://docs.cdp.coinbase.com/x402/welcome) — developer documentation
- [x402 FAQ (Coinbase)](https://docs.cdp.coinbase.com/x402/support/faq) — headers, networks, troubleshooting
- [x402 HTTP transport v2 spec](https://github.com/coinbase/x402/blob/main/specs/transports-v2/http.md) — full header spec with examples
- [x402 exact EVM scheme spec](https://github.com/coinbase/x402/blob/main/specs/schemes/exact/scheme_exact_evm.md) — EIP-3009, Permit2, contract code
- [NPM: x402](https://www.npmjs.com/package/x402) — core package
- [NPM: x402-express](https://www.npmjs.com/package/x402-express) — Express middleware
- [NPM: x402-fetch](https://www.npmjs.com/package/x402-fetch) — Fetch wrapper
- [Permit.io blog: x402 protocol](https://www.permit.io/blog/exploring-the-x402-protocol-for-internet-native-payments) — authorization + x402 integration
- [Cloudflare x402 Foundation announcement](https://blog.cloudflare.com/x402/) — Cloudflare + Coinbase partnership, MCP integration
- [Privy x402 blog](https://privy.io/blog/building-agentic-and-programmatic-payments-with-x402-and-privy) — spending controls and agent payments
- [Simplescraper x402 guide](https://simplescraper.io/blog/x402-payment-protocol) — comprehensive integration guide with dual-auth pattern
- [Solana x402 docs](https://solana.com/x402/what-is-x402) — Solana integration
- [Stellar x402 blog](https://stellar.org/blog/foundation-news/x402-on-stellar) — V2 details, multi-chain
- [Pinata SDK docs](https://docs.pinata.cloud/sdk/getting-started) — IPFS pinning fallback
- [Gnosis Chain gas tracker](https://gnosisscan.io/gastracker) — gas costs
- [Pimlico on Gnosis Chain](https://docs.gnosischain.com/technicalguides/account-abstraction/Safe%20and%20supported%20AA%20infra%20providers/pimilico) — Safe AA setup
